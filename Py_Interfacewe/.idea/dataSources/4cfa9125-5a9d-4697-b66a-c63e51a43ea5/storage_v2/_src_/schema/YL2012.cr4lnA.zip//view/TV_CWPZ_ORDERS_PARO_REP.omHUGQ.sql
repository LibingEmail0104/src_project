CREATE VIEW TV_CWPZ_ORDERS_PARO_REP AS
  select vt2.ordersid,vt2.productid,vt1.sumratio,vt1.discountdetailid from (
select  ha1.ordersid,ha1.discountdetailid,ha1.actual_fee - ha2.actual_fee  sumratio  from
(select t.ordersid,ta.discountdetailid, sum(ta.actual_fee) actual_fee
  from (select t.ordersid, count(*)
          from tv_cwpz_orders_more_par t
         group by t.ordersid) t,
       t_payment_detail ta
 where ta.order_id = t.ordersid group by t.ordersid,ta.discountdetailid) ha1,
 ( select srep.ordersid,srep.discountdetail, sum(srep.sumratio) actual_fee
          from tv_cwpz_orders_sun_rep srep
         group by srep.ordersid ,srep.discountdetail) ha2
         where ha1.ordersid=ha2.ordersid and ha1.discountdetailid=ha2.discountdetail) vt1  ,
( select tt.ordersid,tt.productid
   from (select *
           from tv_cwpz_orders t
          where exists (select 1
                   from tv_cwpz_orders t1
                  where t1.ordersid2 is null
                    and t.ordersid = t1.ordersid)) tt
  where ordersid2 is not null) vt2 where vt1.ordersid=vt2.ordersid
/

