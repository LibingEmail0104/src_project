CREATE PROCEDURE          "UPDATE_ALL" (
       --v_sql cursor, --SQL游标
       v_date varchar2,
       v_num number  --每多少条提交一次
) is

cursor c_ci is --查询返回结果
              select 'insert into jf_obtainrecord values(seq_jf_other.nextval,' ||
                   o.ordersid || ',' || o.customersid || ',' || o.ytotal ||
                   ',sysdate,100,100,100,sysdate,sysdate,''自动修改bug积分订单'')' as sqls
              from t_orders o, t_payment p, jf_obtainrecord j
             where o.ordersid = p.ordersid
               and o.ordersid = j.orderid(+)
               and p.paystatus = 2
               and j.orderid is null
               and o.createtime > to_date(v_date, 'yyyymmdd');
r_ci c_ci % rowtype; --类型

v_index number := 0; --批量提交计数器
v_count number := 0;
begin
  --判断游标是否打开
  if c_ci%isopen then
    null;
  else
    open c_ci;   --打开游标
  end if;

  --循环执行
  loop
    fetch c_ci
      into r_ci;
    exit when c_ci%notfound;
    --判断查询结果集 > 0
    v_index := v_index + 1;
    v_count := (v_count + 1) * v_num;
    --dbms_output.put_line(r_ci.sqls);
    --执行SQL
    --execute immediater ci.sqls;
    execute immediate r_ci.sqls;

    if (v_index = v_num) then
       dbms_output.put_line(' commit success... ' || v_count);
       commit;
       v_index := 0;
    end if;
  end loop;
end update_all;




/

