CREATE PROCEDURE "P_UPDATE_PAYMENT" is

  --定义游标
  cursor c_ci is
  select   ordersid  from vt_od_ids where oisuse=1 ;
  r_ci c_ci % rowtype;
  --判断循环次数
  v_index number := 0;
 begin
  --判断游标是否打开
  if c_ci%isopen then
    null;
  else
    open c_ci;
  end if;

  loop
    fetch c_ci
      into r_ci;
    exit when c_ci%notfound;

 update t_orders o set o.batch='YL_BATCH2016',o.starus=10 where o.ordersid=r_ci.ordersid;

    --分段提交
    v_index := v_index + 1;
    if (v_index = 5000) then
      commit;
      v_index := 0;
    end if;
  end loop;

   commit;

  close c_ci;
end P_UPDATE_PAYMENT;

/

