CREATE procedure p_lodeleuser is
begin
  update t_customers tc
     set tc.status = 1, tc.lastuser = 'z_trigger'
   where tc.status = 0 and tc.TYPE=0
     and customersid in
         (select t.customersid
            from t_orders t, t_ordersdetail tod
           where t.ordersid = tod.ordersid
             and tod.productplayid in
                 (78045382, 78045383, 78045384, 78045385, 78045386, 78045387)
           group by t.customersid
          having sum(num) > 24 or count(*) > 4);
  commit;
end;

/

