CREATE FUNCTION get_codeid (v_areaid number) return number is
  v_codeid number;
begin
  select min(tc.codeid)  into v_codeid from t_code tc where areaid =v_areaid;
  return v_codeid;
end;

/

