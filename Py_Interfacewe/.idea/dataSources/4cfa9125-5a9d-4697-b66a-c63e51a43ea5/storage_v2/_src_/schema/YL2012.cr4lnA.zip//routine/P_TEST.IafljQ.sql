CREATE procedure p_test (v_ordersid number,v_id number)
as
CURSOR O_1 is select * from  t_orders t where t.ordersid=v_ordersid;
CO_1  O_1 % rowtype;
cursor P_1 is select * from  t_payment_detail t where t.id=v_id;
CP_1  P_1 % rowtype;
begin
open O_1;
    fetch O_1 into CO_1;
open P_1;
    fetch P_1 into CP_1;
if (CP_1.discount =70056) then
        dbms_output.put_line('youxi');
    elsif  ( CP_1.discount=48668970) then
        dbms_output.put_line('zaixian');
end if;
close O_1;
close P_1;
end ;

/

