CREATE TRIGGER TRIGGER_LOG_T_PROCEDUREPRICE
  AFTER UPDATE
  ON T_PROCEDUREPRICE
  FOR EACH ROW
  begin
  insert into log_t_procedureprice
    (procedurepriceid,
     ordersid,
     orderprice,
     procedureprice,
     createtime,
     lasttime,
     lastuser,
     fconfigid,
     refundprice,
     ordersdetailid,
     logtime)
  values
    (:old.PROCEDUREPRICEID,
     :old.ORDERSID,
     :old.ORDERPRICE,
     :old.PROCEDUREPRICE,
     :old.CREATETIME,
     :old.LASTTIME,
     :old.LASTUSER,
     :old.FCONFIGID,
     :old.REFUNDPRICE,
     :old.ORDERSDETAILID,
     sysdate);
end;


/

