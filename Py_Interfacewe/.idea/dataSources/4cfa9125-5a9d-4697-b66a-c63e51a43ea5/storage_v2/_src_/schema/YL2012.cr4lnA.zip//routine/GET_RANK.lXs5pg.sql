CREATE function get_rank (v_discountdetailid number)
return varchar2 is
v_rank varchar2(40);
begin
   select t.rank into v_rank from t_discountdetail t   where t.discountdetailid=v_discountdetailid;
return v_rank;
exception
  when no_data_found then
    return ''  ;
  when others then
    return '出错了' || v_discountdetailid;
end;






/

