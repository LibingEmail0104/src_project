CREATE FUNCTION GET_id_pay (v_ordersid number)
  return varchar2 is
  v_pay varchar2(200);
begin
  select wm_concat (t.id) into v_pay
  from t_payment_detail t
 where    t.payment_status=1 and t.order_id=v_ordersid  and t.discountdetailid=2217200  group by t.order_id;
 return v_pay;
    exception
  when no_data_found then
    return ' '  ;
  when others then
    return ' '  ;
end;

/

