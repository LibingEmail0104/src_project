CREATE PROCEDURE          "LETONGUSEPRO" is

  --定义游标
  cursor c_ci is
    select * from (select lc.id,lc.initprice from t_letongcard lc) ltc;
  --定义rowtype
  r_ci c_ci % rowtype;

  --判断循环次数
  v_index number := 0;

begin
  --判断游标是否打开
  if c_ci%isopen then
    null;
  else
    open c_ci;
  end if;

  loop
    fetch c_ci
      into r_ci;
    exit when c_ci%notfound;

    --存储数据
    insert into t_letonguse
      (ID,
       LETONGCARDID,
       ORDERSID,
       TYPE,
       PRICE,
       CREATETIME,
       LASTTIME,
       LASTUSER)
    values
      (seq_a.nextval,
       r_ci.id,
       null,
       20,
       r_ci.initprice,
       to_date('04-08-2014 16:48:06', 'dd-mm-yyyy hh24:mi:ss'),
       to_date('04-08-2014 16:48:06', 'dd-mm-yyyy hh24:mi:ss'),
       'auto');

    --分段提交
    v_index := v_index + 1;
    if (v_index = 2000) then
      commit;
      v_index := 0;
    end if;

  end loop;
  --循环后再次提交数据
  commit;

  close c_ci;

end letongusepro;




/

