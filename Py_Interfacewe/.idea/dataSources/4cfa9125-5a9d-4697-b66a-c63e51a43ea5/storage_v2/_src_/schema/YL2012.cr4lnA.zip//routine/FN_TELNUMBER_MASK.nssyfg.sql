CREATE FUNCTION          "FN_TELNUMBER_MASK" (
    p_telnumber IN VARCHAR2,
    p_flag IN INT -- 0 ?????1 ????
)
    RETURN VARCHAR2
IS
BEGIN
    IF p_flag = 0
    THEN
        IF SUBSTR (p_telnumber, 1, 1) = '0' -- ??
        THEN
            IF LENGTH (p_telnumber) = 11 -- ????
            THEN
                IF SUBSTR (p_telnumber, 1, 3) IN
                      ('020',
                       '021',
                       '022',
                       '023',
                       '024',
                       '025',
                       '026',
                       '027',
                       '028',
                       '029',
                       '010'
                      )
                THEN
                    RETURN REPLACE (p_telnumber,SUBSTR (p_telnumber, 4, 4),'****');
                ELSE -- ????
                    RETURN REPLACE (p_telnumber,SUBSTR (p_telnumber, 5, 4),'****');
                END IF;
            ELSE
                RETURN REPLACE (p_telnumber, SUBSTR (p_telnumber, 5, 4), '****');
            END IF;
        ELSE -- ???
            RETURN REPLACE (p_telnumber, SUBSTR (p_telnumber, 4, 4), '****');
        END IF;
    ELSE -- ???4??
        RETURN REPLACE (p_telnumber, SUBSTR (p_telnumber, -4, 4), '****');
    END IF;
END fn_telnumber_mask;




/

