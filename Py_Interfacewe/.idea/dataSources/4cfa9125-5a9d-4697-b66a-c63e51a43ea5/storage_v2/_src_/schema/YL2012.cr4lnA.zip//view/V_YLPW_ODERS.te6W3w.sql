CREATE VIEW V_YLPW_ODERS AS
  select o.orderid,orderpeople,/*,o.caltotal ytotal ,o.discount,o.realtotal total*/o.acceptname bname,o.acceptmobile bphone,o.acceptaddress address,decode(o.orderstatus,6,'已完成',7,'已完成','无效') status  from YLPW40.Orders o
/

