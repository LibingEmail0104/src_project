CREATE VIEW V_SESSION AS
  select machine ,count(1) as count from v$session t group by rollup(t.machine) order by 2


/

