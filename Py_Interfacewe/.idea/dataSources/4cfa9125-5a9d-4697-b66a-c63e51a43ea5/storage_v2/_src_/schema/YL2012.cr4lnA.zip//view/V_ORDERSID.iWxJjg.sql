CREATE VIEW V_ORDERSID AS
  select ordersid from (select c.phone 手机,
       c.email 邮箱,
       c.createtime 用户注册时间,
       o.ordersid  ,
       get_ordersource(o.ordersource) 来源,
       ad.username 收货人,
       o.customersid,
       ad.phone 收货人手机号,
       get_cityname2(ad.cityid) as 城市,
       get_areaname(ad.areaid) as 区,
       ad.name 详细地址,
     --  od.ordersdetailid 明细ID,
       p.name 商品,
       tp.playdate 演出时间,
       tp.price 价格,
       od.num 数量,
       get_ordersource(o.ordersource),
       decode(tp.starus,
              1,
              '可售',
              2,
              '售完',
              3,
              '隐藏',
              4,
              '预订',
              5,
              '无效') 票价状态,
       get_yh(od.ordersdetailid) 优惠折扣,

       (case
         when (row_number()
               over(partition by o.ordersid order by pm.insuredamount)) = 1 then
          pm.insuredamount
         else
          null
       end) 保费,

       (case
         when (row_number()
               over(partition by o.ordersid order by o.rangeprice)) = 1 then
          o.rangeprice
         else
          null
       end) 运费,
       GET_payways2(o.ordersid) 支付方式,
       pm.paysuccessfultime 支付时间,
       od.ytotal - get_od_zk(od.ordersdetailid) 实收,
       --pm.insuredamount 保费,o.rangeprice 运费,pm.zprice 实收
       od.seat 座位号,
       decode(o.psxx, 1, '快递配送', 2, '上门自取', 4, '电子票') 票制类型,
       pa.name 分类,
       tcode.name 出票系统

  from t_orders       o,
       t_ordersdetail od,
       t_productplay  tp,
       t_product      p,
       t_customers    c,
       t_address      ad,
       t_payment      pm,
       t_producttypea pa,
       t_code         tcode

 where o.ordersid = od.ordersid
   and tp.productplayid = od.productplayid
   and c.customersid = o.customersid
   and o.addressid = ad.addressid(+)
   and o.ordersid = pm.ordersid(+)
   and p.codeid = tcode.codeid(+)
   and p.producttypeaid1 = pa.producttypeaid(+)
   and tp.productid = p.productid
   and p.productid in (140844156)
   and o.starus in (5, 6))
   where 支付时间>演出时间
/

