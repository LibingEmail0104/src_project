CREATE PROCEDURE PZ_ONE_ORDER(v_ordersid in number,v_date in varchar2,v_pay in number,v_payno in varchar2)
as
   cursor c_one is
  select * from   t_payment_detail where order_id=v_ordersid  and original_fee=v_pay;
  r_one c_one % rowtype;
  v_row number;
 begin
   if c_one%isopen then
    null;
  else
    open c_one;
  end if;

    fetch c_one into r_one;

savepoint  point_a;

update t_payment_detail t
   set t.actual_fee            = v_pay ,
       t.payment_status        = 1,
       t.trade_create_time     = to_date(v_date,'yyyy-mm-dd hh24:mi:ss'),
       t.trade_finish_time     = to_date(v_date,'yyyy-mm-dd hh24:mi:ss'),
       t.third_trade_no           = v_payno,
       t.last_users='ZQ_P',
       t.discountvalue         = 100,
       t.original_discount_fee = v_pay,
       t.pay_discount_fee      = 0.00
 where id = r_one.id and t.original_fee=v_pay and rownum=1;
v_row :=SQL%ROWCOUNT ;
dbms_output.put_line('支付明细 更新行数：  '||v_row);

 if v_row>1 then
    rollback to savepoint point_a;
  end if;




savepoint  point_b;
 update t_payment  t set t.paystatus=2, t.isselect  =1,LASTUSER='ZQ_P',t.paysuccessfultime= to_date(v_date,'yyyy-mm-dd hh24:mi:ss') where  ordersid=v_ordersid;
 v_row :=SQL%ROWCOUNT ;
dbms_output.put_line('支付     更新行数：  '||v_row);

 if v_row>1 then
    rollback to savepoint point_b;
  end if;



savepoint  point_c;
 update t_orders t set t.starus=2 ,LASTUSER='ZQ_P'   where  ordersid=v_ordersid;
 v_row :=SQL%ROWCOUNT ;
dbms_output.put_line('订单     更新行数：  '||v_row);

 if v_row>1 then
    rollback to savepoint point_c;
  end if;

  close c_one;
commit;

 exception
  when others then
    rollback to  savepoint point_a;
    close c_one;
    RAISE_APPLICATION_ERROR(-20010, '更新失败,更新回滚');
end;

/

