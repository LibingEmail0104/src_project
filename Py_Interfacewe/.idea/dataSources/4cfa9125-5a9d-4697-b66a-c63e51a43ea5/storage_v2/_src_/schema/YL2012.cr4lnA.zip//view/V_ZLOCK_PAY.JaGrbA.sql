CREATE VIEW V_ZLOCK_PAY AS
  SELECT 'ALTER SYSTEM KILL SESSION ''' || TA.SID || ',' || TA.SERIAL# ||
       ''';' SQLS
  FROM V$SESSION TA,
       (SELECT /*+rule+*/  t.*
          FROM V$LOCK T,V$LOCK TT
         WHERE T.TYPE IN ('TM')
           and tt.sid=t.sid
           and tt.TYPE in ('TX')
           AND tt.BLOCK = 1
           and t.id1=92613
           and t.CTIME>10
          ) TB
 WHERE TA.SID = TB.SID
/

