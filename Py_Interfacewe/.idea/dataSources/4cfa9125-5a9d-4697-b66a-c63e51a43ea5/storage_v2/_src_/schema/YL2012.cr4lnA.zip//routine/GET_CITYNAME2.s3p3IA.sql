CREATE FUNCTION "GET_CITYNAME2" (p_ctiyid number) return varchar2 is
  v_cityname varchar2(50);
begin
  select t1.cityname  into v_cityname from t_city t1 where t1.cityid=p_ctiyid;
  return v_cityname;
/*   EXCEPTION
         WHEN NO_DATA_FOUND THEN
       return '什么啊';*/
end;




/

