CREATE PROCEDURE          "DEDUCTINTEGRALPRO" (v_lasttime     varchar2,
                                              v_lastuser     varchar2,
                                              v_discount     number,
                                              v_discountname varchar2) is
  --定义游标
  cursor c_ci is
    select *
      from (select customersid,
                   oldintegral,
                   deductintegral,
                   (oldintegral - deductintegral) as newintegral
              from (select c.customersid,
                           c.integral as oldintegral,
                           trunc(c.integral * (v_discount * 0.01)) as deductintegral
                      from t_customers c
                     where c.type = 0
                       and c.integral > 0)) customersintegral;
  --定义rowtype
  r_ci c_ci % rowtype;

  --判断循环次数
  v_index number := 0;
begin
  --判断游标是否打开
  if c_ci%isopen then
    null;
  else
    open c_ci;
  end if;

  loop
    fetch c_ci
      into r_ci;
    exit when c_ci%notfound;

    --判断折损积分是否大于0
    if (r_ci.deductintegral > 0) then

      --更新用户表积分
      update t_customers c
         set c.integral = r_ci.newintegral,
             c.lasttime = to_date(v_lasttime, 'yyyy-MM-dd hh24:mi:ss'),
             c.lastuser = v_lastuser
       where c.customersid = r_ci.customersid;

      --增加积分折损表
      insert into jf_deductintegralrecord
        (deductintegralrecordid,
         customersid,
         name,
         oldintegral,
         discount,
         deductintegral,
         newintegral,
         deducttime,
         createtime,
         lasttime,
         lastuser)
      values
        (seq_jf_other.nextval,
         r_ci.customersid,
         v_discountname,
         r_ci.oldintegral,
         v_discount,
         r_ci.deductintegral,
         r_ci.newintegral,
         to_date(v_lasttime, 'yyyy-MM-dd hh24:mi:ss'),
         to_date(v_lasttime, 'yyyy-MM-dd hh24:mi:ss'),
         to_date(v_lasttime, 'yyyy-MM-dd hh24:mi:ss'),
         v_lastuser);

      --分段提交
      v_index := v_index + 1;
      if (v_index = 2000) then
        commit;
        v_index := 0;
      end if;

    end if;

  end loop;
  --循环后再次提交数据
  commit;

  close c_ci;
end deductintegralpro;




/

