CREATE FUNCTION get_odtotal (p_ordersid  number,
                                      p_ordersdetailid NUMBER,
                                      p_by        number) return number is
  v_odtotal number(20,2);
begin
  select (select decode(od.total,0,1,null,1,od.total) from t_orders o,t_ordersdetail od where o.ordersid=od.ordersid and od.ordersdetailid=p_ordersdetailid) /
         (select decode(sum(od.total),0,1,sum(od.total)) from t_orders o,t_ordersdetail od where o.ordersid=od.ordersid and o.ordersid=p_ordersid) * p_by
    into v_odtotal
    from dual;
  return v_odtotal;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    return '0.00';
end;

/

