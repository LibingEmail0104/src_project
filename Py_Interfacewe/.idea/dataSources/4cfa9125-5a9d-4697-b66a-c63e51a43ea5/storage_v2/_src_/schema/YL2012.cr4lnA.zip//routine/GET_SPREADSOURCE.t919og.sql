CREATE FUNCTION "GET_SPREADSOURCE" (scodeid varchar2) return varchar2 is
  v_name varchar2(50);
begin
    select  name into v_name from t_code where type=6 and codeid=scodeid;
  return v_name;
EXCEPTION
when Too_many_rows
then
        return v_name;
end;

/

