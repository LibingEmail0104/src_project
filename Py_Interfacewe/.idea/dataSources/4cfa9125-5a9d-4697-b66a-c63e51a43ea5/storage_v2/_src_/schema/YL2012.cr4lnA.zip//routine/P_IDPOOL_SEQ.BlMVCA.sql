CREATE procedure p_idpool_seq as
oid number;
odid number;
ct number;
begin
  select  seq_order.nextval into oid from dual;
  select  seq_order.nextval into odid from dual;
  select  to_char(sysdate,'yyyymmdd') into ct from dual;
  insert into vt_od_ids values(oid,odid,ct,0,0);
commit;
end p_idpool_seq;

/

