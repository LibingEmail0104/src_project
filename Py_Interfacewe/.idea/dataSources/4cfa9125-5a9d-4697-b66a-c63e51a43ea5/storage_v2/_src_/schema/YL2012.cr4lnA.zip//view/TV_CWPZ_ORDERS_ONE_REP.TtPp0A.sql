CREATE VIEW TV_CWPZ_ORDERS_ONE_REP AS
  select /*+ parallel(2) */
   ordersid,
   productid,
   get_cwpz_one(ordersid, productid, id) sumratio,
   --get_discount(id) discount,
   get_discountdetail(id) discountdetail
    from tv_cwpz_orders_one_pmdid
/

