CREATE FUNCTION "GET_CITYNAME" (p_ctiyid number) return varchar2 is
  v_cityname varchar2(50);
begin
  v_cityname := case p_ctiyid
                  when 1 then
                   '北京市'
                  when 50050 then
                   '天津市'
                  when 51900 then
                   '上海市'
                  when 131000 then
                   '郑州市'
                  when 131001 then
                   '哈尔滨市'
                  when 131002 then
                   '成都市'
                  when 131003 then
                   '重庆市'
                  when 131004 then
                   '广州市'
                  when 131005 then
                   '深圳市'
                  when 131006 then
                   '南京市'
                  when 758500 then
                   '石家庄市'
                  when 758501 then
                   '唐山市'
                  when 758502 then
                   '秦皇岛市'
                  when 758503 then
                   '邯郸市'
                  when 758504 then
                   '邢台市'
                  when 758505 then
                   '保定市'
                  when 758506 then
                   '张家口市'
                  when 758507 then
                   '承德市'
                  when 758508 then
                   '沧州市'
                  when 758509 then
                   '廊坊市'
                  when 758510 then
                   '衡水市'
                  when 758511 then
                   '太原市'
                  when 758512 then
                   '大同市'
                  when 758513 then
                   '阳泉市'
                  when 758514 then
                   '长治市'
                  when 758515 then
                   '晋城市'
                  when 758516 then
                   '朔州市'
                  when 758517 then
                   '晋中市'
                  when 758518 then
                   '运城市'
                  when 758519 then
                   '忻州市'
                  when 758520 then
                   '临汾市'
                  when 758521 then
                   '吕梁市'
                  when 758522 then
                   '呼和浩特市'
                  when 758523 then
                   '包头市'
                  when 758524 then
                   '乌海市'
                  when 758525 then
                   '赤峰市'
                  when 758526 then
                   '通辽市'
                  when 758527 then
                   '鄂尔多斯市'
                  when 758528 then
                   '呼伦贝尔市'
                  when 758529 then
                   '巴彦淖尔市'
                  when 758530 then
                   '乌兰察布市'
                  when 758531 then
                   '兴安盟'
                  when 758532 then
                   '锡林郭勒盟'
                  when 758533 then
                   '阿拉善盟'
                  when 758534 then
                   '沈阳市'
                  when 758535 then
                   '大连市'
                  when 758536 then
                   '鞍山市'
                  when 758537 then
                   '抚顺市'
                  when 758538 then
                   '本溪市'
                  when 758539 then
                   '丹东市'
                  when 758540 then
                   '锦州市'
                  when 758541 then
                   '营口市'
                  when 758542 then
                   '阜新市'
                  when 758543 then
                   '辽阳市'
                  when 758544 then
                   '盘锦市'
                  when 758545 then
                   '铁岭市'
                  when 758546 then
                   '朝阳市'
                  when 758547 then
                   '葫芦岛市'
                  when 758548 then
                   '长春市'
                  when 758549 then
                   '吉林市'
                  when 758550 then
                   '四平市'
                  when 758551 then
                   '辽源市'
                  when 758552 then
                   '通化市'
                  when 758553 then
                   '白山市'
                  when 758554 then
                   '松原市'
                  when 758555 then
                   '白城市'
                  when 758557 then
                   '齐齐哈尔市'
                  when 758558 then
                   '鸡西市'
                  when 758559 then
                   '鹤岗市'
                  when 758560 then
                   '双鸭山市'
                  when 758561 then
                   '大庆市'
                  when 758562 then
                   '伊春市'
                  when 758563 then
                   '佳木斯市'
                  when 758564 then
                   '七台河市'
                  when 758565 then
                   '牡丹江市'
                  when 758566 then
                   '黑河市'
                  when 758567 then
                   '绥化市'
                  when 758568 then
                   '大兴安岭地区'
                  when 758569 then
                   '无锡市'
                  when 758570 then
                   '徐州市'
                  when 758571 then
                   '常州市'
                  when 758572 then
                   '苏州市'
                  when 758573 then
                   '南通市'
                  when 758574 then
                   '连云港市'
                  when 758575 then
                   '淮安市'
                  when 758576 then
                   '盐城市'
                  when 758577 then
                   '扬州市'
                  when 758578 then
                   '镇江市'
                  when 758579 then
                   '泰州市'
                  when 758580 then
                   '宿迁市'
                  when 758581 then
                   '杭州市'
                  when 758582 then
                   '宁波市'
                  when 758583 then
                   '温州市'
                  when 758584 then
                   '嘉兴市'
                  when 758585 then
                   '湖州市'
                  when 758586 then
                   '绍兴市'
                  when 758587 then
                   '金华市'
                  when 758588 then
                   '衢州市'
                  when 758589 then
                   '舟山市'
                  when 758590 then
                   '台州市'
                  when 758591 then
                   '丽水市'
                  when 758592 then
                   '合肥市'
                  when 758593 then
                   '芜湖市'
                  when 758594 then
                   '蚌埠市'
                  when 758595 then
                   '淮南市'
                  when 758596 then
                   '马鞍山市'
                  when 758597 then
                   '淮北市'
                  when 758598 then
                   '铜陵市'
                  when 758599 then
                   '安庆市'
                  when 758600 then
                   '黄山市'
                  when 758601 then
                   '滁州市'
                  when 758602 then
                   '阜阳市'
                  when 758603 then
                   '宿州市'
                  when 758604 then
                   '巢湖市'
                  when 758605 then
                   '六安市'
                  when 758606 then
                   '亳州市'
                  when 758607 then
                   '池州市'
                  when 758608 then
                   '宣城市'
                  when 758609 then
                   '福州市'
                  when 758610 then
                   '厦门市'
                  when 758611 then
                   '莆田市'
                  when 758612 then
                   '三明市'
                  when 758613 then
                   '泉州市'
                  when 758614 then
                   '漳州市'
                  when 758615 then
                   '南平市'
                  when 758616 then
                   '龙岩市'
                  when 758617 then
                   '宁德市'
                  when 758618 then
                   '南昌市'
                  when 758619 then
                   '景德镇市'
                  when 758620 then
                   '萍乡市'
                  when 758621 then
                   '九江市'
                  when 758622 then
                   '新余市'
                  when 758623 then
                   '鹰潭市'
                  when 758624 then
                   '赣州市'
                  when 758625 then
                   '吉安市'
                  when 758626 then
                   '宜春市'
                  when 758627 then
                   '抚州市'
                  when 758628 then
                   '上饶市'
                  when 758629 then
                   '济南市'
                  when 758630 then
                   '青岛市'
                  when 758631 then
                   '淄博市'
                  when 758632 then
                   '枣庄市'
                  when 758633 then
                   '东营市'
                  when 758634 then
                   '烟台市'
                  when 758635 then
                   '潍坊市'
                  when 758636 then
                   '济宁市'
                  when 758637 then
                   '泰安市'
                  when 758638 then
                   '威海市'
                  when 758639 then
                   '日照市'
                  when 758640 then
                   '莱芜市'
                  when 758641 then
                   '临沂市'
                  when 758642 then
                   '德州市'
                  when 758643 then
                   '聊城市'
                  when 758644 then
                   '滨州市'
                  when 758645 then
                   '菏泽市'
                  when 758646 then
                   '开封市'
                  when 758647 then
                   '洛阳市'
                  when 758648 then
                   '平顶山市'
                  when 758649 then
                   '安阳市'
                  when 758650 then
                   '鹤壁市'
                  when 758651 then
                   '新乡市'
                  when 758652 then
                   '焦作市'
                  when 758653 then
                   '濮阳市'
                  when 758654 then
                   '许昌市'
                  when 758655 then
                   '漯河市'
                  when 758656 then
                   '三门峡市'
                  when 758657 then
                   '南阳市'
                  when 758658 then
                   '商丘市'
                  when 758659 then
                   '信阳市'
                  when 758660 then
                   '周口市'
                  when 758661 then
                   '驻马店市'
                  when 758662 then
                   '武汉市'
                  when 758663 then
                   '黄石市'
                  when 758664 then
                   '十堰市'
                  when 758665 then
                   '宜昌市'
                  when 758666 then
                   '襄樊市'
                  when 758667 then
                   '鄂州市'
                  when 758668 then
                   '荆门市'
                  when 758669 then
                   '孝感市'
                  when 758670 then
                   '荆州市'
                  when 758671 then
                   '黄冈市'
                  when 758672 then
                   '咸宁市'
                  when 758673 then
                   '随州市'
                  when 758675 then
                   '神农架'
                  when 758676 then
                   '长沙市'
                  when 758677 then
                   '株洲市'
                  when 758678 then
                   '湘潭市'
                  when 758679 then
                   '衡阳市'
                  when 758680 then
                   '邵阳市'
                  when 758681 then
                   '岳阳市'
                  when 758682 then
                   '常德市'
                  when 758683 then
                   '张家界市'
                  when 758684 then
                   '益阳市'
                  when 758685 then
                   '郴州市'
                  when 758686 then
                   '永州市'
                  when 758687 then
                   '怀化市'
                  when 758688 then
                   '娄底市'
                  when 758690 then
                   '韶关市'
                  when 758691 then
                   '珠海市'
                  when 758692 then
                   '汕头市'
                  when 758693 then
                   '佛山市'
                  when 758694 then
                   '江门市'
                  when 758695 then
                   '湛江市'
                  when 758696 then
                   '茂名市'
                  when 758697 then
                   '肇庆市'
                  when 758698 then
                   '惠州市'
                  when 758699 then
                   '梅州市'
                  when 758700 then
                   '汕尾市'
                  when 758701 then
                   '河源市'
                  when 758702 then
                   '阳江市'
                  when 758703 then
                   '清远市'
                  when 758704 then
                   '东莞市'
                  when 758705 then
                   '中山市'
                  when 758706 then
                   '潮州市'
                  when 758707 then
                   '揭阳市'
                  when 758708 then
                   '云浮市'
                  when 758709 then
                   '南宁市'
                  when 758710 then
                   '柳州市'
                  when 758711 then
                   '桂林市'
                  when 758712 then
                   '梧州市'
                  when 758713 then
                   '北海市'
                  when 758714 then
                   '防城港市'
                  when 758715 then
                   '钦州市'
                  when 758716 then
                   '贵港市'
                  when 758717 then
                   '玉林市'
                  when 758718 then
                   '百色市'
                  when 758719 then
                   '贺州市'
                  when 758720 then
                   '河池市'
                  when 758721 then
                   '来宾市'
                  when 758722 then
                   '崇左市'
                  when 758723 then
                   '海口市'
                  when 758724 then
                   '三亚市'
                  when 758725 then
                   '自贡市'
                  when 758726 then
                   '攀枝花市'
                  when 758727 then
                   '泸州市'
                  when 758728 then
                   '德阳市'
                  when 758729 then
                   '绵阳市'
                  when 758730 then
                   '广元市'
                  when 758731 then
                   '遂宁市'
                  when 758732 then
                   '内江市'
                  when 758733 then
                   '乐山市'
                  when 758734 then
                   '南充市'
                  when 758735 then
                   '眉山市'
                  when 758736 then
                   '宜宾市'
                  when 758737 then
                   '广安市'
                  when 758738 then
                   '达州市'
                  when 758739 then
                   '雅安市'
                  when 758740 then
                   '巴中市'
                  when 758741 then
                   '资阳市'
                  when 758745 then
                   '贵阳市'
                  when 758746 then
                   '六盘水市'
                  when 758747 then
                   '遵义市'
                  when 758748 then
                   '安顺市'
                  when 758749 then
                   '铜仁地区'
                  when 758751 then
                   '毕节地区'
                  when 758754 then
                   '昆明市'
                  when 758755 then
                   '曲靖市'
                  when 758756 then
                   '玉溪市'
                  when 758757 then
                   '保山市'
                  when 758758 then
                   '昭通市'
                  when 758759 then
                   '丽江市'
                  when 758760 then
                   '普洱市'
                  when 758761 then
                   '临沧市'
                  when 758770 then
                   '拉萨市'
                  when 758771 then
                   '昌都地区'
                  when 758772 then
                   '山南地区'
                  when 758773 then
                   '日喀则地区'
                  when 758774 then
                   '那曲地区'
                  when 758775 then
                   '阿里地区'
                  when 758776 then
                   '林芝地区'
                  when 758777 then
                   '西安市'
                  when 758778 then
                   '铜川市'
                  when 758779 then
                   '宝鸡市'
                  when 758780 then
                   '咸阳市'
                  when 758781 then
                   '渭南市'
                  when 758782 then
                   '延安市'
                  when 758783 then
                   '汉中市'
                  when 758784 then
                   '榆林市'
                  when 758785 then
                   '安康市'
                  when 758786 then
                   '商洛市'
                  when 758787 then
                   '兰州市'
                  when 758788 then
                   '嘉峪关市'
                  when 758789 then
                   '金昌市'
                  when 758790 then
                   '白银市'
                  when 758791 then
                   '天水市'
                  when 758792 then
                   '武威市'
                  when 758793 then
                   '张掖市'
                  when 758794 then
                   '平凉市'
                  when 758795 then
                   '酒泉市'
                  when 758796 then
                   '庆阳市'
                  when 758797 then
                   '定西市'
                  when 758798 then
                   '陇南市'
                  when 758801 then
                   '西宁市'
                  when 758802 then
                   '海东地区'
                  when 758809 then
                   '银川市'
                  when 758810 then
                   '石嘴山市'
                  when 758811 then
                   '吴忠市'
                  when 758812 then
                   '固原市'
                  when 758813 then
                   '中卫市'
                  when 758814 then
                   '乌鲁木齐市'
                  when 758815 then
                   '克拉玛依市'
                  when 758816 then
                   '吐鲁番地区'
                  when 758817 then
                   '哈密地区'
                  when 758821 then
                   '阿克苏地区'
                  when 758823 then
                   '喀什地区'
                  when 758824 then
                   '和田地区'
                  when 758826 then
                   '塔城地区'
                  when 758827 then
                   '阿勒泰地区'
                  when 758828 then
                   '直辖市'
                  when 758832 then
                   '台湾省'
                  when 760800 then
                   '延边朝鲜族自治州'
                  when 760801 then
                   '恩施土家族苗族自治州'
                  when 760802 then
                   '湘西土家族苗族自治州'
                  when 760803 then
                   '阿坝藏族羌族自治州'
                  when 760804 then
                   '甘孜藏族自治州'
                  when 760805 then
                   '凉山彝族自治州'
                  when 760850 then
                   '黔西南布依族苗族自治州'
                  when 760851 then
                   '黔东南苗族侗族自治州'
                  when 760852 then
                   '黔南布依族苗族自治州'
                  when 760853 then
                   '楚雄彝族自治州'
                  when 760854 then
                   '红河哈尼族彝族自治州'
                  when 760855 then
                   '文山壮族苗族自治州'
                  when 760856 then
                   '西双版纳傣族自治州'
                  when 760857 then
                   '大理白族自治州'
                  when 760858 then
                   '德宏傣族景颇族自治州'
                  when 760859 then
                   '怒江傈僳族自治州'
                  when 760860 then
                   '迪庆藏族自治州'
                  when 760861 then
                   '临夏回族自治州'
                  when 760862 then
                   '甘南藏族自治州'
                  when 760863 then
                   '海北藏族自治州'
                  when 760864 then
                   '黄南藏族自治州'
                  when 760865 then
                   '海南藏族自治州'
                  when 760866 then
                   '果洛藏族自治州'
                  when 760867 then
                   '玉树藏族自治州'
                  when 760868 then
                   '海西蒙古族藏族自治州'
                  when 760869 then
                   '昌吉回族自治州'
                  when 760870 then
                   '博尔塔拉蒙古自治州'
                  when 760871 then
                   '巴音郭楞蒙古自治州'
                  when 760872 then
                   '克孜勒苏柯尔克孜自治州'
                  when 760873 then
                   '伊犁哈萨克自治州'
                  when 760874 then
                   '香港特别行政区'
                  when 760875 then
                   '澳门特别行政区'
                  when 3230051 then
                   '仙桃市'
                  when 3230052 then
                   '潜江市'
                  when 3230053 then
                   '天门市'
                  else
                   '未知城市'
                end;
  return v_cityname;
end;





/

