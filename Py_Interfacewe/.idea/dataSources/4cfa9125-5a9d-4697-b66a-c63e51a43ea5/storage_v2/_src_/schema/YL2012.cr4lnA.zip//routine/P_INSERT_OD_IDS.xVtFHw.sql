CREATE procedure p_insert_od_ids as
begin
insert into vt_od_ids (ordersid,ordersdetailid,mtime,oisuse,odisuse)
  select max(t.ordersdetailid), t.ordersid, to_char(o.createtime, 'yyyymmdd'),0,0
   from t_ordersdetail t, t_orders o
  where t.ordersid = o.ordersid
    and  not exists ( select 1 from vt_od_ids vd where o.ordersid=vd.ordersid)
    and o.createtime>trunc(sysdate-1) and  o.createtime<trunc(sysdate)
    group by to_char(o.createtime,'yyyymmdd'),t.ordersid  order by 2;
commit;
end p_insert_od_ids;

/

