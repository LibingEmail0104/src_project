CREATE VIEW V_CITY_EXPRESS AS
  select '02.' || t2.fconfigid  || '.' ||'70053.' || t3.expressid  fz_exp,
       t3.name,
       'true' tru,
       get_cityname(t2.cityid) city
  FROM t_fconfig t2, T_EXPRESS t3
 WHERE t2.fconfigid = t3.fconfigid
 order by 1


/

