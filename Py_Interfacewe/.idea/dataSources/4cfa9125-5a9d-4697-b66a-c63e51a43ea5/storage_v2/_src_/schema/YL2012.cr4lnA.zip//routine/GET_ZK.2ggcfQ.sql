CREATE FUNCTION get_zk (v_ordersdetailid number) return varchar2 is
  v_cname varchar2(40);
begin
 select decode(sum(decode(odp.discount,null,0,odp.discount)),null,0,sum(decode(odp.discount,null,0,odp.discount))) into  v_cname
                  from t_ordersdetail_promos odp
                 where odp.ordersdetailid =v_ordersdetailid
                   and odp.promotypecd  not  in ('10', '910');
  return v_cname;
exception
  when no_data_found then
    return '0' || v_cname;
  when others then
    return '出错了' || v_cname;
end;

/

