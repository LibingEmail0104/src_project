CREATE procedure YL_INDEX_PARALLEL (in_para in varchar2) Authid Current_User
    is
  -- Author  : ZHANGQIANG
  -- Created : 2015/7/28 01:29:27
  -- MODIFY  : 2016/7/28 01:50:00
  -- Purpose :
     CURSOR c1 is select * from user_indexes where index_type!='LOB' ;
    c_c1 c1%rowtype;
begin
  open c1;
  loop
      fetch c1 into c_c1;
      exit  when c1%notfound;
      if in_para !='rebuild'
        then
                 execute immediate 'ALTER INDEX ' ||  c_c1.index_name   || ' parallel '|| in_para;
        else
                  execute immediate 'ALTER INDEX ' ||  c_c1.index_name   ||' '||in_para  || ' parallel  32';
                  execute immediate 'ALTER INDEX ' ||  c_c1.index_name   ||  ' NOPARALLEL';

      end if;
     end loop;
 close c1;
end;

/

