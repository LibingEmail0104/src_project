CREATE VIEW V_YLPW_PRODUCT AS
  select tp.id productid ,tp.name pname ,tp.keyword,tp.starttime,tp.endtime  from YLPW40.PRODUCT tp
/

