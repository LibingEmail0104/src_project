CREATE FUNCTION  get_rangeprice (p_fconfigid varchar) return varchar2 is
  v_rangeprice varchar2(50);
begin
    select efs.rangeprice into v_rangeprice
             from t_expressfeespecial efs,t_province pro
            where pro.provinceid = efs.provinceid
            and efs.fconfigid =p_fconfigid ;
  return v_rangeprice;
end;

/

