CREATE VIEW V_GAIDAN_CW_A AS
  select
       (SELECT get_fcname(fconfigid) FROM T_ORDERS   as of timestamp to_timestamp( TO_CHAR(SYSDATE,'YYYYMMDD')||'090000','YYYYMMDDHH24MISS')  WHERE t.ordersid =  ordersid)  城市,
      (SELECT get_starus(STARUS) FROM T_ORDERS   as of timestamp to_timestamp( TO_CHAR(SYSDATE,'YYYYMMDD')||'090000','YYYYMMDDHH24MISS')  WHERE t.ordersid =  ordersid) 历史状态,

      decode (decode((select tp.paystatus
                from log_t_payment tp
               where t.ordersid = tp.ordersid
                 and mhost = 'MSHOME\ZHANGQIANG' ),
              null,
              (select  paystatus
                 from t_payment  as of timestamp to_timestamp( TO_CHAR(SYSDATE,'YYYYMMDD')||'090000','YYYYMMDDHH24MISS')
                where t.ordersid =  ordersid),
              (select tp.paystatus
                 from log_t_payment tp
                where t.ordersid = tp.ordersid
                  and mhost = 'MSHOME\ZHANGQIANG')),0,'未支付',1,'部分支付',2,'已支付',3,'已退款',4,'等待付款') paystatus  ,




        decode((select tp.paysuccessfultime
                from log_t_payment tp
               where t.ordersid = tp.ordersid
                 and mhost = 'MSHOME\ZHANGQIANG' ),
              null,
              (select  paysuccessfultime
                 from t_payment  as of timestamp to_timestamp( TO_CHAR(SYSDATE,'YYYYMMDD')||'090000','YYYYMMDDHH24MISS')
                where t.ordersid =  ordersid),
              (select tp.paysuccessfultime
                 from log_t_payment tp
                where t.ordersid = tp.ordersid
                  and mhost = 'MSHOME\ZHANGQIANG')) paysuccessfultime,

      get_role(decode((select tp.discount
                from log_t_payment tp
               where t.ordersid = tp.ordersid
                 and mhost = 'MSHOME\ZHANGQIANG')  , null,
                 (select tp.discount
                from t_payment tp
               where t.ordersid = tp.ordersid), (select tp.discount
                from log_t_payment tp
               where t.ordersid = tp.ordersid
                 and mhost = 'MSHOME\ZHANGQIANG')))||

        get_rank( decode((select tp.discountdetailid
                from log_t_payment tp
               where t.ordersid = tp.ordersid
                 and mhost = 'MSHOME\ZHANGQIANG')  , null,
                 (select tp.discountdetailid
                from t_payment tp
               where t.ordersid = tp.ordersid), (select tp.discountdetailid
                from log_t_payment tp
               where t.ordersid = tp.ordersid
                 and mhost = 'MSHOME\ZHANGQIANG')))  支付方式 ,
       t.ordersid,
        decode((select tp.paysuccessfultime
                from log_t_payment tp
               where t.ordersid = tp.ordersid
                 and mhost = 'MSHOME\ZHANGQIANG' ),
              null,
              (select  paysuccessfultime
                 from t_payment  as of timestamp to_timestamp( TO_CHAR(SYSDATE,'YYYYMMDD')||'160000','YYYYMMDDHH24MISS')
                where t.ordersid =  ordersid),
              (select tp.paysuccessfultime
                 from log_t_payment tp
                where t.ordersid = tp.ordersid
                  and mhost = 'MSHOME\ZHANGQIANG')) paysuccessfultime2,
                ( select        get_starus(STARUS) from t_orders as of timestamp to_timestamp( TO_CHAR(SYSDATE,'YYYYMMDD')||'160000','YYYYMMDDHH24MISS')  where t.ordersid=ordersid)   订单当前状态,
               get_role( (select  discount   from t_payment as of timestamp to_timestamp( TO_CHAR(SYSDATE,'YYYYMMDD')||'160000','YYYYMMDDHH24MISS')      where t.ordersid =  ordersid) ) ||
               get_rank( (select  discountdetailid   from t_payment as of timestamp to_timestamp( TO_CHAR(SYSDATE,'YYYYMMDD')||'160000','YYYYMMDDHH24MISS')    where t.ordersid =  ordersid)) 订单当前支付方式


  from log_t_payment T
 where mhost = 'MSHOME\ZHANGQIANG'
   and to_char(logtime, 'yyyymmdd') = to_char(sysdate, 'yyyymmdd')


/

