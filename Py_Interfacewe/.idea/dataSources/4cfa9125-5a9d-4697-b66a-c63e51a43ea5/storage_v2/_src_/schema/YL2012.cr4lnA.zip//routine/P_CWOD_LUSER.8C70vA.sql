CREATE PROCEDURE P_cwod_luser is
  --定义游标
  cursor c_ci is
  select ordersdetailid from   vt_od_ids where odisuse=1   ;
  r_ci c_ci % rowtype;
  --判断循环次数
  v_index number := 0;
begin
  --判断游标是否打开
  if c_ci%isopen then
    null;
  else
    open c_ci;
  end if;

  loop
    fetch c_ci
      into r_ci;
    exit when c_ci%notfound;

 update t_ordersdetail od set  od.integral=0,od.hostdiscount=null,od.discountdetailidorganizer=null
where od.ordersdetailid=r_ci.ordersdetailid;




    --分段提交
    v_index := v_index + 1;
    if (v_index = 1000) then
      commit;
      v_index := 0;
    end if;
  end loop;

   commit;

  close c_ci;
end P_cwod_luser;

/

