CREATE VIEW TV_CWPZ_ORDERS_ONE AS
  select "ORDERSID","ORDERSID2","PRODUCTID","STARUS","PAYSTATUS","PDTOTAL" from tv_cwpz_orders t where not exists (
select 1 from tv_cwpz_orders t1 where t1.ordersid2 is null  and t.ordersid=t1.ordersid)
/

