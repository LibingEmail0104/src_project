CREATE FUNCTION "GET_DEPT" (oname varchar2) return varchar2 is
  v_dept varchar2(50);
begin
    select t2.name into v_dept from T_ADMINUSER t1, T_DEPARTMENT t2 where t1.departmentid=t2.departmentid and t1.uname=oname;
  return v_dept;
EXCEPTION
when Too_many_rows
then
        return oname;
end;

/

