CREATE VIEW V_YLPW_PRODUCT_PLAY AS
  select  pp.id productplayid,pp.product_id productid ,pp.playdate,pp.playtime,pp.price,pp.describe playinfo,pp.product_name,pp.place_name vname  from  YLPW40.PRODUCT_PLAY pp
/

