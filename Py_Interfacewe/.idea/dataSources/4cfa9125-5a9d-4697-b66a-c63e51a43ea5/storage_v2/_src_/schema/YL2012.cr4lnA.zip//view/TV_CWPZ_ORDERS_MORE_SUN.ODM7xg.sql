CREATE VIEW TV_CWPZ_ORDERS_MORE_SUN AS
  select "ORDERSID","ORDERSID2","PRODUCTID","STARUS","PAYSTATUS","PDTOTAL" from (
select * from tv_cwpz_orders t where   exists (
select 1 from tv_cwpz_orders t1 where t1.ordersid2 is null  and t.ordersid=t1.ordersid)
) where ordersid2 is null
/

