CREATE FUNCTION get_yh (v_ordersdetailid number) return varchar2 is
  v_cname varchar2(40);
begin
 select wm_concat(os.promoname||':'||trunc(os.discount_rate*10,3)||'折')  into v_cname from t_ordersdetail_promos os where  os.ordersdetailid=v_ordersdetailid;

  return v_cname;
exception
  when no_data_found then
    return '' || v_cname;
  when others then
    return '出错了' || v_cname;
end;

/

