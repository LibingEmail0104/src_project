CREATE VIEW V_FZ_PLAY AS
  select VC.fz AS 分公司,
       decode(VC.cityname,null,get_fcname(p.fconfigid),VC.cityname) AS 城市,
       '01.' || p.fconfigid || '.' || pta.producttypeaid || '.' ||
       ptb.producttypebid || '.' || p.productid 编码,
       p.name as 项目名称,
       'true' 明细,
       '' 审核人_FName,
       '-1' 控制,
       '0' 是否禁用,
       '' 全球唯一标识内码,
       vc.fconfigid as 分站编码,
       vc.cityname as 分站名称,
       pta.producttypeaid as 项目大类编码,
       pta.name as 项目大类名称,
       ptb.producttypebid as 项目小类编码,
       ptb.name as 项目小类名称,
       p.productid as 项目编码,
        p.createtime,
        p.begindate,
        P.ENDDATE
  from t_product      p,
       t_producttypea pta,
       t_producttypeb ptb,
     /*  t_fconfig      fc,
       t_city         ci,*/
       V_COMPANY      VC
 where p.producttypeaid1 = pta.producttypeaid
   and p.producttypebid1 = ptb.producttypebid
   and p.fconfigid = vc.fconfigid(+)
      /* and p.fconfigid in  (131051
      ,51844107
      ,2870000
      ,5214250
      ,62124540)*/
   /*and p.createtime >= to_date('20140601 00:00:01', 'yyyymmdd hh24:mi:ss')
   and p.createtime <= to_date('20150303 23:59:59', 'yyyymmdd hh24:mi:ss')*/
 order by 1, 2
/

