CREATE PROCEDURE PZ_ins_pmd (v_ordersid in number,v_date in varchar2,v_pay in number,v_payno in varchar2,v_discount number,v_discountdetail number)
as
   cursor c_one is
  select *  from t_payment t where t.ordersid=v_ordersid;
  r_one c_one % rowtype;
  v_row number;
  v_id number;
 begin
   if c_one%isopen then
    null;
  else
    open c_one;
  end if;

    fetch c_one into r_one;
    select seq_a.nextval into v_id from dual;

savepoint  point_a;

insert into t_payment_detail
  (ID,
   PAYMENT_ID,
   ORDER_ID,
   ORIGINAL_FEE,
   ACTUAL_FEE,
   DISCOUNT,
   DISCOUNTDETAILID,
   PAYMENT_STATUS,
   TRADE_CREATE_TIME,
   TRADE_FINISH_TIME,
   THIRD_TRADE_NO,
   BUYER_EMAIL,
   GMT_CREATE,
   DISCOUNTVALUE,
   LAST_TIME,
   LAST_USERS,
   ORDER_SUBJECT,
   ORDER_BODY,
   ORDER_SHOW_URL,
   EXPIRE_TIME,
   RETURN_URL,
   ERROR_URL,
   REQUEST_CHANNEL,
   REQUEST_SOURCE,
   REQUEST_PARTNER,
   CARDNO,
   ORIGINAL_DISCOUNT_FEE,
   PAY_DISCOUNT_FEE,
   PAYDETAILINFO,
   RETRY_TIME)
values
  (v_id,
   r_one.paymentid,
   v_ordersid,
   v_pay,
   v_pay,
   v_discount,
   v_discountdetail,
   1,
   to_date(v_date, 'yyyy-mm-dd hh24:mi:ss'),
   to_date(v_date, 'yyyy-mm-dd hh24:mi:ss'),
   v_payno,
   null,
   to_date(v_date, 'yyyy-mm-dd hh24:mi:ss'),
   null,
    to_date(v_date, 'yyyy-mm-dd hh24:mi:ss'),
   'xx',
   'xx',
   '',
   'http://www.228.com.cn/',
    to_date(v_date, 'yyyy-mm-dd hh24:mi:ss'),
   '',
   '',
   '',
   '',
   '',
   null,
   v_pay,
   0.00,
   null,
   null);
 v_row :=SQL%ROWCOUNT ;
dbms_output.put_line('明细插入     行数：  '||v_row);

 if v_row>1 then
    rollback to savepoint point_c;
  end if;


savepoint  point_b;
update t_payment  t set t.paystatus=2, t.isselect  =1,t.paysuccessfultime=to_date(v_date, 'yyyy-mm-dd hh24:mi:ss') where  ordersid=v_ordersid;
 v_row :=SQL%ROWCOUNT ;
dbms_output.put_line('支付更新     行数：  '||v_row);
 if v_row>1 then
    rollback to savepoint point_c;
  end if;


savepoint  point_c;
  update t_orders t set t.starus=2 ,t.ISCHANGEMONEY=1   where  ordersid=v_ordersid;
 v_row :=SQL%ROWCOUNT ;
dbms_output.put_line('订单更新     行数：  '||v_row);
 if v_row>1 then
    rollback to savepoint point_c;
  end if;

  close c_one;
commit;

 exception
  when others then
    rollback to  savepoint point_a;
    close c_one;
    RAISE_APPLICATION_ERROR(-20010, '插入失败,更新回滚');
end;

/

