CREATE FUNCTION get_actual_fee (p_id  number) return number is
  v_actual_fee number;
begin
  select actual_fee  into v_actual_fee
       from t_payment_detail
 where id = p_id ;
  return v_actual_fee;
  EXCEPTION
         WHEN NO_DATA_FOUND THEN
       return '00';
end;

/

