CREATE package YL_AUTO_ORDER is

  -- Author  : TANLING,ZHANGQIANG
  -- Created : 2015/6/11 9:29:27
  -- MODIFY  : 2016/7/2 19:04:00
  -- Purpose :

  procedure YL_ORDER_INSERT(IN_PRODUCTID  T_PRODUCT.PRODUCTID%TYPE,
                            IN_TOTALPRICE in number,
                            IN_PAYTYPE    in number,
                            --IN_DISCOUNTID       T_DISCOUNT.DISCOUNTID%TYPE,
                            --IN_DISCOUNTDETAILID T_DISCOUNTDETAIL.DISCOUNTDETAILID%TYPE,
                            IN_ORDERSOURCE T_ORDERS.ORDERSOURCE%TYPE,
                            in_customersid      t_customers.customersid%TYPE ,
                            IN_ORDER_DATE DATE
                            );

end YL_AUTO_ORDER;

/

