CREATE VIEW V_PD_EXPRESS AS
  select get_cityname(t1.cityid) cityname,t.customersid,t3.expressid,t.truename, t3.name, amount 赊销额度,renewal 预存款,decode(sign(amount),1,'可','不可') 是否可赊销
  from t_customers t, t_fconfig t1 ,T_EXPRESS t3
 where t.truename like 'PD%'
   and t.fconfigid = t1.fconfigid(+)
      and t.fconfigid=t3.fconfigid(+)
   order by 1


/

