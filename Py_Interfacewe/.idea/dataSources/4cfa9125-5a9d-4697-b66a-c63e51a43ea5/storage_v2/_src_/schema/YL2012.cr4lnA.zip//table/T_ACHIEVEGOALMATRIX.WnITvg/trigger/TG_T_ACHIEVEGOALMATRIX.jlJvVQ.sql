CREATE TRIGGER TG_T_ACHIEVEGOALMATRIX
  BEFORE INSERT
  ON T_ACHIEVEGOALMATRIX
  FOR EACH ROW
  begin   --触发器主题
  select seq_t_achievegoalmatrix.nextval into:new.achievegoalmatrixid from dual;   --调用创建的list_seq序号
end tg_t_achievegoalmatrix;




/

