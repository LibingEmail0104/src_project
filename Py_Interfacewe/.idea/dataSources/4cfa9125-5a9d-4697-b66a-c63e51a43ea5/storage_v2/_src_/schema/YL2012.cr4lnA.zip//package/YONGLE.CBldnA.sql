CREATE package yongle
is
 --根据订单id查询支付方式明细
 function pd(oid number) return varchar2;
 --获取订单支付方式：oid 订单Id, payStatus 支付状态, showType 显示格式 ZhaoHb2016.11.11
 function pmd(oid number, payStatus number, showType number) return varchar2;
 function upd(oid number,discount number) return varchar2;
 function hostdiscount(odid number) return number;
 function userdiscount(odid number) return number;
 function uniondiscount(odid number) return number;
 function actualfee(did number,oid number) return number;
  --根据订单id查询支付成功时间
/* function pt(oid number) return varchar2;*/
end yongle;

/

