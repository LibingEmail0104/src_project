CREATE PROCEDURE          "P_UPDATE_SPREADSOURCE" as
begin
  --修改百度来源
  update t_orders t
     set t.spreadsource = 'baidu'
   where t.spreadsource = '#baidu#';
  --修改百度来源
  update t_orders t
     set t.spreadsource = '360'
   where t.spreadsource = '#360#';
  --修改edm来源
  update t_orders t
     set t.spreadsource = 'edm'
   where t.spreadsource = '#edm#';
  --修改gjdjy来源
  update t_orders t
     set t.spreadsource = 'gjdjy'
   where t.spreadsource = '#gjdjy#';
  --修改google来源
  update t_orders t
     set t.spreadsource = 'google'
   where t.spreadsource = '#google#';
  --修改sogou来源
  update t_orders t
     set t.spreadsource = 'sogou'
   where t.spreadsource = '#sogou#';
  --修改soso来源
  update t_orders t
     set t.spreadsource = 'soso'
   where t.spreadsource = '#soso#';
  --修改tieba来源
  update t_orders t
     set t.spreadsource = 'tieba'
   where t.spreadsource = '#tieba#';
  --修改renyi来源
  update t_orders t
     set t.spreadsource = 'renyi'
   where t.spreadsource = '#renyi#';
  --修改shoudu来源
  update t_orders t
     set t.spreadsource = 'shoudu'
   where t.spreadsource = '#shoudu#';

  commit;

end;




/

