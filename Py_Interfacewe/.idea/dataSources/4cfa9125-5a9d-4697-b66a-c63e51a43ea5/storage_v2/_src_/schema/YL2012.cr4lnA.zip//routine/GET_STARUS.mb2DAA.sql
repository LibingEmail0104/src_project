CREATE FUNCTION "GET_STARUS" (starus number) return varchar2 is
  v_starus varchar2(50);
begin
  v_starus := case starus

                when 1 then
                 '未审核'
                when 2 then
                 '已审核'
                when 3 then
                 '配票中'
                when 4 then
                 '发货中'
                when 5 then
                 '已发货'
                when 6 then
                 '已完成'
                when 7 then
                 '无效'
                when 8 then
                 '已退票'
                when 9 then
                 '已处理'
                when 10 then
                 '用户已删除'
                when 11 then
                 '审核至前台'
                when 12 then
                 '无票'
                when 13 then
                 '退票中'
                when 15 then
                 '退款中'
                when 16 then
                 '退款已审核'
                when 17 then
                 '已退款'
                when 18 then
                 '退票、退款中'
                when 19 then
                 '已退票、退款中'
                when 20 then
                 '已退票、退款已审核'
                when 21 then
                 '已退票、已退款'
                else
                 '未知状态'
              end;
  return v_starus;
end;






/

