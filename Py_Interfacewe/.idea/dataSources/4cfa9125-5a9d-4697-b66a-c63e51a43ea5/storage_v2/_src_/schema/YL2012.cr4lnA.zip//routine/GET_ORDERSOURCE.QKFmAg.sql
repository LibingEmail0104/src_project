CREATE function get_ordersource(ordersource number) return varchar2 is
  v_ordersource varchar2(50);
begin
  v_ordersource := case ordersource
-- 1:电话,2:网络,3:票务前台用户,4:票务前台票点,50:联盟,60:乐票通,70:IOS,80:ANDROID,90:WAP';
                when 1 then
                 '电话'
                when 5 then
                 '电话'
                when 2 then
                 '网络'
                when 3 then
                 '票点前台用户'
                when 4 then
                 '票务前台票点'
                when 50 then
                 '联盟'
                when 60 then
                 '乐票通'
                when 70 then
                 'IOS'
                when 80 then
                 'ANDROID'
                when 90 then
                 'WAP'
                else
                 '未知状态'
              end;
  return v_ordersource;
end;

/

