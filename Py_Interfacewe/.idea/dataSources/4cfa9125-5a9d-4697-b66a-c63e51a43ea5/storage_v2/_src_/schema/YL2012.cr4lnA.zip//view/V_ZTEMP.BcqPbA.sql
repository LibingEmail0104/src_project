CREATE VIEW V_ZTEMP AS
  select   '01.' || f.fconfigid || '.' || ta.producttypeaid || '.' ||
       tb.producttypebid || '.' || p.productid codes,
       get_ordersource(o.ordersource) 来源,
       od.ORDERSDETAILID 订单明细ID,
       get_payfgs(od.ordersdetailid) 分公司,
       city.cityname 城市,
       o.ordersid 订单号,
       c.customersid 用户ID,
       o.lnvoice 发票抬头,
       o.writecheck 是否已开发票,
       c.email 用户邮箱,
       o.BACKMONEYDATE 回款日期,
       o.DELIVERYDATE 发货时间,
       warehousedate 实际发货时间,
       o.createtime 订单创建时间,
       o.lasttime 最后修改时间,
       get_starus(o.starus) 订单状态,
       get_paystatus(pm.paystatus) 支付状态,
       addr.username 收货人,
       addr.phone 收货人手机号,

       decode(o.PSXX, 1, '快递配送', 2, '上门自取', 4, '电子票', '其他') 配送方式,
       ta.name 商品分类,
       tb.name 商品小类,
       decode(p.status,
              0,
              '售票中',
              1,
              '预售',
              2,
              '无效',
              3,
              '待定',
              4,
              '售完',
              5,
              '延期',
              6,
              '取消',
              7,
              '已结束') 商品状态,

       p.productid 商品ID,
       p.name 商品名称,
       v.vname 场馆名称,
       tcode.name 出票系统,
       decode(pp. playdate, null, pp.time, pp.playdate) 演出时间,
       p.begindate 演出开始时间,
       p.enddate 演出结束时间,
       p.enddate - p.begindate 周期,
       pp.PRICE 票价,
       pp.playinfo 票价说明,
       od.NUM 数量,
       od.YTOTAL 票面款,
       od.YTOTAL - (od.YTOTAL * od.HOSTDISCOUNT * 0.01 *
       od.customerdiscount * 0.01 * pm.discountpay * 0.01) 折扣金额,
       od.HOSTDISCOUNT 折扣优惠,
       pp.PRICE * od.NUM *
       (1 - decode(od.HOSTDISCOUNT, null, 100, od.HOSTDISCOUNT) / 100) 优惠损失,
       decode(c.type,
              0,
              decode(od.customerdiscount, null, 100, od.customerdiscount),
              1,
              decode(od.discount, null, 100, od.discount),
              100) as 折扣, --主办折扣
       pp.PRICE * od.NUM *
       (1 -
       decode(c.type,
               0,
               decode(od.customerdiscount, null, 100, od.customerdiscount),
               1,
               decode(od.discount, null, 100, od.discount),
               100) / 100) 折扣损失,
       pm.discountpay 支付折扣,     GET_payways( tpd.order_id ) 支付方式,
     GET_payways2( tpd.order_id ) 支付方式加金额,
       te.name         快递,
       te.EXPRESSID    快递号,
       o.ISENDTIME     取票时间,
       o.UNIONORDERSID 联盟单号,
       ty.ENDTIME      异常结束时间,
       o.MATCHINGTIME  配票时间,
        get_province(addr.provinceid) ||
       get_cityname(addr.cityid) ||
       get_areaname(addr.areaid) ||
       addr.NAME as 收货地址,
       o.financeinfo ,
       o.oldordersid
  from t_orders       o,
       t_ordersdetail od,
       t_customers    c,
       t_address      addr,
       t_productplay  pp,
       t_producttypea ta,
       t_product      p,
       t_venues       v,
       t_payment      pm,
       t_fconfig      f,
       t_city         city,
        t_producttypeb   tb,
       t_office         tof,
       t_code           tcode,
       T_EXPRESS        te,
       T_ORDERANOMALY   ty,
       t_payment_detail tpd
 where o.ordersid = od.ordersid
   and o.customersid = c.customersid
   and o.addressid = addr.addressid(+)
   and p.productid = pp.productid
   and od.productplayid = pp.productplayid
   and p.producttypeaid1 = ta.producttypeaid
   and p.venuesid = v.venuesid
   and o.ordersid = pm.ordersid
   and o.fconfigid = f.fconfigid
   and f.cityid = city.cityid
   and p.producttypebid1 = tb.producttypebid
   and p.OFFICE = tof.officeid(+)
   and p.codeid = tcode.codeid(+)
   and o.EXPRESSNAME = te.expressid(+)
   and o.ordersid = ty.ordersid(+)
   and tpd.payment_id(+) = pm.paymentid
/

