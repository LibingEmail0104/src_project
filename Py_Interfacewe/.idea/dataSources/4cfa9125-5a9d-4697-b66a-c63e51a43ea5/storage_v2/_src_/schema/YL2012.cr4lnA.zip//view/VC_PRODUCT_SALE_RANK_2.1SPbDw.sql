CREATE VIEW VC_PRODUCT_SALE_RANK_2 AS
  select p.fconfigid,
       city.cityname,
       p.producttypeaid1,
       pta.name ptaname,
       p.productid,
       p.status as pStatus,
       decode(p.status, 0, '售票中', 1, '预售', 2, '无效', 3, '待定', 4, '售完', 5, '延期', 6, '取消', 7, '已结束') as proStatus,
       p.name pname,
       v.venuesid,
       v.vname,
       --trim(TO_CHAR(pp.playdate, 'YYYY-MM-DD') || ' ' || pp.time) as playtime,不按演出时间分组，这边只给商品演出时间范围即可
       --p.begindate||'至'||p.enddate as playtime,
       trim(TO_CHAR(p.begindate, 'YYYY-MM-DD') ||'至'|| TO_CHAR(p.enddate, 'YYYY-MM-DD')) as playtime,
       p.display,
       --pp.starus as ppStatus,
       p.codeid,
       cd.name cdname,
       sum(od.total) total,
       get_ordersource(o.ordersource) ordersource,
       o.createtime ,
       o.ordersid
  from t_orders       o,
       t_payment      pay,
       t_ordersdetail od,
       t_productplay  pp,
       t_product      p,
       t_fconfig      ff,
       t_city         city,
       t_venues       v,
       t_producttypea pta,
       t_code         cd
 where o.ordersid = od.ordersid
       and  o.createtime > trunc(sysdate)
   and o.createtime <= trunc(sysdate + 1)
   and o.ordersid = pay.ordersid
   and od.productplayid = pp.productplayid
   and pp.productid = p.productid
   and p.fconfigid = ff.fconfigid
   and ff.cityid = city.cityid
   and p.venuesid = v.venuesid
   and p.producttypeaid1 = pta.producttypeaid
   and p.codeid = cd.codeid
   --and o.starus in (2, 3, 4, 5, 6, 11)
   and o.starus in (1, 2, 3, 4, 5, 6, 9, 11)     --2015年10月12号，按新新需求更改
   --and o.ordersource in (1,2,3,4,50,60,70,80,90) --2016年2月18号，按新新需求更改
   --and (o.psxx in (1, 4) or (o.psxx = 2 and pay.paystatus = 2 and o.ordersource !=3) or (o.psxx =2 and o.ordersource = 3))
   and ((o.psxx in (1, 4) and pay.paystatus = 2) or (pay.discount in (70053) and pay.paystatus = 0) or (o.psxx = 2 and pay.paystatus = 2 and o.ordersource !=3) or (o.psxx =2 and o.ordersource in (3, 4)))    --2015年10月12号，按新新需求更改
 group by p.fconfigid,
       city.cityname,
       p.producttypeaid1,
       pta.name,
       p.productid,
       p.status,
       decode(p.status, 0, '售票中', 1, '预售', 2, '无效', 3, '待定', 4, '售完', 5, '延期', 6, '取消', 7, '已结束'),
       p.name,
       v.venuesid,
       v.vname,
       --trim(TO_CHAR(pp.playdate, 'YYYY-MM-DD') || ' ' || pp.time),
       --p.begindate||'至'||p.enddate,
       trim(TO_CHAR(p.begindate, 'YYYY-MM-DD') ||'至'|| TO_CHAR(p.enddate, 'YYYY-MM-DD')),
       p.display,
       --pp.starus,
       p.codeid,
       cd.name,
       get_ordersource(o.ordersource),
       o.createtime,  o.ordersid

/

