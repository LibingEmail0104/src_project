CREATE FUNCTION "GET_ZNAME" (oname varchar2) return varchar2 is
  v_name varchar2(50);
begin
    select  name into v_name from T_ADMINUSER where uname=oname;
  return v_name;
EXCEPTION
when Too_many_rows
then
        return oname;
end;

/

