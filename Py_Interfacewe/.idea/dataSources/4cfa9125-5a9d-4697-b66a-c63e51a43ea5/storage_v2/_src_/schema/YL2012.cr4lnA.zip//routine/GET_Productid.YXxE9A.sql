CREATE FUNCTION "GET_Productid" (odid number)
  return NUMBER is
  Productid number;
begin
  select tp.productid
    into Productid
    from T_PRODUCT tp,T_PRODUCTPLAY tpa,T_ORDERSDETAIL tod
   where   tod.productplayid=tpa.productplayid
   and tpa.productid=tp.productid
   and tod.ordersdetailid=odid;
  return Productid;
exception
  when no_data_found then
    return '未知' || v_ctiyid;
  when others then
    return '出错了' || v_ctiyid;
end;



/

