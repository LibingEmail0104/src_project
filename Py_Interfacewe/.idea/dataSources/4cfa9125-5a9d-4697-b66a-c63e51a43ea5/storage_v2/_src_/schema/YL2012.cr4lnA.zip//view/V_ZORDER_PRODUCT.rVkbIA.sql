create view V_ZORDER_PRODUCT as
select
       o.ordersid  as ordersid,
      '01.' || f.fconfigid || '.' || ta.producttypeaid || '.' ||tb.producttypebid || '.' || p.productid codes,
        od.ORDERSDETAILID,
       od.NUM,
       p.productid as productid,
       od.Productplayid,
       p.status,
       p.name pname,
     decode(TICKETTYPE, '1','提票' , '2','系统出票',    '3','现票') piaolei,


    decode(p.status,0,'售票中',1,'预售',2,'无效',3,'待定',4,'售完',5,'延期',6,'取消',7,'已结束') pstatus,


        tcode.name zhuban,
       pp.PRICE price,
       pp.playinfo,
       pp.xzpriceid spid,
       decode(o.PSXX,1,'快递配送',2,'上门自取',4,'电子票','其他') peisong,
       decode(pp. playdate,null,pp.time,to_char(pp.playdate,'yyyy-mm-dd ')||pp.time)   ptime,
         decode(pp. playdate, null, pp.time, pp.playdate) PLAYDATE,
       p.begindate,
       p.enddate,
       ta.name typea,
       tb.name typeb,
       p.fconfigid,
       tl.name  大区,
       city.cityname,
       v.vname as location,
       tof.name ting,
       c.customersid as customer_id,
       o.unionid,
     c.TRUENAME as CNAME,
       decode(C.TYPE,0,'用户',1,'票点',2,'联盟',3,'新联盟'，'其他') ctype,
       o.UNIONID  as 联盟ID,
       get_uname(o.UNIONID) as 联盟名称,
       o.UNIONORDERSID  as 联盟订单流水,
       o.createtime as mtime,
       o.DELIVERYDATE  sendtime,
       o.DZPHONE,
       decode(o.isend,1,'是',0,'否','未知') 是否取票,
       o.lastuser,
       o.lasttime,
       decode(o.ADDRESSID,0,'自取','配送上上门') sendway,
       get_starus(o.starus) starus,
       o.starus  dstatus,
       decode(o.TYPE,0,'普通','1','选座','20','抢座','未知') as seat_type,
       od.seat,
     --  get_ordersource(o.ordersource) order_source,
        o.ordersource  order_source,

       decode(o.PROTYPE,1,'预售',2,'热卖','未知') as product_type,
       get_paystatus(pm.paystatus) paystatus,
       pm.paysuccessfultime,
        decode(pm.discount,
 70049           ,o.DELIVERYDATE,
  62923793       ,o.DELIVERYDATE,
  63046930    ,o.DELIVERYDATE,
  62923783    ,o.DELIVERYDATE,
  70053     ,o.ISMODIFTIME,
  70054     ,o.createtime,
  1613300    ,o.createtime,
  70057       ,o.createtime,
  70055     ,pm.paysuccessfultime,
  77650     ,pm.paysuccessfultime,
 2341200     ,o.createtime,
 70056        ,pm.paysuccessfultime,o.createtime) cw_paysuccessfultime,

       pm.dealtime  支付序列号,
       pp.PRICE  as 票价,
       pp.playinfo 票价说明,
       od.YTOTAL ,    -- 票面款
       od.TOTAL  ,    -- 票面款折扣后
       GET_payways( o.ordersid ) 支付方式,
     GET_payways2( o.ordersid ) 支付方式金额,
    --   od.ytotal - od.total as lostcount,
   --   pp.PRICE*od.NUM*(1-decode(c.type,0,decode(od.customerdiscount,null,100,od.customerdiscount),1,decode(od.discount, null,100,od.discount),100)/100) lostcount,
       decode(pm.ysprice, null, 0, pm.ysprice) as yingshou,
     --  decode(pm.ljprice, null, 0, pm.ljprice) as lijuan,
    --   decode(pm.lpkprice, null, 0, pm.lpkprice) as lipinka,
       decode(pm.yckprice, null, 0, pm.yckprice) as yucun,
       decode(pm.sjzfprice, null, 0, pm.sjzfprice) as shishou,
       o.BACKMONEYDATE,
       o.MATCHINGTIME 配票时间,
              ty.ENDTIME      异常结束时间,
    --   pm.insuredamount   baofei,
       decode(od.hostdiscount, null, 100, od.hostdiscount) as host_discount,   --优惠折扣
       pm.discountpay  pay_discount,                                                                   --折扣
       c.phone  as CPHONE,
       c.email  as CMAIL,
     c.CREATETIME ctime,
       c.customersid as cid,
       addr.addressid,
     addr.username name,
       addr.phone,
       addr.email,
      get_province(addr.provinceid)  as 收货省,
       get_cityname(addr.cityid) as  收货城市,
       get_areaname(addr.areaid)  as 收货区 ,
       addr.NAME as 收货地址,

         get_province(addr.provinceid)  ||
       get_cityname(addr.cityid) ||
       get_areaname(addr.areaid) ||
       addr.NAME as 地址,
    /*    (case
         when (row_number() over(partition by o.ordersid order by o.rangeprice)) = 1 then
          o.rangeprice
         else
          null
       end) */

        o.rangeprice 运费,
       te.name   快递,
       o.expressno 快递单号,
     get_tuiguang(o.spreadsource) 推广来源,
       COMPANYINFO 备注,
       clientinfo  用户备注
       from t_orders       o,
       t_ordersdetail od,
       t_ordersdetail_promos top,
       t_customers    c,
       t_address      addr,
       t_productplay  pp,
       t_producttypea ta,
       t_product      p,
       t_venues       v,
       t_payment      pm,
    --   t_payment_detail pmd,
       t_fconfig      f,
       t_city         city,
         t_producttypeb  tb,
       t_office        tof,
       t_code           tcode,
       T_EXPRESS        te,
       t_largearea      tl,
       T_ORDERANOMALY   ty
  where o.ordersid = od.ordersid
   and o.customersid = c.customersid
   and o.addressid = addr.addressid(+)
   and p.productid = pp.productid
   and od.productplayid = pp.productplayid
   and p.producttypeaid1 = ta.producttypeaid
   and p.venuesid = v.venuesid
   and o.ordersid = pm.ordersid
   and o.fconfigid = f.fconfigid
   and f.cityid = city.cityid
    and p.producttypebid1  = tb.producttypebid
   and p.OFFICE=tof.officeid(+)
   and p.codeid = tcode.codeid(+)
   and o.EXPRESSNAME=te.expressid(+)
   and tl.id(+)=f.districtid
   and od.ordersdetailid=top.ordersdetailid(+)
      and o.ordersid = ty.ordersid(+)

--       and pm.paymentid=pmd.payment_id(+)
/

