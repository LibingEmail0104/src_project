CREATE procedure p_mf_productplay_his
as
begin
insert into mf_productplay_history   select * from mf_productplay where showdate<trunc(sysdate-1/24);
delete from mf_productplay t  where  showdate<trunc(sysdate-1/24) ;
commit;
exception
  when others then
    rollback;
    RAISE_APPLICATION_ERROR(-20010, 'JOB FILED');
end;

/

