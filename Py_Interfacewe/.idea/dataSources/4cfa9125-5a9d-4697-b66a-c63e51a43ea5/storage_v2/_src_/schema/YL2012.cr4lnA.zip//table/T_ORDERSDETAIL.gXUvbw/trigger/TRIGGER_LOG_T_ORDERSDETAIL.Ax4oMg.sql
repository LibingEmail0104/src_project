CREATE TRIGGER TRIGGER_LOG_T_ORDERSDETAIL
  AFTER UPDATE OR DELETE
  ON T_ORDERSDETAIL
  FOR EACH ROW
  begin
  insert into log_t_ordersdetail
    (ordersdetailid,
     ordersid,
     productplayid,
     price,
     num,
     total,
     giftid,
     ticket,
     hostdiscount,
     integral,
     seat,
     system,
     createtime,
     lasttime,
     lastuser,
     discountdetailid,
     papernumber,
     discount,
     customerdiscount,
     discountdetailidteamwork,
     discountdetailidorganizer,
     insuredstatus,
     insuredtotal,
     ytotal,
     settlementstatus,
     logtime,
      integralmultiple  ,
      yltouserdiscount  ,
       jsdiscount,
        mhost)
  values
    (:old.ORDERSDETAILID,
     :old.ORDERSID,
     :old.PRODUCTPLAYID,
     :old.PRICE,
     :old.NUM,
     :old.TOTAL,
     :old.GIFTID,
     :old.TICKET,
     :old.HOSTDISCOUNT,
     :old.INTEGRAL,
     :old.SEAT,
     :old.SYSTEM,
     :old.CREATETIME,
     :old.LASTTIME,
     :old.LASTUSER,
     :old.DISCOUNTDETAILID,
     :old.PAPERNUMBER,
     :old.DISCOUNT,
     :old.CUSTOMERDISCOUNT,
     :old.DISCOUNTDETAILIDTEAMWORK,
     :old.DISCOUNTDETAILIDORGANIZER,
     :old.INSUREDSTATUS,
     :old.INSUREDTOTAL,
     :old.YTOTAL,
     :old.settlementstatus,
     sysdate,
      :OLD.integralmultiple  ,
      :OLD.yltouserdiscount  ,
      :OLD.jsdiscount,
      SYS_CONTEXT('USERENV', 'HOST'));
end;



/

