create view V_CAIWU2 as
select
       o.ordersid  as ordersid,
       od.ORDERSDETAILID,
       c.TRUENAME as CNAME,
       p.productid as productid,
       p.status,
       p.enddate,
       p.name pname,
       pp. playdate   ptime,
       ta.name typea,
       p.fconfigid,
       city.cityname,
       v.vname as location,
       c.customersid as customer_id,
       c.phone  as CPHONE,
       c.email  as CMAIL,
       decode(C.TYPE,0,'用户',1,'票点',2,'联盟',3,'新联盟'，'其他') ctype,
       c.CREATETIME ctime,
       o.UNIONID  as 联盟ID,
       o.UNIONORDERSID  as 联盟订单流水,
       o.createtime as mtime,
       o.DELIVERYDATE  sendtime,
       decode(o.isend,1,'是',0,'否','未知') 是否取票,
       o.lastuser kefu,
       decode(o.ADDRESSID,0,'自取','配送上上门') sendway,
       get_starus(o.starus) starus,
       decode(o.TYPE,0,'普通','1','选座','20','抢座','未知') as seat_type,
       get_ordersource(o.ordersource) order_source,
       decode(o.PROTYPE,1,'预售',2,'热卖','未知') as product_type,   --待完善
       addr.username name,
       addr.phone,
       addr.email,
       get_province(addr.provinceid)  as 收货省,
       get_cityname(addr.cityid) as  收货城市,
       get_areaname(addr.areaid)  as 收货区 ,
       addr.NAME as 收货地址,
       get_paystatus(pm.paystatus) paystatus,
       pp.PRICE  as 票价,
       od.YTOTAL ,    -- 票面款
       od.TOTAL  ,
      -- o.YTOTAL ,    -- 票面款
      -- o.ZTOTAL,     --         应收
       pm.ysprice as 订单应收,
       pm.sjzfprice as 订单实收,
       --pm.PAYSUCCESSFULTIME  as 支付时间,
       dis.role,
       disd.rank,
       nvl( decode(dis.discountid,
                      70053,
                      o.deliverydate,
                      70049,
                     o.deliverydate,
                     pm.paysuccessfultime),o.createtime)     paysuccessfultime
  from t_orders       o,
       t_ordersdetail od,
       t_customers    c,
       t_address      addr,
       t_productplay  pp,
       t_producttypea ta,
       t_product      p,
       t_venues       v,
       t_payment      pm,
       t_fconfig      f,
       t_city         city,
       t_discount     dis,
       t_discountdetail  disd
 where o.ordersid = od.ordersid
   and o.customersid = c.customersid
   and o.addressid = addr.addressid(+)
   and p.productid = pp.productid
   and od.productplayid = pp.productplayid
   and p.producttypeaid1 = ta.producttypeaid
   and p.venuesid = v.venuesid
   and o.ordersid = pm.ordersid
   and o.fconfigid = f.fconfigid
   and f.cityid = city.cityid
   and pm.discount=dis.DISCOUNTID(+)  and dis.HOST=2
   and pm.discountdetailid=disd.discountdetailid(+)

 
/

