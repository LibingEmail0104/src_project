CREATE PROCEDURE "P_UPDATE_PAYMENT_IS" is
  --定义游标
  cursor c_ci2 is
  select rowid row_id from   t_payment  ;
  r_ci2 c_ci2 % rowtype;
  --判断循环次数
  v_index number := 0;
begin
  --判断游标是否打开
  if c_ci2%isopen then
    null;
  else
    open c_ci2;
  end if;

  loop
    fetch c_ci2
      into r_ci2;
    exit when c_ci2%notfound;

update t_payment  t set  t.isselect=0 where  t.discount=70000 and t.rowid=r_ci2.row_id;
  update t_payment  t set  t.isselect=1 where  t.discount!=70000 and t.rowid=r_ci2.row_id;

    --分段提交
    v_index := v_index + 1;
    if (v_index = 5000) then
      commit;
      v_index := 0;
    end if;
  end loop;

   commit;

  close c_ci2;
end P_UPDATE_PAYMENT_IS;

/

