CREATE function get_date_minus_tl(in_productid   number,--商品ID
                                             in_char_hour   number,--要减去的天
                                             in_char_minute number --要减去的秒
                                             )
  return date is
  v_date date;
begin
  select trunc(t.enddate) - in_char_hour - (in_char_minute / (24 * 60*60))
    into v_date
    from t_product t
   where t.productid = in_productid;
  return v_date;
end get_date_minus_tl;

/

