CREATE FUNCTION get_discount (p_id  number) return number is
  v_discount number;
begin
  select decode(t.discount, null, tv.discountid, t.discount)  into v_discount
       from v_discount tv, t_payment_detail t
 where tv.discountdetailid = t.discountdetailid and   t.discountdetailid is not null and t.id=p_id ;
  return v_discount;
  EXCEPTION
         WHEN NO_DATA_FOUND THEN
       return '0';
end;

/

