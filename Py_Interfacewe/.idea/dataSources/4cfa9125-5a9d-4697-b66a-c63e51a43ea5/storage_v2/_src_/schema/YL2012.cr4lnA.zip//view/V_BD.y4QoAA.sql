CREATE VIEW V_BD AS
  select distinct t.customersid,t.cname,t.phone, t.ytotal,t.ysprice, t.ordersid,t.ordersource,to_number(to_char(t.createtime, 'mm')) mm,to_number(to_char(t.createtime, 'yyyy')) yy
  from v_orders_product t
 where to_char(t.createtime, 'yyyy') in ('2013','2014') and t.starus in ('已完成', '已发货') order by yy,mm


/

