CREATE procedure YL_AUTO_degre
   (in_productid  in number,in_dt in varchar2) is
begin
update t_orders t set batch='2',starus=10 where  ordersid in
(select ordersid from  (select t.ordersid from t_orders t where t.batch = 'YL_'||in_productid||'_'||in_dt order by ytotal asc,ordersid asc ) where rownum<=1);
 commit;
end ;

/

