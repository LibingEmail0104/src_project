CREATE function get_body (v_count number)
return varchar2 is
v_rank varchar2(200);
begin
   if v_count<200
     then select '小项目' into  v_rank from dual;
   elsif v_count>=200 and v_count<500
     then  select '中项目' into  v_rank from dual;
   else
     select '大项目' into  v_rank from dual;
   end if;
return v_rank;
end;

/

