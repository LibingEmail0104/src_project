CREATE VIEW V_PRODUCT_TOTALPRICE AS
  select distinct p.productid,
                p.name,
                get_starus(o.starus) starus,
                get_ordersource(o.ordersource) ordersource,
                sum(od.price * od.num) over(partition by p.productid,o.ordersource,o.starus) price_num
  from t_orders o, t_ordersdetail od, t_productplay pp, t_product p
 where o.ordersid = od.ordersid
   and od.productplayid = pp.productplayid
   and pp.productid = p.productid
   and get_starus(o.starus)  in('已发货','已完成')


/

