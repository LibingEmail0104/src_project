CREATE VIEW V_NEW_PRODUCT AS
  select fc.fconfigid       as 分站编码,
       ci.cityname        as 分站名称,
       pta.producttypeaid as 项目大类编码,
       pta.name           as 项目大类名称,
       ptb.producttypebid as 项目小类编码,
       ptb.name           as 项目小类名称,
       p.productid        as 项目编码,
       p.name             as 项目名称
  from t_product      p,
       t_producttypea pta,
       t_producttypeb ptb,
       t_fconfig      fc,
       t_city         ci
 where p.producttypeaid1 = pta.producttypeaid
   and p.producttypebid1 = ptb.producttypebid
   and p.fconfigid = fc.fconfigid
   and fc.cityid = ci.cityid
      -- and p.display = 1 and p.status = 0
   and p.fconfigid in
       (1, 131051, 2350508, 44977102, 45216767, 45253678, 45733256, 5214250)
   and p.createtime >=
       to_date(decode(to_char(sysdate, 'day'),
              'monday   ',
              to_char(sysdate - 7, 'yyyymmdd'),
              'tuesday  ',
              to_char(sysdate - 8, 'yyyymmdd'),
              'wednesday',
              to_char(sysdate - 9, 'yyyymmdd'),
              'thursday ',
              to_char(sysdate - 10, 'yyyymmdd'),
              'friday   ',
              to_char(sysdate - 11, 'yyyymmdd'),
              'err')||' 00:00:01','yyyymmdd hh24:mi:ss')
   and p.createtime <=
       to_date(decode(to_char(sysdate, 'day'),
              'monday   ',
              to_char(sysdate - 3, 'yyyymmdd'),
              'tuesday  ',
              to_char(sysdate - 4, 'yyyymmdd'),
              'wednesday',
              to_char(sysdate - 5, 'yyyymmdd'),
              'thursday ',
              to_char(sysdate - 6, 'yyyymmdd'),
              'friday   ',
              to_char(sysdate - 7, 'yyyymmdd'),
              'err')||' 23:59:59','yyyymmdd hh24:mi:ss') --根据起始日期推断月末
 order by fc.fconfigid, p.productid


/

