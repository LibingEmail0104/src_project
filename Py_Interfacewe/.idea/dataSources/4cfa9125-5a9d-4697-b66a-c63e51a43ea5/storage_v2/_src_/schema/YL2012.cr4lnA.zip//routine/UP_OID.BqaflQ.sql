CREATE procedure up_oid(v_id number,v_wid number )
    is
begin
-----v_wid 0  ordersid  ;1 orderdetailid
if v_wid=0
  then
   update  vt_od_ids set oisuse=1 where ordersid=v_id;
   commit;
elsif  v_wid=1
    then
    update  vt_od_ids set odisuse=1 where ordersdetailid=v_id;
   commit;
end if;
 end;

/

