CREATE VIEW V_PRODUCTTYPE AS
  select ta.producttypeaid,ta.name taname,tb.producttypebid,tb.name tbname from    t_producttypea ta,t_producttypeB tb where ta.producttypeaid=tb.producttypeaid

/

