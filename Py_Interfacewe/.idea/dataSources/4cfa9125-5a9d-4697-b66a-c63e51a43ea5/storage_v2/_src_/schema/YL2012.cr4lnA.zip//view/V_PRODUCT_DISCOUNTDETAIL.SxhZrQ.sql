CREATE VIEW V_PRODUCT_DISCOUNTDETAIL AS
  select "ORDERSID","PRODUCTID","SUMRATIO","DISCOUNTDETAILID" from vt_product_discountdetail1 union select "ORDERSID","PRODUCTID","SUMRATIO","DISCOUNTDETAIL" from vt_product_discountdetail2
/

