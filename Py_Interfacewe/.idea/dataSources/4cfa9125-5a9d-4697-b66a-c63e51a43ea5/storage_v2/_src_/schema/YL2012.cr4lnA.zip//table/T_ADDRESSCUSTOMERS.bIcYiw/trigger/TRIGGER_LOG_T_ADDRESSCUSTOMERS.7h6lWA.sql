CREATE TRIGGER TRIGGER_LOG_T_ADDRESSCUSTOMERS
  AFTER UPDATE
  ON T_ADDRESSCUSTOMERS
  FOR EACH ROW
  begin
  insert into log_t_addresscustomers
    (addressidcustomersid,
     customersid,
     name,
     type,
     zip,
     username,
     phone,
     tel,
     orders,
     remark,
     status,
     createtime,
     lasttime,
     lastuser,
     areaid,
     cityid,
     codeid,
     provinceid,
     dzphone,
     email,
     delivery,
     logtime,
     mhost,
     ip,
     new_codeid,
     new_areaid,
     new_cityid)
  values
    (:old.addressidcustomersid,
     :old.customersid,
     :old.name,
     :old.type,
     :old.zip,
     :old.username,
     :old.phone,
     :old.tel,
     :old.orders,
     :old.remark,
     :old.status,
     :old.createtime,
     :old.lasttime,
     :old.lastuser,
     :old.areaid,
     :old.cityid,
     :old.codeid,
     :old.provinceid,
     :old.dzphone,
     :old.email,
     :old.delivery,
     sysdate,
     SYS_CONTEXT('USERENV', 'HOST'), sys_context('userenv','ip_address'),
     :new.codeid,
     :new.areaid,
     :new.cityid);
end;


/

