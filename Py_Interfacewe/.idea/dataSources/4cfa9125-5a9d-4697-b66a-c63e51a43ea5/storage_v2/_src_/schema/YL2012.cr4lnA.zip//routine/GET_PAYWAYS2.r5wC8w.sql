CREATE FUNCTION GET_payways2 (v_ordersid number)
  return varchar2 is
  v_pay varchar2(200);
begin
  select wm_concat(v.rank||t.third_trade_no ||':'||t.actual_fee) into v_pay
  from t_payment_detail t, v_discount v
 where  v.discountdetailid = t.discountdetailid and t.order_id=v_ordersid and t.payment_status in (1,2)
 group by t.order_id;
 return v_pay;
    exception
  when no_data_found then
    return ' '  ;
  when others then
    return ' '  ;
end;

/

