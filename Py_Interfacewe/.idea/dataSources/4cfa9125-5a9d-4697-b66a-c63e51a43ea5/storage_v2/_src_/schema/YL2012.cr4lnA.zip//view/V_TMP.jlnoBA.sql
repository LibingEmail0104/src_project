CREATE VIEW V_TMP AS
  select city.cityname,
 decode(o.WRITECHECKFLAG, 0, '不开', 1, '永乐', 2, '主办开票') 开票方 ,       co.name,
   decode(o.writecheck,0,'否','是') 是否已开,
   decode(     o.isaddwritecheck,0,'否','是') 是否补开,
       o.ordersid,
    decode (  pay.paystatus,2,'已支付',1,'部分支付',0,'未支付') 支付状态,
       to_char(pay.paysuccessfultime, 'yyyy-mm-dd hh24:mi:ss') as paysuccessfultime,
       to_char(o.deliverydate, 'yyyy-mm-dd hh24:mi:ss') as deliverydate,
       p.productid,
       p.name as productname,
  --     yongle.pd(o.ordersid) as paymethod,
       p.begindate,
       p.enddate,
       to_char(pp.playdate, 'yyyy-mm-dd') || ' ' || pp.time as playenddate,
       pay.zprice 合计,
       o.fpprice,
       pay.nzprice 应收,
       to_char(o.writecheckdate, 'yyyy-mm-dd hh24:mi:ss') as writecheckdate,
       pay.ljprice as 礼券金额,
       (select sum(pmd1.actual_fee)
          from t_payment_detail pmd1
         where pmd1.order_id = o.ordersid
           and pmd1.payment_status != 0
           and pmd1.discountdetailid = 66985008
           and pmd1.cardno not in
               (select pmd2.cardno
                  from t_payment_detail pmd2,
                       t_cashcoupon     cash2,
                       t_cashcouponinfo cashinfo2
                 where pmd2.cardno = cashinfo2.cashcouponno
                   and cash2.cashcouponid = cashinfo2.cashcouponid
                   and cash2.cashcouponname like '%浦发银行%'
                   and pmd2.payment_status != 0
                   and pmd1.id = pmd2.id)) 礼券,
       (select sum(pmd1.actual_fee)
          from t_payment_detail pmd1
         where pmd1.order_id = o.ordersid
           and pmd1.payment_status != 0
           and pmd1.discountdetailid = 66985006) 乐通卡,
       (select sum(pmd1.actual_fee)
          from t_payment_detail pmd1
         where pmd1.order_id = o.ordersid
           and pmd1.payment_status != 0
           and pmd1.discountdetailid = 66985007) 预存款,
       (select sum(pmd1.actual_fee)
          from t_payment_detail pmd1
         where pmd1.order_id = o.ordersid
           and pmd1.payment_status != 0
           and pmd1.discountdetailid = 101159715) 浦发A,
       (select sum(pmd1.actual_fee)
          from t_payment_detail pmd1
         where pmd1.order_id = o.ordersid
           and pmd1.payment_status != 0
           and pmd1.discountdetailid = 107453558) 浦发B,
       (select sum(pmd1.actual_fee)
          from t_payment_detail pmd1
         where pmd1.order_id = o.ordersid
           and pmd1.payment_status != 0
           and pmd1.discountdetailid = 66985008
           and pmd1.cardno in
               (select pmd2.cardno
                  from t_payment_detail pmd2,
                       t_cashcoupon     cash2,
                       t_cashcouponinfo cashinfo2
                 where pmd2.cardno = cashinfo2.cashcouponno
                   and cash2.cashcouponid = cashinfo2.cashcouponid
                   and cash2.cashcouponname like '%浦发银行%'
                   and pmd2.payment_status != 0
                   and pmd1.id = pmd2.id)) 浦发C,
        (select sum(pmd1.actual_fee)
          from t_payment_detail pmd1
         where pmd1.order_id = o.ordersid
           and pmd1.payment_status != 0
           and pmd1.discountdetailid = 108948742) 百度优惠,
   --    pay.insuredamount,
       o.rangeprice 配送金额,
       o.lnvoice 抬头,
       o.writecheckcode 发票号,
   --    addrc.name as addrname,
       addrc.phone 手机号,
       addrc.username
   from t_orders       o,
       t_payment      pay,
       t_ordersdetail od,
       t_productplay  pp,
       t_product      p,
       t_fconfig      ff,
       t_city         city,
       t_address      addrc,
       t_code         co
 where o.ordersid = pay.ordersid
   and o.ordersid = od.ordersid
   and od.productplayid = pp.productplayid
   and pp.productid = p.productid
   and o.fconfigid = ff.fconfigid
   and ff.cityid = city.cityid
   and p.codeid = co.codeid
   and o.addressid = addrc.addressid(+)
   and o.starus in (5, 6)
   and o.ERRSTARUS != 1
   and p.path  like 'kaixinguo%'
    and pay.paysuccessfultime> to_date('20160101 00:00:00','yyyymmdd hh24:mi:ss') and  pay.paysuccessfultime<to_date('20170101 00:00:00','yyyymmdd hh24:mi:ss')
/

