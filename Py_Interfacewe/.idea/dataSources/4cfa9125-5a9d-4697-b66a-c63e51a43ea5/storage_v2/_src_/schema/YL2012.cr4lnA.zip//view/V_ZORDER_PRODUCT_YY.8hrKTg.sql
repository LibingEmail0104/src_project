CREATE VIEW V_ZORDER_PRODUCT_YY AS
  select
        '01.' || f.fconfigid || '.' || ta.producttypeaid || '.' ||tb.producttypebid || '.' || p.productid codes,
       get_ordersource(o.ordersource) 来源,
       get_payfgs(od.ordersdetailid) 分公司,
       city.cityname 城市,
       o.ordersid 订单号,
       od.ORDERSDETAILID 订单明细ID,
       c.customersid 用户ID,
       o.BACKMONEYDATE 回款日期,
       o.DELIVERYDATE 发货时间,
       o.createtime 订单创建时间,
       get_starus(o.starus)    订单状态,



       decode(dis.role || disd.rank,'百付宝快钱','在线支付快钱',
                                    '百付宝支付宝','在线支付支付宝',
                                    '货到付款快钱','货到付款',
                                    '货到付款支付宝','货到付款',
                                    '网银直联快钱','在线支付快钱',
                                    '网银直联支付宝','在线支付支付宝',
                                    '银行转账快钱','在线支付快钱',
                                    '银行转账支付宝','在线支付支付宝',
                                    '预存款快钱','在线支付快钱',
                                    '预存款支付宝','在线支付支付宝',dis.role || disd.rank)    支付方式,
       get_paystatus(pm.paystatus) 支付状态,
        decode(dis.discountid,
                      70054,
                      o.createtime,
                      70057,
                      o.createtime,
                      2341200,
                      o.createtime,
                      70049,
                     o.deliverydate,
                     70053,
                     o.ismodiftime,
                     pm.paysuccessfultime)    交易时间,
       addr.username 收货人,
       addr.phone  收货人手机号,
       decode(o.PSXX,1,'快递配送',2,'上门自取',4,'电子票','其他') 配送方式,
       ta.name 商品分类,
         decode(p.status,
              0,
              '售票中',
              1,
              '预售',
              2,
              '无效',
              3,
              '待定',
              4,
              '售完',
              5,
              '延期',
              6,
              '取消',
              7,
              '已结束') 商品状态,

    --  o.MATCHINGTIME 配票时间,
      p.productid 商品ID,
      p.name 商品名称,
       v.vname 场馆名称,
      tcode.name 出票系统,
      decode(pp. playdate, null, pp.time, pp.playdate) 演出时间,
      p.begindate 演出开始时间,
       p.enddate 演出结束时间,
       p.enddate- p.begindate   周期,
       pp.PRICE 票价,
       pp.playinfo 票价说明,
       od.NUM 数量,
       od.YTOTAL  票面款,
       od.HOSTDISCOUNT 折扣优惠,
        pp.PRICE*od.NUM*(1-decode(od.HOSTDISCOUNT,null,100,od.HOSTDISCOUNT)/100) 优惠损失,
       decode(c.type,0,decode(od.customerdiscount,null,100,od.customerdiscount),1,decode(od.discount, null,100,od.discount),100) as 折扣, --主办折扣
       pp.PRICE*od.NUM*(1-decode(c.type,0,decode(od.customerdiscount,null,100,od.customerdiscount),1,decode(od.discount, null,100,od.discount),100)/100) 折扣损失,
       pm.discountpay  支付折扣,
       (case
         when (row_number() over(partition by o.ordersid order by decode(pm.ysprice, null, 0, pm.ysprice) * (1 - pm.discountpay / 100))) = 1 then
          decode(pm.ysprice, null, 0, pm.ysprice) * (1 - pm.discountpay / 100)
         else
          null
       end) 支付损失,                                          --支付折扣
       -- 损失  票面款-（票价x数量x主办优惠x折扣+运费+保费）x支付折扣
       pp.PRICE*od.NUM*(decode(od.HOSTDISCOUNT,null,100,od.HOSTDISCOUNT)/100)*(decode(c.type,0,decode(od.customerdiscount,null,100,od.customerdiscount),1,decode(od.discount, null,100,od.discount),100)/100) 应收,
                                                                    --应收=票价x数量x主办优惠x折扣
       (case
         when (row_number() over(partition by o.ordersid order by od.YTOTAL*(1-c.UNIONSETTLEMENTDISCOUNT/100))) = 1 then
          od.YTOTAL*(1-c.UNIONSETTLEMENTDISCOUNT/100)
         else
          null
       end)   联盟折扣损失,

        (case
         when (row_number() over(partition by o.ordersid order by pm.insuredamount)) = 1 then
          pm.ljprice
         else
          null
       end) 保费,



        (case
         when (row_number() over(partition by o.ordersid order by  o.RANGEPRICE)) = 1 then
           o.RANGEPRICE
         else
          null
       end) 运费,

        (case
         when (row_number() over(partition by o.ordersid order by pm.ljprice)) = 1 then
          pm.ljprice
         else
          null
       end) 礼卷,

       (case
         when (row_number()
               over(partition by o.ordersid order by pm.lpkprice)) = 1 then
          pm.lpkprice
         else
          null
       end) 礼品卡,


       (case
         when (row_number()
               over(partition by o.ordersid order by pm.yckprice)) = 1 then
          pm.yckprice
         else
          null
       end) 预存款,

       (case
         when (row_number() over(partition by o.ordersid order by pm.ysprice)) = 1 then
          pm.ysprice
         else
          null
       end) 实收,
        get_tuiguang(o.spreadsource) 推广,
       te.name 快递,
       te.EXPRESSID 快递号,
       o.ISENDTIME 取票时间,
       o.UNIONORDERSID 联盟单号,
            ty.ENDTIME 异常结束时间,
       o.MATCHINGTIME 配票时间
  from t_orders         o,
       t_ordersdetail   od,
       t_customers      c,
       t_address        addr,
       t_productplay    pp,
       t_producttypea   ta,
       t_product        p,
       t_venues         v,
       t_payment        pm,
       t_fconfig        f,
       t_city           city,
       t_discount       dis,
       t_discountdetail disd,
       t_producttypeb   tb,
       t_office         tof,
       t_code           tcode,
       T_EXPRESS        te,
        T_ORDERANOMALY   ty
 where o.ordersid = od.ordersid
   and o.customersid = c.customersid
   and o.addressid = addr.addressid(+)
   and p.productid = pp.productid
   and od.productplayid = pp.productplayid
   and p.producttypeaid1 = ta.producttypeaid
   and p.venuesid = v.venuesid
   and o.ordersid = pm.ordersid
   and o.fconfigid = f.fconfigid
   and f.cityid = city.cityid
   and pm.discount = dis.DISCOUNTID(+)
   and dis.HOST = 2
   and pm.discountdetailid = disd.discountdetailid(+)
   and p.producttypebid1 = tb.producttypebid
   and p.OFFICE = tof.officeid(+)
   and p.codeid = tcode.codeid(+)
   and o.EXPRESSNAME = te.expressid(+)
    and o.ordersid=ty.ordersid(+)
   -- and o.starus  in (1,2,3,4,5,6,11)
/

