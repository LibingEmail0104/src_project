CREATE FUNCTION get_discountdetail (p_id  number) return number is
  v_discountdetail number;
begin
  select t.discountdetailid   into v_discountdetail
       from  t_payment_detail t
 where   t.id=p_id ;
  return v_discountdetail;
  EXCEPTION
         WHEN NO_DATA_FOUND THEN
       return '0';
end;

/

