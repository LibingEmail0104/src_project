CREATE VIEW V_ORDERSDETAIL_PRODUCT AS
  select c.customersid, o.ordersid,o.createtime,o.starus,o.ordersource,od.price,od.num, p.productid, p.name
           from t_orders       o,
                t_ordersdetail od,
                t_customers    c,
                t_productplay  pp,
                t_product      p
          where o.ordersid = od.ordersid
            and o.customersid = c.customersid
            and p.productid = pp.productid
            and od.productplayid = pp.productplayid


/

