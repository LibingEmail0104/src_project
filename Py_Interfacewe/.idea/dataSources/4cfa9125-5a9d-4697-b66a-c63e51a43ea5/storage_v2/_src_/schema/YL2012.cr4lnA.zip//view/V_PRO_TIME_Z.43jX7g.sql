CREATE VIEW V_PRO_TIME_Z AS
  select tp.productid,
        o.ordersource ordersource,
         decode(pd.discountdetailid,
                  2217200,
                  1,
                  66985006,
                  2,
                  71796727,
                  3,
                  71796728,
                  4,
                  71772150,
                  5,
                  71754712,
                  6,
                  57120812,
                  7
                  ) discount,
        decode(pd.discountdetailid ,71796727,o.customersid,0) customersid,
        sum(od.ytotal) ytotal,
        to_char(o.createtime, 'yyyymmdd') mtime
   from t_orders         o,
        t_ordersdetail   od,
        t_productplay    tp,
        t_payment_detail pd
  where o.ordersid = od.ordersid
    and od.productplayid = tp.productplayid
    and o.ordersid = pd.order_id(+)
    and batch like 'YL_0_%' and  tp.productid=202449428
  group by  o.ordersource,
           to_char(o.createtime, 'yyyymmdd'),
           tp.productid,
             decode(pd.discountdetailid ,71796727,o.customersid,0)  ,
           decode(pd.discountdetailid,
                  2217200,
                  1,
                  66985006,
                  2,
                  71796727,
                  3,
                  71796728,
                  4,
                  71772150,
                  5,
                  71754712,
                  6,
                  57120812,
                  7
                  )
/

