CREATE VIEW V_PRODUCT AS
  select t.productid, t.name pname, c.cityname , pt.name ptname, v.vname, t.begindate , t.enddate ,get_display(t.display) display,decode( t.onlineseat,1,'支持','不支持') onlineseat ,t.performer,t.namesynonym,t.subjectpath
  from t_product t, t_fconfig f, t_city c, t_producttypea pt, t_venues v
 where t.fconfigid = f.fconfigid
   and f.cityid = c.cityid
   and t.producttypeaid1 = pt.producttypeaid
   and t.venuesid = v.venuesid
 order by c.cityname, pt.name, v.vname


/

