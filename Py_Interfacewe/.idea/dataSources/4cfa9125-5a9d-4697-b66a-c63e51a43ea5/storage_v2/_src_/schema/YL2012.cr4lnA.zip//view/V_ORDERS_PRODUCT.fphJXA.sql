CREATE VIEW V_ORDERS_PRODUCT AS
  select c.customersid ,c.type,c.phone cphone,c.email cemail,c.truename cname , o.ordersid,o.createtime,o.spreadsource,get_starus(o.starus) starus,get_ordersource(o.ordersource) ordersource,o.ytotal,o.ztotal, addr.username name, addr.phone,addr.email, get_province(addr.provinceid) province, get_cityname(addr.cityid) city, get_areaname (addr.areaid) area,get_paystatus(pm.paystatus) paystatus, pm.ysprice,pm.sjzfprice, p.productid, p.name pname,v.vname,ta.name typea ,city.cityname
           from t_orders       o,
                t_ordersdetail od,
                t_customers    c,
                t_address      addr,
                t_productplay  pp,
                t_producttypea ta,
                t_product      p,
                t_venues       v,
                t_payment      pm,
                t_fconfig      f,
                t_city         city
          where o.ordersid = od.ordersid
            and o.customersid = c.customersid
            and o.addressid =addr.addressid(+)
            and p.productid = pp.productid
            and od.productplayid = pp.productplayid
            and p.producttypeaid1=ta.producttypeaid
            and p.venuesid = v.venuesid
            and o.ordersid = pm.ordersid
            and o.fconfigid = f.fconfigid
            and f.cityid = city.cityid
/

