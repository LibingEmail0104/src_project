CREATE FUNCTION "GET_FCNAME"(v_fconfigid number) return varchar2 is
  v_cname varchar2(40);
begin
  select tc.cityname
    INTO v_cname
    from t_fconfig tf, t_city tc
   where tf.cityid = tc.cityid
     and tf.fconfigid = v_fconfigid;
  return v_cname;
exception
  when no_data_found then
    return '未知' || v_cname;
  when others then
    return '出错了' || v_cname;
end;



/

