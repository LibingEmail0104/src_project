CREATE VIEW V_YLPW_ORDERSDETAIL AS
  select od.seq_order_detail_id ordersdetailid,od.orderid,od.seq_product_ticket_price_id productplayid,num,od.num*od.caculatetotal ytotal,od.discount,od.realtotal total   from YLPW40.Orders_Detail od
/

