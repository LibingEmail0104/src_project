CREATE FUNCTION          "GET_PROVINCENAME" (p_provinceid number)
  return varchar2 is
  v_provincename varchar2(40);
begin

  select name
    into v_provincename
    from t_province
   where provinceid = p_provinceid;

  return v_provincename;
exception
  when no_data_found then
  
    return '未知' || p_provinceid;
  when others then
    return '出错了' || p_provinceid;
end;




/

