CREATE FUNCTION GET_pxss (p_pxss number) return varchar2 is
  v_pxss varchar2(50);
begin
  v_pxss := case p_pxss
                   when 1 then
                    '快递配送'
                   when 2 then
                    '上门自取'
                   when 3 then
                    '电子票'
                   else
                    '未知状态'||p_pxss
                 end;
  return v_pxss;
end;


/

