CREATE function get_areaname(p_areaid number) return varchar2 is
  v_areaname varchar2(50);
begin
  v_areaname := case p_areaid
                  when 761166 then
                   '伍家岗区'
                  when 761167 then
                   '点军区'
                  when 761168 then
                   '猇亭区'
                  when 761169 then
                   '夷陵区'
                  when 761170 then
                   '远安县'
                  when 761171 then
                   '兴山县'
                  when 761172 then
                   '秭归县'
                  when 761173 then
                   '长阳土家族自治县'
                  when 761174 then
                   '五峰土家族自治县'
                  when 761175 then
                   '宜都市'
                  when 761176 then
                   '当阳市'
                  when 761177 then
                   '枝江市'
                  when 761178 then
                   '襄城区'
                  when 761179 then
                   '樊城区'
                  when 761180 then
                   '襄阳区'
                  when 761181 then
                   '南漳县'
                  when 761182 then
                   '谷城县'
                  when 761183 then
                   '保康县'
                  when 761184 then
                   '老河口市'
                  when 761185 then
                   '枣阳市'
                  when 761186 then
                   '宜城市'
                  when 761187 then
                   '梁子湖区'
                  when 761188 then
                   '华容区'
                  when 761189 then
                   '鄂城区'
                  when 761190 then
                   '东宝区'
                  when 761191 then
                   '掇刀区'
                  when 761192 then
                   '京山县'
                  when 761193 then
                   '沙洋县'
                  when 761194 then
                   '钟祥市'
                  when 761195 then
                   '孝南区'
                  when 761196 then
                   '孝昌县'
                  when 761197 then
                   '大悟县'
                  when 761198 then
                   '云梦县'
                  when 761199 then
                   '应城市'
                  when 761200 then
                   '安陆市'
                  when 761201 then
                   '汉川市'
                  when 761202 then
                   '沙市区'
                  when 761203 then
                   '荆州区'
                  when 761204 then
                   '公安县'
                  when 761205 then
                   '监利县'
                  when 761206 then
                   '江陵县'
                  when 761207 then
                   '石首市'
                  when 761208 then
                   '洪湖市'
                  when 761209 then
                   '松滋市'
                  when 761210 then
                   '黄州区'
                  when 761211 then
                   '团风县'
                  when 761212 then
                   '红安县'
                  when 761213 then
                   '罗田县'
                  when 761214 then
                   '英山县'
                  when 761215 then
                   '浠水县'
                  when 761216 then
                   '蕲春县'
                  when 761217 then
                   '黄梅县'
                  when 761218 then
                   '麻城市'
                  when 761219 then
                   '武穴市'
                  when 761220 then
                   '咸安区'
                  when 761221 then
                   '嘉鱼县'
                  when 761222 then
                   '通城县'
                  when 761223 then
                   '崇阳县'
                  when 761224 then
                   '通山县'
                  when 761225 then
                   '赤壁市'
                  when 761226 then
                   '曾都区'
                  when 761227 then
                   '广水市'
                  when 761231 then
                   '神农架林区'
                  when 761232 then
                   '芙蓉区'
                  when 761233 then
                   '天心区'
                  when 761234 then
                   '岳麓区'
                  when 761235 then
                   '开福区'
                  when 761236 then
                   '雨花区'
                  when 761237 then
                   '长沙县'
                  when 761238 then
                   '望城县'
                  when 761239 then
                   '宁乡县'
                  when 761240 then
                   '浏阳市'
                  when 761241 then
                   '荷塘区'
                  when 761242 then
                   '芦淞区'
                  when 761243 then
                   '石峰区'
                  when 761244 then
                   '天元区'
                  when 761245 then
                   '株洲县'
                  when 761246 then
                   '攸县'
                  when 761247 then
                   '茶陵县'
                  when 761248 then
                   '炎陵县'
                  when 761249 then
                   '醴陵市'
                  when 761250 then
                   '雨湖区'
                  when 761251 then
                   '岳塘区'
                  when 761252 then
                   '湘潭县'
                  when 761253 then
                   '湘乡市'
                  when 761254 then
                   '韶山市'
                  when 761255 then
                   '珠晖区'
                  when 761256 then
                   '雁峰区'
                  when 761257 then
                   '石鼓区'
                  when 761258 then
                   '蒸湘区'
                  when 761259 then
                   '南岳区'
                  when 761260 then
                   '衡阳县'
                  when 761261 then
                   '衡南县'
                  when 761262 then
                   '衡山县'
                  when 761263 then
                   '衡东县'
                  when 761264 then
                   '祁东县'
                  when 761265 then
                   '耒阳市'
                  when 761266 then
                   '常宁市'
                  when 761267 then
                   '双清区'
                  when 761268 then
                   '大祥区'
                  when 761269 then
                   '北塔区'
                  when 761270 then
                   '邵东县'
                  when 761271 then
                   '新邵县'
                  when 761272 then
                   '邵阳县'
                  when 761273 then
                   '隆回县'
                  when 761274 then
                   '洞口县'
                  when 761275 then
                   '绥宁县'
                  when 761276 then
                   '新宁县'
                  when 761277 then
                   '城步苗族自治县'
                  when 761278 then
                   '武冈市'
                  when 761279 then
                   '岳阳楼区'
                  when 761280 then
                   '云溪区'
                  when 761281 then
                   '君山区'
                  when 761282 then
                   '岳阳县'
                  when 761283 then
                   '华容县'
                  when 761284 then
                   '湘阴县'
                  when 761285 then
                   '平江县'
                  when 761286 then
                   '汨罗市'
                  when 761287 then
                   '临湘市'
                  when 761288 then
                   '武陵区'
                  when 761289 then
                   '鼎城区'
                  when 761290 then
                   '安乡县'
                  when 761291 then
                   '汉寿县'
                  when 761292 then
                   '澧县'
                  when 761293 then
                   '临澧县'
                  when 761294 then
                   '桃源县'
                  when 761295 then
                   '石门县'
                  when 761296 then
                   '津市市'
                  when 761297 then
                   '永定区'
                  when 761298 then
                   '武陵源区'
                  when 761299 then
                   '慈利县'
                  when 761300 then
                   '桑植县'
                  when 761301 then
                   '资阳区'
                  when 761302 then
                   '赫山区'
                  when 761303 then
                   '桃江县'
                  when 761304 then
                   '安化县'
                  when 761305 then
                   '沅江市'
                  when 761306 then
                   '北湖区'
                  when 761307 then
                   '苏仙区'
                  when 761308 then
                   '桂阳县'
                  when 761309 then
                   '宜章县'
                  when 761310 then
                   '永兴县'
                  when 761311 then
                   '嘉禾县'
                  when 761312 then
                   '临武县'
                  when 761313 then
                   '汝城县'
                  when 761314 then
                   '桂东县'
                  when 761315 then
                   '安仁县'
                  when 761316 then
                   '资兴市'
                  when 2787 then
                   '和平区'
                  when 2788 then
                   '南开区'
                  when 70200 then
                   '朝阳区'
                  when 2786 then
                   '普陀区'
                  when 2789 then
                   '河西区'
                  when 2790 then
                   '蓟县'
                  when 2325751 then
                   '台湾'
                  when 2792 then
                   '经济技术开发区'
                  when 2325752 then
                   '香港'
                  when 2794 then
                   '青浦区'
                  when 2795 then
                   '津南区'
                  when 2796 then
                   '萝岗区'
                  when 2797 then
                   '红桥区'
                  when 2798 then
                   '河东区'
                  when 2799 then
                   '宝山区'
                  when 2800 then
                   '河北区'
                  when 2801 then
                   '大兴区'
                  when 2802 then
                   '东丽区'
                  when 2803 then
                   '静海县'
                  when 2804 then
                   '盐田区'
                  when 2344851 then
                   '江北区'
                  when 2806 then
                   '大港区'
                  when 2807 then
                   '塘沽区'
                  when 70201 then
                   '闵行区'
                  when 73701 then
                   '昌平区'
                  when 2718 then
                   '静安区'
                  when 2719 then
                   '浦东新区'
                  when 2720 then
                   '松江区'
                  when 2721 then
                   '青羊区'
                  when 2722 then
                   '锦江区'
                  when 2723 then
                   '成华区'
                  when 2724 then
                   '金牛区'
                  when 1645000 then
                   '虹口区'
                  when 2726 then
                   '武候区'
                  when 2727 then
                   '黄浦区'
                  when 2728 then
                   '南岸区'
                  when 2729 then
                   '渝中区'
                  when 2730 then
                   '虹桥经济开发区'
                  when 2731 then
                   '渝北区'
                  when 2732 then
                   '沙坪坝区'
                  when 2733 then
                   '江北区'
                  when 2734 then
                   '东山区'
                  when 2735 then
                   '越秀区'
                  when 2736 then
                   '西城区'
                  when 2737 then
                   '卢湾区'
                  when 2738 then
                   '徐汇区'
                  when 2739 then
                   '闸北区'
                  when 2740 then
                   '杨浦区'
                  when 2741 then
                   '崇文区'
                  when 2742 then
                   '长宁区'
                  when 2743 then
                   '东城区'
                  when 2744 then
                   '丰台区'
                  when 2344852 then
                   '西湖区'
                  when 2746 then
                   '顺义区'
                  when 2747 then
                   '宣武区'
                  when 2748 then
                   '九龙坡区'
                  when 2749 then
                   '通州区'
                  when 2750 then
                   '怀柔区'
                  when 2751 then
                   '嘉定区'
                  when 2752 then
                   '金山区'
                  when 2753 then
                   '白云区'
                  when 2754 then
                   '鼓楼区'
                  when 2351000 then
                   '高新技术区'
                  when 2756 then
                   '番禺区'
                  when 2465502 then
                   '雨山区'
                  when 2758 then
                   '南岗区'
                  when 2759 then
                   '尚志市'
                  when 2465503 then
                   '当涂县'
                  when 2761 then
                   '玄武区'
                  when 2762 then
                   '建邺区'
                  when 2540050 then
                   '无锡新区'
                  when 2596050 then
                   '双桥区'
                  when 2765 then
                   '天河区'
                  when 2766 then
                   '白下区'
                  when 2767 then
                   '新都区'
                  when 2768 then
                   '道里区'
                  when 2769 then
                   '增城市'
                  when 2770 then
                   '道外区'
                  when 2771 then
                   '高新区'
                  when 2772 then
                   '海珠区'
                  when 2773 then
                   '荔湾区'
                  when 2774 then
                   '石景山区'
                  when 2776 then
                   '长寿区'
                  when 2777 then
                   '巴南区'
                  when 2779 then
                   '惠济区'
                  when 2781 then
                   '房山区'
                  when 2782 then
                   '郑东新区'
                  when 2783 then
                   '金水区'
                  when 2784 then
                   '门头沟区'
                  when 73700 then
                   '海淀区'
                  when 760900 then
                   '环翠区'
                  when 760901 then
                   '文登市'
                  when 760902 then
                   '荣成市'
                  when 760903 then
                   '乳山市'
                  when 760904 then
                   '东港区'
                  when 760905 then
                   '岚山区'
                  when 760906 then
                   '五莲县'
                  when 760907 then
                   '莒县'
                  when 760908 then
                   '莱城区'
                  when 760909 then
                   '钢城区'
                  when 760910 then
                   '兰山区'
                  when 760911 then
                   '罗庄区'
                  when 760912 then
                   '沂南县'
                  when 760913 then
                   '郯城县'
                  when 760914 then
                   '沂水县'
                  when 760915 then
                   '苍山县'
                  when 760916 then
                   '费县'
                  when 760917 then
                   '平邑县'
                  when 760918 then
                   '莒南县'
                  when 760919 then
                   '蒙阴县'
                  when 760920 then
                   '临沭县'
                  when 760921 then
                   '德城区'
                  when 760922 then
                   '陵县'
                  when 760923 then
                   '宁津县'
                  when 760924 then
                   '庆云县'
                  when 760925 then
                   '临邑县'
                  when 760926 then
                   '齐河县'
                  when 760927 then
                   '平原县'
                  when 760928 then
                   '夏津县'
                  when 760929 then
                   '武城县'
                  when 760930 then
                   '乐陵市'
                  when 760931 then
                   '禹城市'
                  when 760932 then
                   '东昌府区'
                  when 760933 then
                   '阳谷县'
                  when 760934 then
                   '莘县'
                  when 760935 then
                   '茌平县'
                  when 760936 then
                   '东阿县'
                  when 760937 then
                   '冠县'
                  when 760938 then
                   '高唐县'
                  when 760939 then
                   '临清市'
                  when 760940 then
                   '滨城区'
                  when 760941 then
                   '惠民县'
                  when 760942 then
                   '阳信县'
                  when 760943 then
                   '无棣县'
                  when 760944 then
                   '沾化县'
                  when 760945 then
                   '博兴县'
                  when 760946 then
                   '邹平县'
                  when 760947 then
                   '牡丹区'
                  when 760948 then
                   '曹县'
                  when 760949 then
                   '单县'
                  when 760950 then
                   '成武县'
                  when 760951 then
                   '巨野县'
                  when 760952 then
                   '郓城县'
                  when 760953 then
                   '鄄城县'
                  when 760954 then
                   '定陶县'
                  when 760955 then
                   '东明县'
                  when 760956 then
                   '龙亭区'
                  when 760957 then
                   '顺河回族区'
                  when 760958 then
                   '南关区'
                  when 760959 then
                   '郊区'
                  when 760960 then
                   '杞县'
                  when 760961 then
                   '通许县'
                  when 760962 then
                   '尉氏县'
                  when 760963 then
                   '开封县'
                  when 760964 then
                   '兰考县'
                  when 761000 then
                   '老城区'
                  when 761001 then
                   '西工区'
                  when 761002 then
                   '廛河回族区'
                  when 761003 then
                   '涧西区'
                  when 761004 then
                   '吉利区'
                  when 761005 then
                   '洛龙区'
                  when 761006 then
                   '孟津县'
                  when 761007 then
                   '新安县'
                  when 762636 then
                   '乐亭县'
                  when 762637 then
                   '迁西县'
                  when 762638 then
                   '玉田县'
                  when 762639 then
                   '唐海县'
                  when 762640 then
                   '遵化市'
                  when 762641 then
                   '迁安市'
                  when 761008 then
                   '栾川县'
                  when 761009 then
                   '嵩县'
                  when 761010 then
                   '汝阳县'
                  when 761011 then
                   '宜阳县'
                  when 761012 then
                   '洛宁县'
                  when 761013 then
                   '伊川县'
                  when 761014 then
                   '偃师市'
                  when 761015 then
                   '新华区'
                  when 761016 then
                   '卫东区'
                  when 761017 then
                   '石龙区'
                  when 761018 then
                   '湛河区'
                  when 761019 then
                   '宝丰县'
                  when 761020 then
                   '叶县'
                  when 761021 then
                   '鲁山县'
                  when 761022 then
                   '郏县'
                  when 761023 then
                   '舞钢市'
                  when 761024 then
                   '汝州市'
                  when 761025 then
                   '文峰区'
                  when 761026 then
                   '北关区'
                  when 761027 then
                   '殷都区'
                  when 761028 then
                   '龙安区'
                  when 761029 then
                   '安阳县'
                  when 761030 then
                   '汤阴县'
                  when 761031 then
                   '滑县'
                  when 761032 then
                   '内黄县'
                  when 761033 then
                   '林州市'
                  when 761034 then
                   '鹤山区'
                  when 761035 then
                   '山城区'
                  when 761036 then
                   '淇滨区'
                  when 761037 then
                   '浚县'
                  when 761038 then
                   '淇县'
                  when 761039 then
                   '红旗区'
                  when 761040 then
                   '卫滨区'
                  when 761041 then
                   '凤泉区'
                  when 761042 then
                   '牧野区'
                  when 761043 then
                   '新乡县'
                  when 761044 then
                   '获嘉县'
                  when 761045 then
                   '原阳县'
                  when 761046 then
                   '延津县'
                  when 761047 then
                   '封丘县'
                  when 761048 then
                   '长垣县'
                  when 761049 then
                   '卫辉市'
                  when 761050 then
                   '辉县市'
                  when 761051 then
                   '解放区'
                  when 761052 then
                   '中站区'
                  when 761053 then
                   '马村区'
                  when 761054 then
                   '山阳区'
                  when 761055 then
                   '修武县'
                  when 761056 then
                   '博爱县'
                  when 761057 then
                   '武陟县'
                  when 761058 then
                   '温县'
                  when 761060 then
                   '沁阳市'
                  when 761061 then
                   '孟州市'
                  when 761062 then
                   '华龙区'
                  when 761063 then
                   '清丰县'
                  when 761064 then
                   '南乐县'
                  when 761065 then
                   '范县'
                  when 761066 then
                   '台前县'
                  when 761067 then
                   '濮阳县'
                  when 761068 then
                   '魏都区'
                  when 761069 then
                   '许昌县'
                  when 761070 then
                   '鄢陵县'
                  when 761071 then
                   '襄城县'
                  when 761072 then
                   '禹州市'
                  when 761073 then
                   '长葛市'
                  when 761074 then
                   '源汇区'
                  when 761075 then
                   '郾城区'
                  when 761076 then
                   '召陵区'
                  when 761077 then
                   '舞阳县'
                  when 761078 then
                   '临颍县'
                  when 761079 then
                   '市辖区'
                  when 761080 then
                   '湖滨区'
                  when 761081 then
                   '渑池县'
                  when 761082 then
                   '陕县'
                  when 761083 then
                   '卢氏县'
                  when 761084 then
                   '义马市'
                  when 761085 then
                   '灵宝市'
                  when 761086 then
                   '宛城区'
                  when 761087 then
                   '卧龙区'
                  when 761088 then
                   '南召县'
                  when 761089 then
                   '方城县'
                  when 761090 then
                   '西峡县'
                  when 761091 then
                   '镇平县'
                  when 761092 then
                   '内乡县'
                  when 761093 then
                   '淅川县'
                  when 761094 then
                   '社旗县'
                  when 761095 then
                   '唐河县'
                  when 761096 then
                   '新野县'
                  when 761097 then
                   '桐柏县'
                  when 761098 then
                   '邓州市'
                  when 761099 then
                   '梁园区'
                  when 761100 then
                   '睢阳区'
                  when 761101 then
                   '民权县'
                  when 761102 then
                   '睢县'
                  when 761103 then
                   '宁陵县'
                  when 761104 then
                   '柘城县'
                  when 761105 then
                   '虞城县'
                  when 761106 then
                   '夏邑县'
                  when 761107 then
                   '永城市'
                  when 761108 then
                   '浉河区'
                  when 761109 then
                   '平桥区'
                  when 761110 then
                   '罗山县'
                  when 761111 then
                   '光山县'
                  when 761112 then
                   '新县'
                  when 761113 then
                   '商城县'
                  when 761114 then
                   '固始县'
                  when 761115 then
                   '潢川县'
                  when 761116 then
                   '淮滨县'
                  when 761117 then
                   '息县'
                  when 761118 then
                   '川汇区'
                  when 761119 then
                   '扶沟县'
                  when 761120 then
                   '西华县'
                  when 761121 then
                   '商水县'
                  when 761122 then
                   '沈丘县'
                  when 761123 then
                   '郸城县'
                  when 761124 then
                   '淮阳县'
                  when 761125 then
                   '太康县'
                  when 761126 then
                   '鹿邑县'
                  when 761127 then
                   '项城市'
                  when 761128 then
                   '驿城区'
                  when 761129 then
                   '西平县'
                  when 761130 then
                   '上蔡县'
                  when 761131 then
                   '平舆县'
                  when 761132 then
                   '正阳县'
                  when 761133 then
                   '确山县'
                  when 761134 then
                   '泌阳县'
                  when 761135 then
                   '汝南县'
                  when 761136 then
                   '遂平县'
                  when 761137 then
                   '新蔡县'
                  when 761138 then
                   '江岸区'
                  when 761139 then
                   '江汉区'
                  when 761140 then
                   '硚口区'
                  when 761141 then
                   '汉阳区'
                  when 761142 then
                   '武昌区'
                  when 761143 then
                   '青山区'
                  when 761144 then
                   '洪山区'
                  when 761145 then
                   '东西湖区'
                  when 761146 then
                   '汉南区'
                  when 761147 then
                   '蔡甸区'
                  when 761148 then
                   '江夏区'
                  when 761149 then
                   '黄陂区'
                  when 761150 then
                   '新洲区'
                  when 761151 then
                   '黄石港区'
                  when 761152 then
                   '西塞山区'
                  when 761153 then
                   '下陆区'
                  when 761154 then
                   '铁山区'
                  when 761155 then
                   '阳新县'
                  when 761156 then
                   '大冶市'
                  when 761157 then
                   '茅箭区'
                  when 761158 then
                   '张湾区'
                  when 761159 then
                   '郧县'
                  when 761160 then
                   '郧西县'
                  when 761161 then
                   '竹山县'
                  when 761162 then
                   '竹溪县'
                  when 761163 then
                   '房县'
                  when 761317 then
                   '芝山区'
                  when 761318 then
                   '冷水滩区'
                  when 761319 then
                   '祁阳县'
                  when 761320 then
                   '东安县'
                  when 761321 then
                   '双牌县'
                  when 761322 then
                   '道县'
                  when 761323 then
                   '江永县'
                  when 761324 then
                   '宁远县'
                  when 761325 then
                   '蓝山县'
                  when 761326 then
                   '新田县'
                  when 761327 then
                   '江华瑶族自治县'
                  when 761328 then
                   '鹤城区'
                  when 761329 then
                   '中方县'
                  when 761330 then
                   '沅陵县'
                  when 761331 then
                   '辰溪县'
                  when 761332 then
                   '溆浦县'
                  when 761333 then
                   '会同县'
                  when 761334 then
                   '麻阳苗族自治县'
                  when 761335 then
                   '新晃侗族自治县'
                  when 761336 then
                   '芷江侗族自治县'
                  when 761337 then
                   '靖州苗族侗族自治县'
                  when 761338 then
                   '通道侗族自治县'
                  when 761339 then
                   '洪江市'
                  when 761340 then
                   '娄星区'
                  when 761341 then
                   '双峰县'
                  when 761342 then
                   '新化县'
                  when 761343 then
                   '冷水江市'
                  when 761344 then
                   '涟源市'
                  when 761345 then
                   '武江区'
                  when 761346 then
                   '浈江区'
                  when 761347 then
                   '曲江区'
                  when 761348 then
                   '始兴县'
                  when 761349 then
                   '仁化县'
                  when 761350 then
                   '翁源县'
                  when 761351 then
                   '乳源瑶族自治县'
                  when 761352 then
                   '新丰县'
                  when 761353 then
                   '乐昌市'
                  when 761354 then
                   '南雄市'
                  when 761355 then
                   '香洲区'
                  when 761356 then
                   '斗门区'
                  when 761357 then
                   '金湾区'
                  when 761358 then
                   '龙湖区'
                  when 761359 then
                   '金平区'
                  when 761360 then
                   '濠江区'
                  when 761361 then
                   '潮阳区'
                  when 761362 then
                   '潮南区'
                  when 761363 then
                   '澄海区'
                  when 761364 then
                   '南澳县'
                  when 761365 then
                   '禅城区'
                  when 761366 then
                   '南海区'
                  when 761367 then
                   '顺德区'
                  when 761368 then
                   '三水区'
                  when 761369 then
                   '高明区'
                  when 761370 then
                   '蓬江区'
                  when 761371 then
                   '江海区'
                  when 761372 then
                   '新会区'
                  when 761373 then
                   '台山市'
                  when 761374 then
                   '开平市'
                  when 761375 then
                   '鹤山市'
                  when 761376 then
                   '恩平市'
                  when 761377 then
                   '赤坎区'
                  when 761378 then
                   '霞山区'
                  when 761379 then
                   '坡头区'
                  when 761380 then
                   '麻章区'
                  when 761381 then
                   '遂溪县'
                  when 761382 then
                   '徐闻县'
                  when 761383 then
                   '廉江市'
                  when 761384 then
                   '雷州市'
                  when 761385 then
                   '吴川市'
                  when 761386 then
                   '茂南区'
                  when 761387 then
                   '茂港区'
                  when 761388 then
                   '电白县'
                  when 761389 then
                   '高州市'
                  when 761390 then
                   '化州市'
                  when 761391 then
                   '信宜市'
                  when 761392 then
                   '端州区'
                  when 761393 then
                   '鼎湖区'
                  when 761394 then
                   '广宁县'
                  when 761395 then
                   '怀集县'
                  when 761396 then
                   '封开县'
                  when 761397 then
                   '德庆县'
                  when 761398 then
                   '高要市'
                  when 761399 then
                   '四会市'
                  when 761400 then
                   '惠城区'
                  when 761401 then
                   '惠阳区'
                  when 761402 then
                   '博罗县'
                  when 761403 then
                   '惠东县'
                  when 761404 then
                   '龙门县'
                  when 761405 then
                   '梅江区'
                  when 761406 then
                   '大埔县'
                  when 761407 then
                   '丰顺县'
                  when 761408 then
                   '五华县'
                  when 761409 then
                   '平远县'
                  when 761410 then
                   '蕉岭县'
                  when 761411 then
                   '兴宁市'
                  when 761412 then
                   '海丰县'
                  when 761413 then
                   '陆河县'
                  when 761414 then
                   '陆丰市'
                  when 761415 then
                   '源城区'
                  when 761416 then
                   '紫金县'
                  when 761417 then
                   '龙川县'
                  when 761418 then
                   '连平县'
                  when 761419 then
                   '和平县'
                  when 761420 then
                   '东源县'
                  when 761421 then
                   '江城区'
                  when 761422 then
                   '阳西县'
                  when 761423 then
                   '阳东县'
                  when 761424 then
                   '阳春市'
                  when 761425 then
                   '清城区'
                  when 761426 then
                   '佛冈县'
                  when 761427 then
                   '阳山县'
                  when 761428 then
                   '连山壮族瑶族自治县'
                  when 761429 then
                   '连南瑶族自治县'
                  when 761430 then
                   '清新县'
                  when 761431 then
                   '英德市'
                  when 761432 then
                   '连州市'
                  when 761433 then
                   '湘桥区'
                  when 761434 then
                   '潮安县'
                  when 761435 then
                   '饶平县'
                  when 761436 then
                   '榕城区'
                  when 761437 then
                   '揭东县'
                  when 761438 then
                   '揭西县'
                  when 761439 then
                   '惠来县'
                  when 761440 then
                   '普宁市'
                  when 761441 then
                   '云城区'
                  when 761442 then
                   '新兴县'
                  when 761443 then
                   '郁南县'
                  when 761444 then
                   '云安县'
                  when 761445 then
                   '罗定市'
                  when 761446 then
                   '兴宁区'
                  when 761447 then
                   '青秀区'
                  when 761448 then
                   '江南区'
                  when 761449 then
                   '西乡塘区'
                  when 761450 then
                   '良庆区'
                  when 761451 then
                   '邕宁区'
                  when 761452 then
                   '武鸣县'
                  when 761453 then
                   '隆安县'
                  when 761454 then
                   '马山县'
                  when 761455 then
                   '上林县'
                  when 761456 then
                   '宾阳县'
                  when 761457 then
                   '横县'
                  when 761458 then
                   '城中区'
                  when 761459 then
                   '鱼峰区'
                  when 761460 then
                   '柳南区'
                  when 761461 then
                   '柳北区'
                  when 761462 then
                   '柳江县'
                  when 761463 then
                   '柳城县'
                  when 761464 then
                   '鹿寨县'
                  when 761465 then
                   '融安县'
                  when 761466 then
                   '融水苗族自治县'
                  when 761467 then
                   '三江侗族自治县'
                  when 761468 then
                   '秀峰区'
                  when 761469 then
                   '叠彩区'
                  when 761470 then
                   '象山区'
                  when 761471 then
                   '七星区'
                  when 761472 then
                   '雁山区'
                  when 761473 then
                   '阳朔县'
                  when 761474 then
                   '临桂县'
                  when 761475 then
                   '灵川县'
                  when 761476 then
                   '全州县'
                  when 761477 then
                   '兴安县'
                  when 761478 then
                   '永福县'
                  when 761479 then
                   '灌阳县'
                  when 761480 then
                   '龙胜各族自治县'
                  when 761481 then
                   '资源县'
                  when 761482 then
                   '平乐县'
                  when 761483 then
                   '荔蒲县'
                  when 761484 then
                   '恭城瑶族自治县'
                  when 761485 then
                   '万秀区'
                  when 761486 then
                   '蝶山区'
                  when 761487 then
                   '长洲区'
                  when 761488 then
                   '苍梧县'
                  when 761489 then
                   '藤县'
                  when 761490 then
                   '蒙山县'
                  when 761491 then
                   '岑溪市'
                  when 761492 then
                   '海城区'
                  when 761493 then
                   '银海区'
                  when 761494 then
                   '铁山港区'
                  when 761495 then
                   '合浦县'
                  when 761496 then
                   '港口区'
                  when 761497 then
                   '防城区'
                  when 761498 then
                   '上思县'
                  when 761499 then
                   '东兴市'
                  when 761500 then
                   '钦南区'
                  when 761501 then
                   '钦北区'
                  when 761502 then
                   '灵山县'
                  when 761503 then
                   '浦北县'
                  when 761504 then
                   '港北区'
                  when 761505 then
                   '港南区'
                  when 761506 then
                   '覃塘区'
                  when 761507 then
                   '平南县'
                  when 761508 then
                   '桂平市'
                  when 761509 then
                   '玉州区'
                  when 761510 then
                   '陆川县'
                  when 761511 then
                   '博白县'
                  when 761512 then
                   '兴业县'
                  when 761513 then
                   '北流市'
                  when 761514 then
                   '右江区'
                  when 761515 then
                   '田阳县'
                  when 761516 then
                   '田东县'
                  when 761517 then
                   '平果县'
                  when 761518 then
                   '德保县'
                  when 761519 then
                   '靖西县'
                  when 761520 then
                   '那坡县'
                  when 761521 then
                   '凌云县'
                  when 761522 then
                   '乐业县'
                  when 761523 then
                   '田林县'
                  when 761524 then
                   '西林县'
                  when 761525 then
                   '隆林各族自治县'
                  when 761526 then
                   '八步区'
                  when 761527 then
                   '昭平县'
                  when 761528 then
                   '钟山县'
                  when 761529 then
                   '富川瑶族自治县'
                  when 761530 then
                   '金城江区'
                  when 761531 then
                   '南丹县'
                  when 761532 then
                   '天峨县'
                  when 761533 then
                   '凤山县'
                  when 761534 then
                   '东兰县'
                  when 761535 then
                   '罗城仫佬族自治县'
                  when 761536 then
                   '环江毛南族自治县'
                  when 761537 then
                   '巴马瑶族自治县'
                  when 761538 then
                   '都安瑶族自治县'
                  when 761539 then
                   '大化瑶族自治县'
                  when 761540 then
                   '宜州市'
                  when 761541 then
                   '兴宾区'
                  when 761542 then
                   '忻城县'
                  when 761543 then
                   '象州县'
                  when 761544 then
                   '武宣县'
                  when 761545 then
                   '金秀瑶族自治县'
                  when 761546 then
                   '合山市'
                  when 761547 then
                   '江洲区'
                  when 761548 then
                   '扶绥县'
                  when 761549 then
                   '宁明县'
                  when 761550 then
                   '龙州县'
                  when 761551 then
                   '大新县'
                  when 761552 then
                   '天等县'
                  when 761553 then
                   '凭祥市'
                  when 761554 then
                   '秀英区'
                  when 761555 then
                   '龙华区'
                  when 761556 then
                   '琼山区'
                  when 761557 then
                   '美兰区'
                  when 761558 then
                   '五指山市'
                  when 761559 then
                   '琼海市'
                  when 761560 then
                   '儋州市'
                  when 761561 then
                   '文昌市'
                  when 761562 then
                   '万宁市'
                  when 761563 then
                   '东方市'
                  when 761564 then
                   '定安县'
                  when 761565 then
                   '屯昌县'
                  when 761566 then
                   '澄迈县'
                  when 761567 then
                   '临高县'
                  when 761568 then
                   '白沙黎族自治县'
                  when 761569 then
                   '昌江黎族自治县'
                  when 761570 then
                   '乐东黎族自治县'
                  when 761571 then
                   '陵水黎族自治县'
                  when 761572 then
                   '保亭黎族苗族自治县'
                  when 761573 then
                   '琼中黎族苗族自治县'
                  when 761574 then
                   '西沙群岛'
                  when 761575 then
                   '南沙群岛'
                  when 761700 then
                   '中沙群岛的岛礁及其海域'
                  when 761701 then
                   '自流井区'
                  when 761702 then
                   '贡井区'
                  when 761703 then
                   '大安区'
                  when 761704 then
                   '沿滩区'
                  when 761705 then
                   '荣县'
                  when 761706 then
                   '富顺县'
                  when 761707 then
                   '仁和区'
                  when 761708 then
                   '米易县'
                  when 761709 then
                   '盐边县'
                  when 761710 then
                   '江阳区'
                  when 761711 then
                   '纳溪区'
                  when 761712 then
                   '龙马潭区'
                  when 761713 then
                   '泸县'
                  when 761714 then
                   '合江县'
                  when 761715 then
                   '叙永县'
                  when 761716 then
                   '古蔺县'
                  when 761717 then
                   '旌阳区'
                  when 761718 then
                   '中江县'
                  when 761719 then
                   '罗江县'
                  when 761720 then
                   '广汉市'
                  when 761721 then
                   '什邡市'
                  when 761722 then
                   '绵竹市'
                  when 761723 then
                   '涪城区'
                  when 761724 then
                   '游仙区'
                  when 761725 then
                   '三台县'
                  when 761726 then
                   '盐亭县'
                  when 761727 then
                   '梓潼县'
                  when 761728 then
                   '北川羌族自治县'
                  when 761729 then
                   '平武县'
                  when 761730 then
                   '江油市'
                  when 761731 then
                   '市中区'
                  when 761732 then
                   '元坝区'
                  when 761733 then
                   '朝天区'
                  when 761734 then
                   '旺苍县'
                  when 761735 then
                   '青川县'
                  when 761736 then
                   '剑阁县'
                  when 761737 then
                   '苍溪县'
                  when 761738 then
                   '船山区'
                  when 761164 then
                   '丹江口市'
                  when 761165 then
                   '西陵区'
                  when 761745 then
                   '资中县'
                  when 761746 then
                   '隆昌县'
                  when 761747 then
                   '沙湾区'
                  when 761748 then
                   '五通桥区'
                  when 761749 then
                   '金口河区'
                  when 761750 then
                   '犍为县'
                  when 761751 then
                   '井研县'
                  when 761752 then
                   '夹江县'
                  when 761753 then
                   '沐川县'
                  when 761754 then
                   '峨边彝族自治县'
                  when 761755 then
                   '马边彝族自治县'
                  when 761756 then
                   '峨眉山市'
                  when 761757 then
                   '顺庆区'
                  when 761758 then
                   '高坪区'
                  when 761759 then
                   '嘉陵区'
                  when 761760 then
                   '南部县'
                  when 761761 then
                   '营山县'
                  when 761762 then
                   '蓬安县'
                  when 761763 then
                   '仪陇县'
                  when 761764 then
                   '西充县'
                  when 761765 then
                   '阆中市'
                  when 761766 then
                   '东坡区'
                  when 761767 then
                   '仁寿县'
                  when 761768 then
                   '彭山县'
                  when 761769 then
                   '洪雅县'
                  when 761770 then
                   '丹棱县'
                  when 761771 then
                   '青神县'
                  when 761772 then
                   '翠屏区'
                  when 761773 then
                   '宜宾县'
                  when 761774 then
                   '南溪县'
                  when 761775 then
                   '江安县'
                  when 761776 then
                   '长宁县'
                  when 761777 then
                   '珙县'
                  when 761778 then
                   '筠连县'
                  when 761779 then
                   '兴文县'
                  when 761780 then
                   '屏山县'
                  when 761781 then
                   '广安区'
                  when 761782 then
                   '岳池县'
                  when 761783 then
                   '武胜县'
                  when 761784 then
                   '邻水县'
                  when 761785 then
                   '华蓥市'
                  when 761786 then
                   '通川区'
                  when 761787 then
                   '达县'
                  when 761788 then
                   '宣汉县'
                  when 761789 then
                   '开江县'
                  when 761790 then
                   '大竹县'
                  when 761791 then
                   '渠县'
                  when 761792 then
                   '万源市'
                  when 761793 then
                   '雨城区'
                  when 761794 then
                   '名山县'
                  when 761795 then
                   '荥经县'
                  when 761796 then
                   '汉源县'
                  when 761797 then
                   '石棉县'
                  when 761798 then
                   '天全县'
                  when 761799 then
                   '芦山县'
                  when 761800 then
                   '宝兴县'
                  when 761801 then
                   '巴州区'
                  when 761802 then
                   '通江县'
                  when 761803 then
                   '南江县'
                  when 761804 then
                   '平昌县'
                  when 761805 then
                   '雁江区'
                  when 761806 then
                   '安岳县'
                  when 761807 then
                   '乐至县'
                  when 761808 then
                   '简阳市'
                  when 761809 then
                   '南明区'
                  when 761810 then
                   '云岩区'
                  when 761811 then
                   '花溪区'
                  when 761812 then
                   '乌当区'
                  when 761813 then
                   '小河区'
                  when 761814 then
                   '开阳县'
                  when 761815 then
                   '息烽县'
                  when 761816 then
                   '修文县'
                  when 761817 then
                   '清镇市'
                  when 761818 then
                   '钟山区'
                  when 761819 then
                   '六枝特区'
                  when 761820 then
                   '水城县'
                  when 761821 then
                   '盘县'
                  when 761822 then
                   '红花岗区'
                  when 761823 then
                   '汇川区'
                  when 761824 then
                   '遵义县'
                  when 761825 then
                   '桐梓县'
                  when 761826 then
                   '绥阳县'
                  when 761827 then
                   '正安县'
                  when 761828 then
                   '道真仡佬族苗族自治县'
                  when 761829 then
                   '务川仡佬族苗族自治县'
                  when 761830 then
                   '凤冈县'
                  when 761831 then
                   '湄潭县'
                  when 761832 then
                   '余庆县'
                  when 761833 then
                   '习水县'
                  when 761834 then
                   '赤水市'
                  when 761835 then
                   '仁怀市'
                  when 761836 then
                   '西秀区'
                  when 761837 then
                   '平坝县'
                  when 761838 then
                   '普定县'
                  when 761839 then
                   '镇宁布依族苗族自治县'
                  when 761840 then
                   '关岭布依族苗族自治县'
                  when 761841 then
                   '紫云苗族布依族自治县'
                  when 761842 then
                   '铜仁市'
                  when 761843 then
                   '江口县'
                  when 761844 then
                   '玉屏侗族自治县'
                  when 761845 then
                   '石阡县'
                  when 761846 then
                   '思南县'
                  when 761847 then
                   '印江土家族苗族自治县'
                  when 761848 then
                   '德江县'
                  when 761849 then
                   '沿河土家族自治县'
                  when 761850 then
                   '松桃苗族自治县'
                  when 761851 then
                   '万山特区'
                  when 761852 then
                   '毕节市'
                  when 761853 then
                   '大方县'
                  when 761854 then
                   '黔西县'
                  when 761855 then
                   '金沙县'
                  when 761856 then
                   '织金县'
                  when 761857 then
                   '纳雍县'
                  when 761858 then
                   '威宁彝族回族苗族自治县'
                  when 761859 then
                   '赫章县'
                  when 761860 then
                   '五华区'
                  when 761861 then
                   '盘龙区'
                  when 761862 then
                   '官渡区'
                  when 761863 then
                   '西山区'
                  when 761864 then
                   '东川区'
                  when 761865 then
                   '呈贡县'
                  when 761866 then
                   '晋宁县'
                  when 761867 then
                   '富民县'
                  when 761868 then
                   '宜良县'
                  when 761869 then
                   '石林彝族自治县'
                  when 761870 then
                   '嵩明县'
                  when 761871 then
                   '禄劝彝族苗族自治县'
                  when 761872 then
                   '寻甸回族彝族自治县'
                  when 761873 then
                   '安宁市'
                  when 761874 then
                   '麒麟区'
                  when 761875 then
                   '马龙县'
                  when 761876 then
                   '陆良县'
                  when 761877 then
                   '师宗县'
                  when 761878 then
                   '罗平县'
                  when 761879 then
                   '富源县'
                  when 761880 then
                   '会泽县'
                  when 761881 then
                   '沾益县'
                  when 761882 then
                   '宣威市'
                  when 761883 then
                   '红塔区'
                  when 761884 then
                   '江川县'
                  when 761885 then
                   '澄江县'
                  when 761886 then
                   '通海县'
                  when 761887 then
                   '华宁县'
                  when 761888 then
                   '易门县'
                  when 761889 then
                   '峨山彝族自治县'
                  when 761890 then
                   '新平彝族傣族自治县'
                  when 761891 then
                   '元江哈尼族彝族傣族自治县'
                  when 761892 then
                   '隆阳区'
                  when 761893 then
                   '施甸县'
                  when 761894 then
                   '腾冲县'
                  when 761895 then
                   '龙陵县'
                  when 761896 then
                   '昌宁县'
                  when 761897 then
                   '昭阳区'
                  when 761898 then
                   '鲁甸县'
                  when 761899 then
                   '巧家县'
                  when 761900 then
                   '盐津县'
                  when 761901 then
                   '大关县'
                  when 761902 then
                   '永善县'
                  when 761903 then
                   '绥江县'
                  when 761904 then
                   '镇雄县'
                  when 761905 then
                   '彝良县'
                  when 761906 then
                   '威信县'
                  when 761907 then
                   '水富县'
                  when 761908 then
                   '古城区'
                  when 761909 then
                   '玉龙纳西族自治县'
                  when 761910 then
                   '永胜县'
                  when 761911 then
                   '华坪县'
                  when 761912 then
                   '宁蒗彝族自治县'
                  when 761913 then
                   '翠云区'
                  when 761914 then
                   '宁洱哈尼族彝族自治县'
                  when 761915 then
                   '墨江哈尼族自治县'
                  when 761916 then
                   '景东彝族自治县'
                  when 761917 then
                   '景谷傣族彝族自治县'
                  when 761918 then
                   '镇沅彝族哈尼族拉祜族自治县'
                  when 761919 then
                   '江城哈尼族彝族自治县'
                  when 761920 then
                   '孟连傣族拉祜族佤族自治县'
                  when 761921 then
                   '澜沧拉祜族自治县'
                  when 761922 then
                   '西盟佤族自治县'
                  when 761923 then
                   '临翔区'
                  when 761924 then
                   '凤庆县'
                  when 761925 then
                   '永德县'
                  when 761926 then
                   '镇康县'
                  when 761927 then
                   '双江拉祜族佤族布朗族傣族自治县'
                  when 761928 then
                   '耿马傣族佤族自治县'
                  when 761929 then
                   '沧源佤族自治县'
                  when 761930 then
                   '城关区'
                  when 761931 then
                   '林周县'
                  when 761932 then
                   '当雄县'
                  when 761933 then
                   '尼木县'
                  when 761934 then
                   '曲水县'
                  when 761935 then
                   '堆龙德庆县'
                  when 761936 then
                   '达孜县'
                  when 761937 then
                   '墨竹工卡县'
                  when 761938 then
                   '昌都县'
                  when 761939 then
                   '江达县'
                  when 761940 then
                   '贡觉县'
                  when 761941 then
                   '类乌齐县'
                  when 761942 then
                   '丁青县'
                  when 761943 then
                   '察雅县'
                  when 761944 then
                   '八宿县'
                  when 761945 then
                   '左贡县'
                  when 761946 then
                   '芒康县'
                  when 761947 then
                   '洛隆县'
                  when 761948 then
                   '边坝县'
                  when 761949 then
                   '乃东县'
                  when 761950 then
                   '扎囊县'
                  when 761951 then
                   '贡嘎县'
                  when 761952 then
                   '桑日县'
                  when 761953 then
                   '琼结县'
                  when 761954 then
                   '曲松县'
                  when 761955 then
                   '措美县'
                  when 761956 then
                   '洛扎县'
                  when 761957 then
                   '加查县'
                  when 761958 then
                   '隆子县'
                  when 761959 then
                   '错那县'
                  when 761960 then
                   '浪卡子县'
                  when 761961 then
                   '日喀则市'
                  when 761962 then
                   '南木林县'
                  when 761963 then
                   '江孜县'
                  when 761964 then
                   '定日县'
                  when 761965 then
                   '萨迦县'
                  when 761966 then
                   '拉孜县'
                  when 761967 then
                   '昂仁县'
                  when 761968 then
                   '谢通门县'
                  when 761969 then
                   '白朗县'
                  when 761970 then
                   '仁布县'
                  when 761971 then
                   '康马县'
                  when 761972 then
                   '定结县'
                  when 761973 then
                   '仲巴县'
                  when 761974 then
                   '亚东县'
                  when 761975 then
                   '吉隆县'
                  when 761976 then
                   '聂拉木县'
                  when 761977 then
                   '萨嘎县'
                  when 761978 then
                   '岗巴县'
                  when 761979 then
                   '那曲县'
                  when 761980 then
                   '嘉黎县'
                  when 761981 then
                   '比如县'
                  when 761982 then
                   '聂荣县'
                  when 761983 then
                   '安多县'
                  when 761984 then
                   '申扎县'
                  when 761985 then
                   '索县'
                  when 761986 then
                   '班戈县'
                  when 761987 then
                   '巴青县'
                  when 761988 then
                   '尼玛县'
                  when 761989 then
                   '普兰县'
                  when 761990 then
                   '札达县'
                  when 761991 then
                   '噶尔县'
                  when 761992 then
                   '日土县'
                  when 761993 then
                   '革吉县'
                  when 761994 then
                   '改则县'
                  when 761995 then
                   '措勤县'
                  when 761996 then
                   '林芝县'
                  when 761997 then
                   '工布江达县'
                  when 761998 then
                   '米林县'
                  when 761999 then
                   '墨脱县'
                  when 762000 then
                   '波密县'
                  when 762001 then
                   '察隅县'
                  when 762002 then
                   '新城区'
                  when 762003 then
                   '碑林区'
                  when 762004 then
                   '莲湖区'
                  when 762005 then
                   '灞桥区'
                  when 762006 then
                   '未央区'
                  when 762007 then
                   '雁塔区'
                  when 762008 then
                   '阎良区'
                  when 762009 then
                   '临潼区'
                  when 762010 then
                   '长安区'
                  when 762011 then
                   '蓝田县'
                  when 762012 then
                   '周至县'
                  when 762013 then
                   '户县'
                  when 762014 then
                   '高陵县'
                  when 762015 then
                   '王益区'
                  when 762016 then
                   '印台区'
                  when 762017 then
                   '耀州区'
                  when 762018 then
                   '宜君县'
                  when 762019 then
                   '渭滨区'
                  when 762020 then
                   '金台区'
                  when 762021 then
                   '陈仓区'
                  when 762022 then
                   '凤翔县'
                  when 762023 then
                   '岐山县'
                  when 762024 then
                   '扶风县'
                  when 762025 then
                   '眉县'
                  when 762026 then
                   '千阳县'
                  when 762027 then
                   '麟游县'
                  when 762028 then
                   '凤县'
                  when 762029 then
                   '太白县'
                  when 762030 then
                   '秦都区'
                  when 762031 then
                   '杨凌区'
                  when 762032 then
                   '渭城区'
                  when 762033 then
                   '三原县'
                  when 762034 then
                   '泾阳县'
                  when 762035 then
                   '乾县'
                  when 762036 then
                   '礼泉县'
                  when 762037 then
                   '永寿县'
                  when 762038 then
                   '彬县'
                  when 762039 then
                   '长武县'
                  when 762040 then
                   '旬邑县'
                  when 762041 then
                   '淳化县'
                  when 762042 then
                   '武功县'
                  when 762043 then
                   '兴平市'
                  when 762044 then
                   '临渭区'
                  when 762045 then
                   '潼关县'
                  when 762046 then
                   '大荔县'
                  when 762047 then
                   '合阳县'
                  when 762048 then
                   '澄城县'
                  when 762049 then
                   '蒲城县'
                  when 762050 then
                   '白水县'
                  when 762051 then
                   '富平县'
                  when 762052 then
                   '韩城市'
                  when 762053 then
                   '华阴市'
                  when 762054 then
                   '宝塔区'
                  when 762055 then
                   '延长县'
                  when 762056 then
                   '延川县'
                  when 762057 then
                   '子长县'
                  when 762058 then
                   '安塞县'
                  when 762059 then
                   '志丹县'
                  when 762060 then
                   '吴旗县'
                  when 762061 then
                   '甘泉县'
                  when 762062 then
                   '洛川县'
                  when 762063 then
                   '宜川县'
                  when 762064 then
                   '黄龙县'
                  when 762065 then
                   '黄陵县'
                  when 762066 then
                   '汉台区'
                  when 762067 then
                   '南郑县'
                  when 762068 then
                   '城固县'
                  when 762069 then
                   '西乡县'
                  when 762070 then
                   '勉县'
                  when 762071 then
                   '宁强县'
                  when 762072 then
                   '略阳县'
                  when 762073 then
                   '镇巴县'
                  when 762074 then
                   '留坝县'
                  when 762075 then
                   '佛坪县'
                  when 762076 then
                   '榆阳区'
                  when 762077 then
                   '神木县'
                  when 762078 then
                   '府谷县'
                  when 762079 then
                   '横山县'
                  when 762080 then
                   '靖边县'
                  when 762081 then
                   '定边县'
                  when 762082 then
                   '绥德县'
                  when 762083 then
                   '米脂县'
                  when 762084 then
                   '佳县'
                  when 762085 then
                   '吴堡县'
                  when 762086 then
                   '清涧县'
                  when 762087 then
                   '子洲县'
                  when 762088 then
                   '汉滨区'
                  when 762089 then
                   '汉阴县'
                  when 762090 then
                   '石泉县'
                  when 762091 then
                   '宁陕县'
                  when 762092 then
                   '紫阳县'
                  when 762093 then
                   '岚皋县'
                  when 762094 then
                   '平利县'
                  when 762095 then
                   '镇坪县'
                  when 762096 then
                   '旬阳县'
                  when 762097 then
                   '白河县'
                  when 762098 then
                   '商州区'
                  when 762099 then
                   '洛南县'
                  when 762100 then
                   '丹凤县'
                  when 762101 then
                   '商南县'
                  when 762102 then
                   '山阳县'
                  when 762103 then
                   '镇安县'
                  when 762104 then
                   '柞水县'
                  when 762105 then
                   '七里河区'
                  when 762106 then
                   '西固区'
                  when 762107 then
                   '安宁区'
                  when 762108 then
                   '红古区'
                  when 762109 then
                   '永登县'
                  when 762110 then
                   '皋兰县'
                  when 762111 then
                   '榆中县'
                  when 762112 then
                   '金川区'
                  when 762113 then
                   '永昌县'
                  when 762114 then
                   '白银区'
                  when 762115 then
                   '平川区'
                  when 762116 then
                   '靖远县'
                  when 762117 then
                   '会宁县'
                  when 762118 then
                   '景泰县'
                  when 762119 then
                   '秦城区'
                  when 762120 then
                   '北道区'
                  when 762121 then
                   '清水县'
                  when 762122 then
                   '秦安县'
                  when 762123 then
                   '甘谷县'
                  when 762124 then
                   '武山县'
                  when 762125 then
                   '张家川回族自治县'
                  when 762126 then
                   '凉州区'
                  when 762127 then
                   '民勤县'
                  when 762128 then
                   '古浪县'
                  when 762129 then
                   '天祝藏族自治县'
                  when 762130 then
                   '甘州区'
                  when 762131 then
                   '肃南裕固族自治县'
                  when 762132 then
                   '民乐县'
                  when 762133 then
                   '临泽县'
                  when 762134 then
                   '高台县'
                  when 762135 then
                   '山丹县'
                  when 762136 then
                   '崆峒区'
                  when 762137 then
                   '泾川县'
                  when 762138 then
                   '灵台县'
                  when 762139 then
                   '崇信县'
                  when 762140 then
                   '华亭县'
                  when 762141 then
                   '庄浪县'
                  when 762142 then
                   '静宁县'
                  when 762143 then
                   '肃州区'
                  when 762144 then
                   '金塔县'
                  when 762145 then
                   '安西县'
                  when 762146 then
                   '肃北蒙古族自治县'
                  when 762147 then
                   '阿克塞哈萨克族自治县'
                  when 762148 then
                   '玉门市'
                  when 762149 then
                   '敦煌市'
                  when 762150 then
                   '西峰区'
                  when 762151 then
                   '庆城县'
                  when 762152 then
                   '环县'
                  when 762153 then
                   '华池县'
                  when 762154 then
                   '合水县'
                  when 762155 then
                   '正宁县'
                  when 762156 then
                   '镇原县'
                  when 762157 then
                   '安定区'
                  when 762158 then
                   '通渭县'
                  when 762159 then
                   '陇西县'
                  when 762160 then
                   '渭源县'
                  when 762161 then
                   '临洮县'
                  when 762162 then
                   '岷县'
                  when 762163 then
                   '武都区'
                  when 762164 then
                   '成县'
                  when 762165 then
                   '宕昌县'
                  when 762166 then
                   '西和县'
                  when 762167 then
                   '礼县'
                  when 762168 then
                   '徽县'
                  when 762169 then
                   '两当县'
                  when 762170 then
                   '城东区'
                  when 762171 then
                   '城西区'
                  when 762172 then
                   '城北区'
                  when 762173 then
                   '大通回族土族自治县'
                  when 762174 then
                   '湟中县'
                  when 762175 then
                   '湟源县'
                  when 762176 then
                   '平安县'
                  when 762177 then
                   '民和回族土族自治县'
                  when 762178 then
                   '乐都县'
                  when 762179 then
                   '互助土族自治县'
                  when 762180 then
                   '化隆回族自治县'
                  when 762181 then
                   '循化撒拉族自治县'
                  when 762182 then
                   '兴庆区'
                  when 762183 then
                   '西夏区'
                  when 762184 then
                   '金凤区'
                  when 762185 then
                   '永宁县'
                  when 762186 then
                   '贺兰县'
                  when 762187 then
                   '灵武市'
                  when 762188 then
                   '大武口区'
                  when 762189 then
                   '惠农区'
                  when 762190 then
                   '平罗县'
                  when 762191 then
                   '利通区'
                  when 762192 then
                   '盐池县'
                  when 762193 then
                   '同心县'
                  when 762194 then
                   '青铜峡市'
                  when 762195 then
                   '原州区'
                  when 762196 then
                   '西吉县'
                  when 762197 then
                   '隆德县'
                  when 762198 then
                   '泾源县'
                  when 762199 then
                   '彭阳县'
                  when 762200 then
                   '沙坡头区'
                  when 762201 then
                   '中宁县'
                  when 762202 then
                   '海原县'
                  when 762203 then
                   '天山区'
                  when 762204 then
                   '沙依巴克区'
                  when 762205 then
                   '新市区'
                  when 762206 then
                   '水磨沟区'
                  when 762207 then
                   '头屯河区'
                  when 762208 then
                   '达坂城区'
                  when 762209 then
                   '乌鲁木齐县'
                  when 762210 then
                   '独山子区'
                  when 762211 then
                   '克拉玛依区'
                  when 762212 then
                   '白碱滩区'
                  when 762213 then
                   '乌尔禾区'
                  when 762214 then
                   '吐鲁番市'
                  when 762215 then
                   '鄯善县'
                  when 762216 then
                   '托克逊县'
                  when 762217 then
                   '哈密市'
                  when 762218 then
                   '巴里坤哈萨克自治县'
                  when 762219 then
                   '伊吾县'
                  when 762220 then
                   '阿克苏市'
                  when 762221 then
                   '温宿县'
                  when 762222 then
                   '库车县'
                  when 762223 then
                   '沙雅县'
                  when 762224 then
                   '新和县'
                  when 762225 then
                   '拜城县'
                  when 762226 then
                   '乌什县'
                  when 762227 then
                   '阿瓦提县'
                  when 762228 then
                   '柯坪县'
                  when 762229 then
                   '喀什市'
                  when 762230 then
                   '疏附县'
                  when 762231 then
                   '疏勒县'
                  when 762232 then
                   '英吉沙县'
                  when 762233 then
                   '泽普县'
                  when 762234 then
                   '莎车县'
                  when 762235 then
                   '叶城县'
                  when 762236 then
                   '麦盖提县'
                  when 762237 then
                   '岳普湖县'
                  when 762238 then
                   '伽师县'
                  when 762239 then
                   '巴楚县'
                  when 762240 then
                   '塔什库尔干塔吉克自治县'
                  when 762241 then
                   '和田市'
                  when 762242 then
                   '和田县'
                  when 762243 then
                   '墨玉县'
                  when 762244 then
                   '皮山县'
                  when 762245 then
                   '洛浦县'
                  when 762246 then
                   '策勒县'
                  when 762247 then
                   '于田县'
                  when 762248 then
                   '民丰县'
                  when 762249 then
                   '塔城市'
                  when 762250 then
                   '乌苏市'
                  when 762251 then
                   '额敏县'
                  when 762252 then
                   '沙湾县'
                  when 762253 then
                   '托里县'
                  when 762254 then
                   '裕民县'
                  when 762255 then
                   '和布克赛尔蒙古自治县'
                  when 762256 then
                   '阿勒泰市'
                  when 762257 then
                   '布尔津县'
                  when 762258 then
                   '富蕴县'
                  when 762259 then
                   '福海县'
                  when 762260 then
                   '哈巴河县'
                  when 762261 then
                   '青河县'
                  when 762262 then
                   '吉木乃县'
                  when 762263 then
                   '延吉市'
                  when 762264 then
                   '图们市'
                  when 762265 then
                   '敦化市'
                  when 762266 then
                   '珲春市'
                  when 762267 then
                   '龙井市'
                  when 762268 then
                   '和龙市'
                  when 762269 then
                   '汪清县'
                  when 762270 then
                   '安图县'
                  when 762271 then
                   '恩施市'
                  when 762272 then
                   '利川市'
                  when 762273 then
                   '建始县'
                  when 762274 then
                   '巴东县'
                  when 762275 then
                   '宣恩县'
                  when 762276 then
                   '咸丰县'
                  when 762277 then
                   '来凤县'
                  when 762278 then
                   '鹤峰县'
                  when 762279 then
                   '吉首市'
                  when 762280 then
                   '泸溪县'
                  when 762281 then
                   '凤凰县'
                  when 762282 then
                   '花垣县'
                  when 762283 then
                   '保靖县'
                  when 762284 then
                   '古丈县'
                  when 762285 then
                   '永顺县'
                  when 762286 then
                   '龙山县'
                  when 762287 then
                   '汶川县'
                  when 762288 then
                   '理县'
                  when 762289 then
                   '茂县'
                  when 762290 then
                   '松潘县'
                  when 762291 then
                   '九寨沟县'
                  when 762292 then
                   '金川县'
                  when 762293 then
                   '小金县'
                  when 762294 then
                   '黑水县'
                  when 762295 then
                   '马尔康县'
                  when 762296 then
                   '壤塘县'
                  when 762297 then
                   '阿坝县'
                  when 762298 then
                   '若尔盖县'
                  when 762299 then
                   '红原县'
                  when 762300 then
                   '康定县'
                  when 762301 then
                   '泸定县'
                  when 762302 then
                   '丹巴县'
                  when 762303 then
                   '九龙县'
                  when 762304 then
                   '雅江县'
                  when 762305 then
                   '道孚县'
                  when 762306 then
                   '炉霍县'
                  when 762307 then
                   '甘孜县'
                  when 762308 then
                   '新龙县'
                  when 762309 then
                   '德格县'
                  when 762310 then
                   '白玉县'
                  when 762311 then
                   '石渠县'
                  when 762312 then
                   '色达县'
                  when 762313 then
                   '理塘县'
                  when 762314 then
                   '巴塘县'
                  when 762315 then
                   '乡城县'
                  when 762316 then
                   '稻城县'
                  when 762317 then
                   '得荣县'
                  when 762318 then
                   '西昌市'
                  when 762319 then
                   '木里藏族自治县'
                  when 762320 then
                   '盐源县'
                  when 762321 then
                   '德昌县'
                  when 762322 then
                   '会理县'
                  when 762323 then
                   '会东县'
                  when 762324 then
                   '宁南县'
                  when 762325 then
                   '普格县'
                  when 762326 then
                   '布拖县'
                  when 762327 then
                   '金阳县'
                  when 762328 then
                   '昭觉县'
                  when 762329 then
                   '喜德县'
                  when 762330 then
                   '冕宁县'
                  when 762331 then
                   '越西县'
                  when 762332 then
                   '甘洛县'
                  when 762333 then
                   '美姑县'
                  when 762334 then
                   '雷波县'
                  when 762335 then
                   '兴义市'
                  when 762336 then
                   '兴仁县'
                  when 762337 then
                   '普安县'
                  when 762338 then
                   '晴隆县'
                  when 762339 then
                   '贞丰县'
                  when 762340 then
                   '望谟县'
                  when 762341 then
                   '册亨县'
                  when 762342 then
                   '安龙县'
                  when 762343 then
                   '凯里市'
                  when 762344 then
                   '黄平县'
                  when 762345 then
                   '施秉县'
                  when 762346 then
                   '三穗县'
                  when 762347 then
                   '镇远县'
                  when 762348 then
                   '岑巩县'
                  when 762349 then
                   '天柱县'
                  when 762350 then
                   '锦屏县'
                  when 762351 then
                   '剑河县'
                  when 762352 then
                   '台江县'
                  when 762353 then
                   '黎平县'
                  when 762354 then
                   '榕江县'
                  when 762355 then
                   '从江县'
                  when 762356 then
                   '雷山县'
                  when 762357 then
                   '麻江县'
                  when 762358 then
                   '丹寨县'
                  when 762359 then
                   '都匀市'
                  when 762360 then
                   '福泉市'
                  when 762361 then
                   '荔波县'
                  when 762362 then
                   '贵定县'
                  when 762363 then
                   '瓮安县'
                  when 762364 then
                   '独山县'
                  when 762365 then
                   '平塘县'
                  when 762366 then
                   '罗甸县'
                  when 762367 then
                   '长顺县'
                  when 762368 then
                   '龙里县'
                  when 762369 then
                   '惠水县'
                  when 762370 then
                   '三都水族自治县'
                  when 762371 then
                   '楚雄市'
                  when 762372 then
                   '双柏县'
                  when 762373 then
                   '牟定县'
                  when 762374 then
                   '南华县'
                  when 762375 then
                   '姚安县'
                  when 762376 then
                   '大姚县'
                  when 762377 then
                   '永仁县'
                  when 762378 then
                   '元谋县'
                  when 762379 then
                   '武定县'
                  when 762380 then
                   '禄丰县'
                  when 762381 then
                   '个旧市'
                  when 762382 then
                   '开远市'
                  when 762383 then
                   '蒙自县'
                  when 762384 then
                   '屏边苗族自治县'
                  when 762385 then
                   '建水县'
                  when 762386 then
                   '石屏县'
                  when 762387 then
                   '弥勒县'
                  when 762388 then
                   '泸西县'
                  when 762389 then
                   '元阳县'
                  when 762390 then
                   '红河县'
                  when 762391 then
                   '金平苗族瑶族傣族自治县'
                  when 762392 then
                   '绿春县'
                  when 762393 then
                   '河口瑶族自治县'
                  when 762394 then
                   '文山县'
                  when 762395 then
                   '砚山县'
                  when 762396 then
                   '西畴县'
                  when 762397 then
                   '麻栗坡县'
                  when 762398 then
                   '马关县'
                  when 762399 then
                   '丘北县'
                  when 762400 then
                   '广南县'
                  when 762401 then
                   '富宁县'
                  when 762402 then
                   '景洪市'
                  when 762403 then
                   '勐海县'
                  when 762404 then
                   '勐腊县'
                  when 762405 then
                   '大理市'
                  when 762406 then
                   '漾濞彝族自治县'
                  when 762407 then
                   '祥云县'
                  when 762408 then
                   '宾川县'
                  when 762409 then
                   '弥渡县'
                  when 762410 then
                   '南涧彝族自治县'
                  when 762411 then
                   '巍山彝族回族自治县'
                  when 762412 then
                   '永平县'
                  when 762413 then
                   '云龙县'
                  when 762414 then
                   '洱源县'
                  when 762415 then
                   '剑川县'
                  when 762416 then
                   '鹤庆县'
                  when 762417 then
                   '瑞丽市'
                  when 762418 then
                   '潞西市'
                  when 762419 then
                   '梁河县'
                  when 762420 then
                   '盈江县'
                  when 762421 then
                   '陇川县'
                  when 762422 then
                   '泸水县'
                  when 762423 then
                   '福贡县'
                  when 762424 then
                   '贡山独龙族怒族自治县'
                  when 762425 then
                   '兰坪白族普米族自治县'
                  when 762426 then
                   '香格里拉县'
                  when 762427 then
                   '德钦县'
                  when 762428 then
                   '维西傈僳族自治县'
                  when 762429 then
                   '临夏市'
                  when 762430 then
                   '临夏县'
                  when 762431 then
                   '康乐县'
                  when 762432 then
                   '永靖县'
                  when 762433 then
                   '广河县'
                  when 762434 then
                   '和政县'
                  when 762435 then
                   '东乡族自治县'
                  when 762436 then
                   '积石山保安族东乡族撒拉族自治县'
                  when 762437 then
                   '合作市'
                  when 762438 then
                   '临潭县'
                  when 762439 then
                   '卓尼县'
                  when 762440 then
                   '舟曲县'
                  when 762441 then
                   '迭部县'
                  when 762442 then
                   '玛曲县'
                  when 762443 then
                   '碌曲县'
                  when 762444 then
                   '夏河县'
                  when 762445 then
                   '门源回族自治县'
                  when 762446 then
                   '祁连县'
                  when 762447 then
                   '海晏县'
                  when 762448 then
                   '刚察县'
                  when 762449 then
                   '同仁县'
                  when 762450 then
                   '尖扎县'
                  when 762451 then
                   '泽库县'
                  when 762452 then
                   '河南蒙古族自治县'
                  when 762453 then
                   '共和县'
                  when 762454 then
                   '同德县'
                  when 762455 then
                   '贵德县'
                  when 762456 then
                   '兴海县'
                  when 762457 then
                   '贵南县'
                  when 762458 then
                   '玛沁县'
                  when 762459 then
                   '班玛县'
                  when 762460 then
                   '甘德县'
                  when 762461 then
                   '达日县'
                  when 762462 then
                   '久治县'
                  when 762463 then
                   '玛多县'
                  when 762464 then
                   '玉树县'
                  when 762465 then
                   '杂多县'
                  when 762466 then
                   '称多县'
                  when 762467 then
                   '治多县'
                  when 762468 then
                   '囊谦县'
                  when 762469 then
                   '曲麻莱县'
                  when 762470 then
                   '格尔木市'
                  when 762471 then
                   '德令哈市'
                  when 762472 then
                   '乌兰县'
                  when 762473 then
                   '都兰县'
                  when 762474 then
                   '天峻县'
                  when 762475 then
                   '昌吉市'
                  when 762476 then
                   '阜康市'
                  when 762477 then
                   '米泉市'
                  when 762478 then
                   '呼图壁县'
                  when 762479 then
                   '玛纳斯县'
                  when 762480 then
                   '奇台县'
                  when 762481 then
                   '吉木萨尔县'
                  when 762482 then
                   '木垒哈萨克自治县'
                  when 762483 then
                   '博乐市'
                  when 762484 then
                   '精河县'
                  when 762485 then
                   '温泉县'
                  when 762486 then
                   '库尔勒市'
                  when 762487 then
                   '轮台县'
                  when 762488 then
                   '尉犁县'
                  when 762489 then
                   '若羌县'
                  when 762490 then
                   '且末县'
                  when 762491 then
                   '焉耆回族自治县'
                  when 762492 then
                   '和静县'
                  when 762493 then
                   '和硕县'
                  when 762494 then
                   '博湖县'
                  when 762495 then
                   '阿图什市'
                  when 762496 then
                   '阿克陶县'
                  when 762497 then
                   '阿合奇县'
                  when 762498 then
                   '乌恰县'
                  when 762499 then
                   '伊宁市'
                  when 762500 then
                   '奎屯市'
                  when 762501 then
                   '伊宁县'
                  when 762502 then
                   '察布查尔锡伯自治县'
                  when 762503 then
                   '霍城县'
                  when 762504 then
                   '巩留县'
                  when 762505 then
                   '新源县'
                  when 762506 then
                   '昭苏县'
                  when 762507 then
                   '特克斯县'
                  when 762508 then
                   '尼勒克县'
                  when 762509 then
                   '平谷区'
                  when 762510 then
                   '密云县'
                  when 762511 then
                   '延庆县'
                  when 762512 then
                   '二七区'
                  when 762513 then
                   '管城回族区'
                  when 762514 then
                   '上街区'
                  when 762515 then
                   '中牟县'
                  when 762516 then
                   '巩义市'
                  when 762517 then
                   '荥阳市'
                  when 762518 then
                   '新密市'
                  when 762519 then
                   '新郑市'
                  when 762520 then
                   '登封市'
                  when 762521 then
                   '香坊区'
                  when 762522 then
                   '动力区'
                  when 762523 then
                   '平房区'
                  when 762524 then
                   '松北区'
                  when 762525 then
                   '呼兰区'
                  when 762526 then
                   '依兰县'
                  when 762527 then
                   '方正县'
                  when 762528 then
                   '巴彦县'
                  when 762529 then
                   '木兰县'
                  when 762530 then
                   '通河县'
                  when 762531 then
                   '延寿县'
                  when 762532 then
                   '阿城市'
                  when 762533 then
                   '双城市'
                  when 762534 then
                   '五常市'
                  when 2242150 then
                   '工业园区'
                  when 762536 then
                   '龙泉驿区'
                  when 762537 then
                   '青白江区'
                  when 762538 then
                   '温江区'
                  when 762539 then
                   '金堂县'
                  when 762540 then
                   '双流县'
                  when 762541 then
                   '郫县'
                  when 762542 then
                   '大邑县'
                  when 762543 then
                   '蒲江县'
                  when 762544 then
                   '新津县'
                  when 762545 then
                   '都江堰市'
                  when 762546 then
                   '彭州市'
                  when 762547 then
                   '邛崃市'
                  when 762548 then
                   '崇州市'
                  when 762549 then
                   '万州区'
                  when 762550 then
                   '涪陵区'
                  when 762551 then
                   '大渡口区'
                  when 762552 then
                   '北碚区'
                  when 762553 then
                   '万盛区'
                  when 762554 then
                   '双桥区'
                  when 762555 then
                   '黔江区'
                  when 762556 then
                   '綦江县'
                  when 762557 then
                   '潼南县'
                  when 762558 then
                   '铜梁县'
                  when 762559 then
                   '大足县'
                  when 762560 then
                   '荣昌县'
                  when 762561 then
                   '璧山县'
                  when 762562 then
                   '梁平县'
                  when 762563 then
                   '城口县'
                  when 762564 then
                   '丰都县'
                  when 762565 then
                   '垫江县'
                  when 762566 then
                   '武隆县'
                  when 762567 then
                   '忠县'
                  when 762568 then
                   '云阳县'
                  when 762569 then
                   '奉节县'
                  when 762570 then
                   '巫山县'
                  when 762571 then
                   '巫溪县'
                  when 762572 then
                   '石柱土家族自治县'
                  when 762573 then
                   '秀山土家族苗族自治县'
                  when 762574 then
                   '酉阳土家族苗族自治县'
                  when 762575 then
                   '彭水苗族土家族自治县'
                  when 762576 then
                   '江津区'
                  when 762577 then
                   '南川区'
                  when 762578 then
                   '永川区'
                  when 762579 then
                   '合川区'
                  when 762580 then
                   '芳村区'
                  when 762581 then
                   '黄埔区'
                  when 762582 then
                   '花都区'
                  when 762583 then
                   '从化市'
                  when 762584 then
                   '罗湖区'
                  when 762585 then
                   '福田区'
                  when 762586 then
                   '南山区'
                  when 762587 then
                   '宝安区'
                  when 762588 then
                   '龙岗区'
                  when 762589 then
                   '秦淮区'
                  when 762590 then
                   '下关区'
                  when 762591 then
                   '浦口区'
                  when 762592 then
                   '栖霞区'
                  when 762593 then
                   '雨花台区'
                  when 762594 then
                   '江宁区'
                  when 762595 then
                   '六合区'
                  when 762596 then
                   '溧水县'
                  when 762597 then
                   '高淳县'
                  when 762598 then
                   '汉沽区'
                  when 762599 then
                   '西青区'
                  when 762600 then
                   '北辰区'
                  when 762601 then
                   '武清区'
                  when 762602 then
                   '宝坻区'
                  when 762603 then
                   '宁河县'
                  when 762604 then
                   '南汇区'
                  when 762605 then
                   '奉贤区'
                  when 762606 then
                   '崇明县'
                  when 762607 then
                   '桥东区'
                  when 762608 then
                   '桥西区'
                  when 762609 then
                   '井陉矿区'
                  when 762610 then
                   '裕华区'
                  when 762611 then
                   '井陉县'
                  when 762612 then
                   '正定县'
                  when 762613 then
                   '栾城县'
                  when 762614 then
                   '行唐县'
                  when 762615 then
                   '灵寿县'
                  when 762616 then
                   '高邑县'
                  when 762617 then
                   '深泽县'
                  when 762618 then
                   '赞皇县'
                  when 762619 then
                   '无极县'
                  when 762620 then
                   '平山县'
                  when 762621 then
                   '元氏县'
                  when 762622 then
                   '赵县'
                  when 762623 then
                   '辛集市'
                  when 762624 then
                   '藁城市'
                  when 762625 then
                   '晋州市'
                  when 762626 then
                   '新乐市'
                  when 762627 then
                   '鹿泉市'
                  when 762628 then
                   '路南区'
                  when 762629 then
                   '路北区'
                  when 762630 then
                   '古冶区'
                  when 762631 then
                   '开平区'
                  when 762632 then
                   '丰南区'
                  when 762633 then
                   '丰润区'
                  when 762634 then
                   '滦县'
                  when 762635 then
                   '滦南县'
                  when 763085 then
                   '舒兰市'
                  when 763086 then
                   '磐石市'
                  when 763087 then
                   '梨树县'
                  when 763088 then
                   '伊通满族自治县'
                  when 763089 then
                   '公主岭市'
                  when 763090 then
                   '双辽市'
                  when 762642 then
                   '海港区'
                  when 762643 then
                   '山海关区'
                  when 762644 then
                   '北戴河区'
                  when 762645 then
                   '青龙满族自治县'
                  when 762646 then
                   '昌黎县'
                  when 762647 then
                   '抚宁县'
                  when 762648 then
                   '卢龙县'
                  when 762649 then
                   '邯山区'
                  when 762650 then
                   '丛台区'
                  when 762651 then
                   '复兴区'
                  when 762652 then
                   '峰峰矿区'
                  when 762653 then
                   '邯郸县'
                  when 762654 then
                   '临漳县'
                  when 762655 then
                   '成安县'
                  when 762656 then
                   '大名县'
                  when 762657 then
                   '涉县'
                  when 762658 then
                   '磁县'
                  when 762659 then
                   '肥乡县'
                  when 762660 then
                   '永年县'
                  when 762661 then
                   '邱县'
                  when 762662 then
                   '鸡泽县'
                  when 762663 then
                   '广平县'
                  when 762664 then
                   '馆陶县'
                  when 762665 then
                   '魏县'
                  when 762666 then
                   '曲周县'
                  when 762667 then
                   '武安市'
                  when 762668 then
                   '邢台县'
                  when 762669 then
                   '临城县'
                  when 762670 then
                   '内丘县'
                  when 762671 then
                   '柏乡县'
                  when 762672 then
                   '隆尧县'
                  when 762673 then
                   '任县'
                  when 762674 then
                   '南和县'
                  when 762675 then
                   '宁晋县'
                  when 762676 then
                   '巨鹿县'
                  when 762677 then
                   '新河县'
                  when 762678 then
                   '广宗县'
                  when 762679 then
                   '平乡县'
                  when 762680 then
                   '威县'
                  when 762681 then
                   '清河县'
                  when 762682 then
                   '临西县'
                  when 762683 then
                   '南宫市'
                  when 762684 then
                   '沙河市'
                  when 762685 then
                   '北市区'
                  when 762686 then
                   '南市区'
                  when 762687 then
                   '满城县'
                  when 762688 then
                   '清苑县'
                  when 762689 then
                   '涞水县'
                  when 762690 then
                   '阜平县'
                  when 762691 then
                   '徐水县'
                  when 762692 then
                   '定兴县'
                  when 762693 then
                   '高阳县'
                  when 762694 then
                   '容城县'
                  when 762695 then
                   '涞源县'
                  when 762696 then
                   '望都县'
                  when 762697 then
                   '安新县'
                  when 762698 then
                   '曲阳县'
                  when 762699 then
                   '蠡县'
                  when 762700 then
                   '顺平县'
                  when 762701 then
                   '博野县'
                  when 762702 then
                   '涿州市'
                  when 762703 then
                   '定州市'
                  when 762704 then
                   '安国市'
                  when 762705 then
                   '高碑店市'
                  when 762706 then
                   '宣化区'
                  when 762707 then
                   '下花园区'
                  when 762708 then
                   '宣化县'
                  when 762709 then
                   '张北县'
                  when 762710 then
                   '康保县'
                  when 762711 then
                   '沽源县'
                  when 762712 then
                   '尚义县'
                  when 762713 then
                   '蔚县'
                  when 762714 then
                   '阳原县'
                  when 762715 then
                   '怀安县'
                  when 762716 then
                   '万全县'
                  when 762717 then
                   '怀来县'
                  when 762718 then
                   '涿鹿县'
                  when 762719 then
                   '赤城县'
                  when 762720 then
                   '崇礼县'
                  when 762721 then
                   '双滦区'
                  when 762722 then
                   '鹰手营子矿区'
                  when 762723 then
                   '承德县'
                  when 762724 then
                   '兴隆县'
                  when 762725 then
                   '平泉县'
                  when 762726 then
                   '滦平县'
                  when 762727 then
                   '隆化县'
                  when 762728 then
                   '丰宁满族自治县'
                  when 762729 then
                   '宽城满族自治县'
                  when 762730 then
                   '围场满族蒙古族自治县'
                  when 762731 then
                   '运河区'
                  when 762732 then
                   '沧县'
                  when 762733 then
                   '东光县'
                  when 762734 then
                   '海兴县'
                  when 762735 then
                   '盐山县'
                  when 762736 then
                   '肃宁县'
                  when 762737 then
                   '南皮县'
                  when 762738 then
                   '吴桥县'
                  when 762739 then
                   '献县'
                  when 762740 then
                   '孟村回族自治县'
                  when 762741 then
                   '泊头市'
                  when 762742 then
                   '任丘市'
                  when 762743 then
                   '黄骅市'
                  when 762744 then
                   '河间市'
                  when 762745 then
                   '安次区'
                  when 762746 then
                   '广阳区'
                  when 762747 then
                   '固安县'
                  when 762748 then
                   '永清县'
                  when 762749 then
                   '香河县'
                  when 762750 then
                   '大城县'
                  when 762751 then
                   '文安县'
                  when 762752 then
                   '大厂回族自治县'
                  when 762753 then
                   '霸州市'
                  when 762754 then
                   '三河市'
                  when 762755 then
                   '桃城区'
                  when 762756 then
                   '枣强县'
                  when 762757 then
                   '武邑县'
                  when 762758 then
                   '武强县'
                  when 762759 then
                   '饶阳县'
                  when 762760 then
                   '安平县'
                  when 762761 then
                   '故城县'
                  when 762762 then
                   '景县'
                  when 762763 then
                   '阜城县'
                  when 762764 then
                   '冀州市'
                  when 762765 then
                   '深州市'
                  when 762766 then
                   '小店区'
                  when 762767 then
                   '迎泽区'
                  when 762768 then
                   '杏花岭区'
                  when 762769 then
                   '尖草坪区'
                  when 762770 then
                   '万柏林区'
                  when 762771 then
                   '晋源区'
                  when 762772 then
                   '清徐县'
                  when 762773 then
                   '阳曲县'
                  when 762774 then
                   '娄烦县'
                  when 762775 then
                   '古交市'
                  when 762776 then
                   '南郊区'
                  when 762777 then
                   '新荣区'
                  when 762778 then
                   '阳高县'
                  when 762779 then
                   '天镇县'
                  when 762780 then
                   '广灵县'
                  when 762781 then
                   '灵丘县'
                  when 762782 then
                   '浑源县'
                  when 762783 then
                   '左云县'
                  when 762784 then
                   '大同县'
                  when 762785 then
                   '平定县'
                  when 762786 then
                   '盂县'
                  when 762787 then
                   '长治县'
                  when 762788 then
                   '襄垣县'
                  when 762789 then
                   '屯留县'
                  when 762790 then
                   '平顺县'
                  when 762791 then
                   '黎城县'
                  when 762792 then
                   '壶关县'
                  when 762793 then
                   '长子县'
                  when 762794 then
                   '武乡县'
                  when 762795 then
                   '沁源县'
                  when 762796 then
                   '潞城市'
                  when 762797 then
                   '沁水县'
                  when 762798 then
                   '阳城县'
                  when 762799 then
                   '陵川县'
                  when 762800 then
                   '泽州县'
                  when 762801 then
                   '高平市'
                  when 762802 then
                   '朔城区'
                  when 762803 then
                   '平鲁区'
                  when 762804 then
                   '山阴县'
                  when 762805 then
                   '应县'
                  when 762806 then
                   '右玉县'
                  when 762807 then
                   '怀仁县'
                  when 762808 then
                   '榆次区'
                  when 762809 then
                   '榆社县'
                  when 762810 then
                   '左权县'
                  when 762811 then
                   '和顺县'
                  when 762812 then
                   '昔阳县'
                  when 762813 then
                   '寿阳县'
                  when 762814 then
                   '太谷县'
                  when 762815 then
                   '祁县'
                  when 762816 then
                   '平遥县'
                  when 762817 then
                   '灵石县'
                  when 762818 then
                   '介休市'
                  when 762819 then
                   '盐湖区'
                  when 762820 then
                   '临猗县'
                  when 762821 then
                   '万荣县'
                  when 762822 then
                   '闻喜县'
                  when 762823 then
                   '稷山县'
                  when 762824 then
                   '新绛县'
                  when 762825 then
                   '垣曲县'
                  when 762826 then
                   '平陆县'
                  when 762827 then
                   '芮城县'
                  when 762828 then
                   '永济市'
                  when 762829 then
                   '河津市'
                  when 762830 then
                   '忻府区'
                  when 762831 then
                   '定襄县'
                  when 762832 then
                   '五台县'
                  when 762833 then
                   '代县'
                  when 762834 then
                   '繁峙县'
                  when 762835 then
                   '宁武县'
                  when 762836 then
                   '静乐县'
                  when 762837 then
                   '神池县'
                  when 762838 then
                   '五寨县'
                  when 762839 then
                   '岢岚县'
                  when 762840 then
                   '河曲县'
                  when 762841 then
                   '保德县'
                  when 762842 then
                   '偏关县'
                  when 762843 then
                   '原平市'
                  when 762844 then
                   '尧都区'
                  when 762845 then
                   '曲沃县'
                  when 762846 then
                   '翼城县'
                  when 762847 then
                   '襄汾县'
                  when 762848 then
                   '洪洞县'
                  when 762849 then
                   '古县'
                  when 762850 then
                   '安泽县'
                  when 762851 then
                   '浮山县'
                  when 762852 then
                   '乡宁县'
                  when 762853 then
                   '大宁县'
                  when 762854 then
                   '隰县'
                  when 762855 then
                   '永和县'
                  when 762856 then
                   '汾西县'
                  when 762857 then
                   '侯马市'
                  when 762858 then
                   '霍州市'
                  when 762859 then
                   '离石区'
                  when 762860 then
                   '文水县'
                  when 762861 then
                   '交城县'
                  when 762862 then
                   '临县'
                  when 762863 then
                   '柳林县'
                  when 762864 then
                   '石楼县'
                  when 762865 then
                   '方山县'
                  when 762866 then
                   '中阳县'
                  when 762867 then
                   '交口县'
                  when 762868 then
                   '孝义市'
                  when 762869 then
                   '汾阳市'
                  when 762870 then
                   '回民区'
                  when 762871 then
                   '玉泉区'
                  when 762872 then
                   '赛罕区'
                  when 762873 then
                   '土默特左旗'
                  when 762874 then
                   '托克托县'
                  when 762875 then
                   '和林格尔县'
                  when 762876 then
                   '清水河县'
                  when 762877 then
                   '武川县'
                  when 762878 then
                   '东河区'
                  when 762879 then
                   '昆都仑区'
                  when 762880 then
                   '石拐区'
                  when 762881 then
                   '白云矿区'
                  when 762882 then
                   '九原区'
                  when 762883 then
                   '土默特右旗'
                  when 762884 then
                   '固阳县'
                  when 762885 then
                   '达尔罕茂明安联合旗'
                  when 762886 then
                   '海勃湾区'
                  when 762887 then
                   '海南区'
                  when 762888 then
                   '乌达区'
                  when 762889 then
                   '红山区'
                  when 762890 then
                   '元宝山区'
                  when 762891 then
                   '松山区'
                  when 762892 then
                   '阿鲁科尔沁旗'
                  when 762893 then
                   '巴林左旗'
                  when 762894 then
                   '巴林右旗'
                  when 762895 then
                   '林西县'
                  when 762896 then
                   '克什克腾旗'
                  when 762897 then
                   '翁牛特旗'
                  when 762898 then
                   '喀喇沁旗'
                  when 762899 then
                   '宁城县'
                  when 762900 then
                   '敖汉旗'
                  when 762901 then
                   '科尔沁区'
                  when 762902 then
                   '科尔沁左翼中旗'
                  when 762903 then
                   '科尔沁左翼后旗'
                  when 762904 then
                   '开鲁县'
                  when 762905 then
                   '库伦旗'
                  when 762906 then
                   '奈曼旗'
                  when 762907 then
                   '扎鲁特旗'
                  when 762908 then
                   '霍林郭勒市'
                  when 762909 then
                   '东胜区'
                  when 762910 then
                   '达拉特旗'
                  when 762911 then
                   '准格尔旗'
                  when 762912 then
                   '鄂托克前旗'
                  when 762913 then
                   '鄂托克旗'
                  when 762914 then
                   '杭锦旗'
                  when 762915 then
                   '乌审旗'
                  when 762916 then
                   '伊金霍洛旗'
                  when 762917 then
                   '海拉尔区'
                  when 762918 then
                   '阿荣旗'
                  when 762919 then
                   '莫力达瓦达斡尔族自治旗'
                  when 762920 then
                   '鄂伦春自治旗'
                  when 762921 then
                   '鄂温克族自治旗'
                  when 762922 then
                   '陈巴尔虎旗'
                  when 762923 then
                   '新巴尔虎左旗'
                  when 762924 then
                   '新巴尔虎右旗'
                  when 762925 then
                   '满洲里市'
                  when 762926 then
                   '牙克石市'
                  when 762927 then
                   '扎兰屯市'
                  when 762928 then
                   '额尔古纳市'
                  when 762929 then
                   '根河市'
                  when 762930 then
                   '临河区'
                  when 762931 then
                   '五原县'
                  when 762932 then
                   '磴口县'
                  when 762933 then
                   '乌拉特前旗'
                  when 762934 then
                   '乌拉特中旗'
                  when 762935 then
                   '乌拉特后旗'
                  when 762936 then
                   '杭锦后旗'
                  when 761739 then
                   '安居区'
                  when 761740 then
                   '蓬溪县'
                  when 761741 then
                   '射洪县'
                  when 761742 then
                   '大英县'
                  when 761743 then
                   '东兴区'
                  when 761744 then
                   '威远县'
                  when 3233002 then
                   '向阳区'
                  when 3233003 then
                   '郊区'
                  when 3233004 then
                   '西安区'
                  when 3233005 then
                   '加格达奇区'
                  when 3233006 then
                   '新区'
                  when 3233007 then
                   '鼓楼区'
                  when 3233008 then
                   '海州区'
                  when 3233009 then
                   '清河区'
                  when 3233010 then
                   '南湖区'
                  when 3233011 then
                   '弋江区'
                  when 3233012 then
                   '三山区'
                  when 3233013 then
                   '无为县'
                  when 3233014 then
                   '含山县'
                  when 3233015 then
                   '和县'
                  when 3233016 then
                   '郊区'
                  when 3233017 then
                   '宜秀区'
                  when 3233018 then
                   '开发区'
                  when 3233019 then
                   '市中区'
                  when 3233020 then
                   '西城区'
                  when 3233021 then
                   '东城区'
                  when 3233022 then
                   '市中区'
                  when 3233023 then
                   '河东区'
                  when 3233024 then
                   '鼓楼区'
                  when 3233025 then
                   '禹王台区'
                  when 3233026 then
                   '金明区'
                  when 3233027 then
                   '城区'
                  when 3233028 then
                   '零陵区'
                  when 3233029 then
                   '金唐区'
                  when 3233030 then
                   '拱北区'
                  when 3233031 then
                   '利州区'
                  when 3233032 then
                   '市中区'
                  when 3233033 then
                   '市中区'
                  when 3233034 then
                   '白云区'
                  when 3233035 then
                   '城关区'
                  when 3233036 then
                   '秦州区'
                  when 3233037 then
                   '城中区'
                  when 3233038 then
                   '东山区'
                  when 3233039 then
                   '米东区'
                  when 3859150 then
                   '滨湖新区'
                  when 3859151 then
                   '经济技术开发区'
                  when 3938400 then
                   '石龙镇'
                  when 3938401 then
                   '石碣镇'
                  when 3938402 then
                   '茶山镇'
                  when 3938403 then
                   '石排镇'
                  when 3938404 then
                   '企石镇'
                  when 3938405 then
                   '横沥镇'
                  when 3938406 then
                   '桥头镇'
                  when 3938407 then
                   '谢岗镇'
                  when 3938408 then
                   '东坑镇'
                  when 3938409 then
                   '常平镇'
                  when 3938410 then
                   '寮步镇'
                  when 3938411 then
                   '大朗镇'
                  when 3938412 then
                   '黄江镇'
                  when 3938413 then
                   '清溪镇'
                  when 3938414 then
                   '塘厦镇'
                  when 3938415 then
                   '凤岗镇'
                  when 3938416 then
                   '长安镇'
                  when 3938417 then
                   '虎门镇'
                  when 3938418 then
                   '厚街镇'
                  when 3938419 then
                   '沙田镇'
                  when 3938420 then
                   '道滘镇'
                  when 3938421 then
                   '洪梅镇'
                  when 3938422 then
                   '麻涌镇'
                  when 3938423 then
                   '中堂镇'
                  when 3938424 then
                   '高埗镇'
                  when 3938425 then
                   '樟木头镇'
                  when 3938426 then
                   '大岭山镇'
                  when 3938427 then
                   '望牛墩镇'
                  when 3938428 then
                   '南城区'
                  when 3938429 then
                   '东城区'
                  when 3938430 then
                   '万江区'
                  when 4447450 then
                   '经济技术开发区'
                  when 4487100 then
                   '高新区'
                  when 5379050 then
                   '高新区'
                  when 11018050 then
                   '嘉峪关市'
                  when 45632433 then
                   '图木舒克市'
                  when 45632305 then
                   '石河子市'
                  when 45632432 then
                   '阿拉尔市'
                  when 6706100 then
                   '经济开发区'
                  when 6957100 then
                   '金阳新区'
                  when 45632434 then
                   '五家渠市'
                  when 45632435 then
                   '北屯市'
                  when 45632436 then
                   '铁门关市'
                  when 45984056 then
                   '滨海新区'
                  when 46325108 then
                   '曲江新区'
                  when 3344853 then
                   '红谷滩新区'
                  when 3344854 then
                   '高新区'
                  when 46325109 then
                   '高新区'
                  when 763091 then
                   '龙山区'
                  when 763092 then
                   '西安区'
                  when 763093 then
                   '东丰县'
                  when 763094 then
                   '东辽县'
                  when 763095 then
                   '东昌区'
                  when 763096 then
                   '二道江区'
                  when 763097 then
                   '通化县'
                  when 763098 then
                   '辉南县'
                  when 763099 then
                   '柳河县'
                  when 763100 then
                   '梅河口市'
                  when 763101 then
                   '集安市'
                  when 763102 then
                   '八道江区'
                  when 763103 then
                   '抚松县'
                  when 763104 then
                   '靖宇县'
                  when 763105 then
                   '长白朝鲜族自治县'
                  when 763106 then
                   '江源县'
                  when 763107 then
                   '临江市'
                  when 763108 then
                   '宁江区'
                  when 763109 then
                   '前郭尔罗斯蒙古族自治县'
                  when 763110 then
                   '长岭县'
                  when 763111 then
                   '乾安县'
                  when 763112 then
                   '扶余县'
                  when 763113 then
                   '洮北区'
                  when 763114 then
                   '镇赉县'
                  when 763115 then
                   '通榆县'
                  when 763116 then
                   '洮南市'
                  when 763117 then
                   '大安市'
                  when 763118 then
                   '龙沙区'
                  when 763119 then
                   '建华区'
                  when 763120 then
                   '铁锋区'
                  when 763121 then
                   '昂昂溪区'
                  when 763122 then
                   '富拉尔基区'
                  when 763123 then
                   '碾子山区'
                  when 763124 then
                   '梅里斯达斡尔族区'
                  when 763125 then
                   '龙江县'
                  when 763126 then
                   '依安县'
                  when 763127 then
                   '泰来县'
                  when 763128 then
                   '甘南县'
                  when 763129 then
                   '富裕县'
                  when 763130 then
                   '克山县'
                  when 763131 then
                   '克东县'
                  when 763132 then
                   '拜泉县'
                  when 763133 then
                   '讷河市'
                  when 763134 then
                   '鸡冠区'
                  when 763135 then
                   '恒山区'
                  when 763136 then
                   '滴道区'
                  when 763137 then
                   '梨树区'
                  when 763138 then
                   '城子河区'
                  when 763139 then
                   '麻山区'
                  when 763140 then
                   '鸡东县'
                  when 763141 then
                   '虎林市'
                  when 763142 then
                   '密山市'
                  when 763143 then
                   '向阳区'
                  when 763144 then
                   '工农区'
                  when 763145 then
                   '兴安区'
                  when 763146 then
                   '兴山区'
                  when 763147 then
                   '萝北县'
                  when 763148 then
                   '绥滨县'
                  when 763149 then
                   '尖山区'
                  when 763150 then
                   '岭东区'
                  when 763151 then
                   '四方台区'
                  when 763152 then
                   '集贤县'
                  when 763153 then
                   '友谊县'
                  when 763154 then
                   '宝清县'
                  when 763155 then
                   '饶河县'
                  when 763156 then
                   '萨尔图区'
                  when 763157 then
                   '龙凤区'
                  when 763158 then
                   '让胡路区'
                  when 763159 then
                   '红岗区'
                  when 763160 then
                   '大同区'
                  when 763161 then
                   '肇州县'
                  when 763162 then
                   '肇源县'
                  when 763163 then
                   '林甸县'
                  when 763164 then
                   '杜尔伯特蒙古族自治县'
                  when 763165 then
                   '伊春区'
                  when 763166 then
                   '南岔区'
                  when 763167 then
                   '友好区'
                  when 763168 then
                   '西林区'
                  when 763169 then
                   '翠峦区'
                  when 763170 then
                   '新青区'
                  when 763171 then
                   '美溪区'
                  when 763172 then
                   '金山屯区'
                  when 763173 then
                   '五营区'
                  when 763174 then
                   '乌马河区'
                  when 763175 then
                   '汤旺河区'
                  when 763176 then
                   '带岭区'
                  when 763177 then
                   '乌伊岭区'
                  when 763178 then
                   '红星区'
                  when 763179 then
                   '上甘岭区'
                  when 763180 then
                   '嘉荫县'
                  when 763181 then
                   '铁力市'
                  when 763182 then
                   '永红区'
                  when 763183 then
                   '前进区'
                  when 763184 then
                   '东风区'
                  when 763185 then
                   '桦南县'
                  when 763186 then
                   '桦川县'
                  when 763187 then
                   '汤原县'
                  when 763188 then
                   '抚远县'
                  when 763189 then
                   '同江市'
                  when 763190 then
                   '富锦市'
                  when 763191 then
                   '新兴区'
                  when 763192 then
                   '桃山区'
                  when 763193 then
                   '茄子河区'
                  when 763194 then
                   '勃利县'
                  when 763195 then
                   '东安区'
                  when 763196 then
                   '阳明区'
                  when 763197 then
                   '爱民区'
                  when 763198 then
                   '东宁县'
                  when 763199 then
                   '林口县'
                  when 763200 then
                   '绥芬河市'
                  when 763201 then
                   '海林市'
                  when 763202 then
                   '宁安市'
                  when 763203 then
                   '穆棱市'
                  when 763204 then
                   '爱辉区'
                  when 763205 then
                   '嫩江县'
                  when 763206 then
                   '逊克县'
                  when 763207 then
                   '孙吴县'
                  when 763208 then
                   '北安市'
                  when 763209 then
                   '五大连池市'
                  when 763210 then
                   '北林区'
                  when 763211 then
                   '望奎县'
                  when 763212 then
                   '兰西县'
                  when 763213 then
                   '青冈县'
                  when 763214 then
                   '庆安县'
                  when 763215 then
                   '明水县'
                  when 763216 then
                   '绥棱县'
                  when 763217 then
                   '安达市'
                  when 763218 then
                   '肇东市'
                  when 763219 then
                   '海伦市'
                  when 763220 then
                   '呼玛县'
                  when 763221 then
                   '塔河县'
                  when 763222 then
                   '漠河县'
                  when 763223 then
                   '崇安区'
                  when 763224 then
                   '南长区'
                  when 763225 then
                   '北塘区'
                  when 763226 then
                   '锡山区'
                  when 763227 then
                   '惠山区'
                  when 763228 then
                   '滨湖区'
                  when 763229 then
                   '江阴市'
                  when 763230 then
                   '宜兴市'
                  when 763231 then
                   '云龙区'
                  when 763232 then
                   '九里区'
                  when 763233 then
                   '贾汪区'
                  when 763234 then
                   '泉山区'
                  when 763235 then
                   '沛县'
                  when 763236 then
                   '铜山县'
                  when 763391 then
                   '青田县'
                  when 763392 then
                   '缙云县'
                  when 763393 then
                   '遂昌县'
                  when 763394 then
                   '松阳县'
                  when 763395 then
                   '云和县'
                  when 763396 then
                   '庆元县'
                  when 763397 then
                   '景宁畲族自治县'
                  when 763398 then
                   '龙泉市'
                  when 763399 then
                   '瑶海区'
                  when 763400 then
                   '庐阳区'
                  when 763401 then
                   '蜀山区'
                  when 763402 then
                   '包河区'
                  when 763403 then
                   '长丰县'
                  when 763404 then
                   '肥东县'
                  when 763405 then
                   '肥西县'
                  when 763406 then
                   '镜湖区'
                  when 763407 then
                   '马塘区'
                  when 763408 then
                   '新芜区'
                  when 763409 then
                   '鸠江区'
                  when 763410 then
                   '芜湖县'
                  when 763411 then
                   '繁昌县'
                  when 763412 then
                   '南陵县'
                  when 763413 then
                   '龙子湖区'
                  when 763414 then
                   '蚌山区'
                  when 763415 then
                   '禹会区'
                  when 763416 then
                   '淮上区'
                  when 763417 then
                   '怀远县'
                  when 763418 then
                   '五河县'
                  when 763419 then
                   '固镇县'
                  when 763420 then
                   '大通区'
                  when 763421 then
                   '田家庵区'
                  when 763422 then
                   '谢家集区'
                  when 763423 then
                   '八公山区'
                  when 763424 then
                   '潘集区'
                  when 763425 then
                   '凤台县'
                  when 763426 then
                   '杜集区'
                  when 763427 then
                   '相山区'
                  when 763428 then
                   '烈山区'
                  when 763429 then
                   '濉溪县'
                  when 763430 then
                   '铜官山区'
                  when 763431 then
                   '狮子山区'
                  when 763432 then
                   '铜陵县'
                  when 763433 then
                   '迎江区'
                  when 763434 then
                   '大观区'
                  when 763435 then
                   '怀宁县'
                  when 763436 then
                   '枞阳县'
                  when 763437 then
                   '潜山县'
                  when 763438 then
                   '太湖县'
                  when 763439 then
                   '宿松县'
                  when 763440 then
                   '望江县'
                  when 763441 then
                   '岳西县'
                  when 763442 then
                   '桐城市'
                  when 763443 then
                   '屯溪区'
                  when 763444 then
                   '黄山区'
                  when 763445 then
                   '徽州区'
                  when 763446 then
                   '歙县'
                  when 763447 then
                   '休宁县'
                  when 763448 then
                   '黟县'
                  when 763449 then
                   '祁门县'
                  when 763450 then
                   '琅琊区'
                  when 763451 then
                   '南谯区'
                  when 763452 then
                   '来安县'
                  when 763453 then
                   '全椒县'
                  when 763454 then
                   '定远县'
                  when 763455 then
                   '凤阳县'
                  when 763456 then
                   '天长市'
                  when 763457 then
                   '明光市'
                  when 763458 then
                   '颍州区'
                  when 763459 then
                   '颍东区'
                  when 763460 then
                   '颍泉区'
                  when 763461 then
                   '临泉县'
                  when 763462 then
                   '太和县'
                  when 763463 then
                   '阜南县'
                  when 763464 then
                   '颍上县'
                  when 763465 then
                   '界首市'
                  when 763466 then
                   '埇桥区'
                  when 763467 then
                   '砀山县'
                  when 763468 then
                   '萧县'
                  when 763469 then
                   '灵璧县'
                  when 763470 then
                   '居巢区'
                  when 763471 then
                   '庐江县'
                  when 763472 then
                   '无为县'
                  when 763473 then
                   '含山县'
                  when 763474 then
                   '金安区'
                  when 763475 then
                   '裕安区'
                  when 763476 then
                   '霍邱县'
                  when 763477 then
                   '舒城县'
                  when 763478 then
                   '金寨县'
                  when 763479 then
                   '霍山县'
                  when 763480 then
                   '谯城区'
                  when 763481 then
                   '涡阳县'
                  when 763482 then
                   '蒙城县'
                  when 763483 then
                   '利辛县'
                  when 763484 then
                   '贵池区'
                  when 763485 then
                   '东至县'
                  when 763486 then
                   '石台县'
                  when 763487 then
                   '青阳县'
                  when 763488 then
                   '宣州区'
                  when 763489 then
                   '郎溪县'
                  when 763490 then
                   '广德县'
                  when 763491 then
                   '泾县'
                  when 763492 then
                   '绩溪县'
                  when 763493 then
                   '旌德县'
                  when 763494 then
                   '宁国市'
                  when 763495 then
                   '台江区'
                  when 763496 then
                   '仓山区'
                  when 763497 then
                   '马尾区'
                  when 763498 then
                   '晋安区'
                  when 763499 then
                   '闽侯县'
                  when 763500 then
                   '连江县'
                  when 763501 then
                   '罗源县'
                  when 763502 then
                   '闽清县'
                  when 763503 then
                   '永泰县'
                  when 763504 then
                   '平潭县'
                  when 763505 then
                   '福清市'
                  when 763506 then
                   '长乐市'
                  when 763507 then
                   '思明区'
                  when 763508 then
                   '海沧区'
                  when 763509 then
                   '湖里区'
                  when 763510 then
                   '集美区'
                  when 763511 then
                   '同安区'
                  when 763512 then
                   '翔安区'
                  when 763513 then
                   '城厢区'
                  when 763514 then
                   '涵江区'
                  when 763515 then
                   '荔城区'
                  when 763516 then
                   '秀屿区'
                  when 763517 then
                   '仙游县'
                  when 763518 then
                   '梅列区'
                  when 763519 then
                   '三元区'
                  when 763520 then
                   '明溪县'
                  when 763521 then
                   '清流县'
                  when 763522 then
                   '宁化县'
                  when 763523 then
                   '大田县'
                  when 763524 then
                   '尤溪县'
                  when 763525 then
                   '将乐县'
                  when 763526 then
                   '泰宁县'
                  when 763527 then
                   '建宁县'
                  when 763528 then
                   '永安市'
                  when 763529 then
                   '鲤城区'
                  when 763530 then
                   '丰泽区'
                  when 763531 then
                   '洛江区'
                  when 763532 then
                   '泉港区'
                  when 763533 then
                   '惠安县'
                  when 763534 then
                   '安溪县'
                  when 763535 then
                   '永春县'
                  when 763536 then
                   '德化县'
                  when 763537 then
                   '金门县'
                  when 763538 then
                   '石狮市'
                  when 763539 then
                   '晋江市'
                  when 763540 then
                   '南安市'
                  when 763541 then
                   '芗城区'
                  when 763542 then
                   '龙文区'
                  when 763543 then
                   '云霄县'
                  when 763544 then
                   '漳浦县'
                  when 763545 then
                   '诏安县'
                  when 763546 then
                   '长泰县'
                  when 763547 then
                   '东山县'
                  when 763548 then
                   '南靖县'
                  when 763549 then
                   '平和县'
                  when 763550 then
                   '华安县'
                  when 763551 then
                   '龙海市'
                  when 763552 then
                   '延平区'
                  when 763553 then
                   '顺昌县'
                  when 763554 then
                   '浦城县'
                  when 763555 then
                   '光泽县'
                  when 763556 then
                   '松溪县'
                  when 763557 then
                   '政和县'
                  when 763558 then
                   '邵武市'
                  when 763559 then
                   '武夷山市'
                  when 763560 then
                   '建瓯市'
                  when 763561 then
                   '建阳市'
                  when 763562 then
                   '新罗区'
                  when 763563 then
                   '长汀县'
                  when 763564 then
                   '永定县'
                  when 763565 then
                   '上杭县'
                  when 763566 then
                   '武平县'
                  when 763567 then
                   '连城县'
                  when 763568 then
                   '漳平市'
                  when 763569 then
                   '蕉城区'
                  when 763570 then
                   '霞浦县'
                  when 763571 then
                   '古田县'
                  when 763572 then
                   '屏南县'
                  when 763573 then
                   '寿宁县'
                  when 763574 then
                   '周宁县'
                  when 763575 then
                   '柘荣县'
                  when 763576 then
                   '福安市'
                  when 763577 then
                   '福鼎市'
                  when 763578 then
                   '东湖区'
                  when 763579 then
                   '青云谱区'
                  when 763580 then
                   '湾里区'
                  when 763581 then
                   '青山湖区'
                  when 763582 then
                   '南昌县'
                  when 763583 then
                   '新建县'
                  when 763584 then
                   '安义县'
                  when 763585 then
                   '进贤县'
                  when 763586 then
                   '昌江区'
                  when 763587 then
                   '珠山区'
                  when 763588 then
                   '浮梁县'
                  when 763589 then
                   '乐平市'
                  when 763590 then
                   '安源区'
                  when 763591 then
                   '湘东区'
                  when 763592 then
                   '莲花县'
                  when 763593 then
                   '上栗县'
                  when 763594 then
                   '芦溪县'
                  when 763595 then
                   '庐山区'
                  when 763596 then
                   '浔阳区'
                  when 763597 then
                   '九江县'
                  when 763598 then
                   '武宁县'
                  when 763599 then
                   '修水县'
                  when 763600 then
                   '永修县'
                  when 763601 then
                   '德安县'
                  when 763602 then
                   '星子县'
                  when 763603 then
                   '都昌县'
                  when 763604 then
                   '湖口县'
                  when 763605 then
                   '彭泽县'
                  when 763606 then
                   '瑞昌市'
                  when 763607 then
                   '渝水区'
                  when 763608 then
                   '分宜县'
                  when 763609 then
                   '月湖区'
                  when 763610 then
                   '余江县'
                  when 763611 then
                   '贵溪市'
                  when 763612 then
                   '章贡区'
                  when 763613 then
                   '赣县'
                  when 763614 then
                   '信丰县'
                  when 763615 then
                   '大余县'
                  when 763616 then
                   '上犹县'
                  when 763617 then
                   '崇义县'
                  when 763618 then
                   '安远县'
                  when 763619 then
                   '龙南县'
                  when 763620 then
                   '定南县'
                  when 763621 then
                   '全南县'
                  when 763622 then
                   '宁都县'
                  when 763623 then
                   '于都县'
                  when 763624 then
                   '兴国县'
                  when 763625 then
                   '会昌县'
                  when 763626 then
                   '寻乌县'
                  when 763627 then
                   '石城县'
                  when 763628 then
                   '瑞金市'
                  when 763629 then
                   '南康市'
                  when 763630 then
                   '吉州区'
                  when 763631 then
                   '青原区'
                  when 763632 then
                   '吉安县'
                  when 763633 then
                   '吉水县'
                  when 763634 then
                   '峡江县'
                  when 763635 then
                   '新干县'
                  when 763636 then
                   '永丰县'
                  when 763637 then
                   '泰和县'
                  when 763638 then
                   '遂川县'
                  when 763639 then
                   '万安县'
                  when 763640 then
                   '安福县'
                  when 763641 then
                   '永新县'
                  when 763642 then
                   '井冈山市'
                  when 763643 then
                   '袁州区'
                  when 763644 then
                   '奉新县'
                  when 763645 then
                   '万载县'
                  when 763646 then
                   '上高县'
                  when 763647 then
                   '宜丰县'
                  when 763648 then
                   '靖安县'
                  when 763649 then
                   '铜鼓县'
                  when 763650 then
                   '丰城市'
                  when 763651 then
                   '樟树市'
                  when 763652 then
                   '高安市'
                  when 763653 then
                   '临川区'
                  when 763654 then
                   '南城县'
                  when 763655 then
                   '黎川县'
                  when 763656 then
                   '南丰县'
                  when 763657 then
                   '崇仁县'
                  when 763658 then
                   '乐安县'
                  when 763659 then
                   '宜黄县'
                  when 763660 then
                   '金溪县'
                  when 763661 then
                   '资溪县'
                  when 763662 then
                   '东乡县'
                  when 763663 then
                   '广昌县'
                  when 763664 then
                   '信州区'
                  when 763665 then
                   '上饶县'
                  when 763666 then
                   '广丰县'
                  when 763667 then
                   '玉山县'
                  when 763668 then
                   '铅山县'
                  when 763669 then
                   '横峰县'
                  when 763670 then
                   '弋阳县'
                  when 763671 then
                   '余干县'
                  when 763672 then
                   '鄱阳县'
                  when 763673 then
                   '万年县'
                  when 763674 then
                   '婺源县'
                  when 763675 then
                   '德兴市'
                  when 763676 then
                   '历下区'
                  when 763677 then
                   '槐荫区'
                  when 763678 then
                   '天桥区'
                  when 763679 then
                   '历城区'
                  when 763680 then
                   '长清区'
                  when 763681 then
                   '平阴县'
                  when 763682 then
                   '济阳县'
                  when 763683 then
                   '商河县'
                  when 763684 then
                   '章丘市'
                  when 763685 then
                   '市南区'
                  when 763686 then
                   '市北区'
                  when 763687 then
                   '四方区'
                  when 763688 then
                   '黄岛区'
                  when 763689 then
                   '崂山区'
                  when 763690 then
                   '李沧区'
                  when 763691 then
                   '城阳区'
                  when 763692 then
                   '胶州市'
                  when 763693 then
                   '即墨市'
                  when 763694 then
                   '平度市'
                  when 763695 then
                   '胶南市'
                  when 763696 then
                   '莱西市'
                  when 763697 then
                   '淄川区'
                  when 763698 then
                   '张店区'
                  when 763699 then
                   '博山区'
                  when 763700 then
                   '临淄区'
                  when 763701 then
                   '周村区'
                  when 763702 then
                   '桓台县'
                  when 763703 then
                   '高青县'
                  when 763704 then
                   '沂源县'
                  when 763705 then
                   '薛城区'
                  when 763706 then
                   '峄城区'
                  when 763707 then
                   '台儿庄区'
                  when 763708 then
                   '山亭区'
                  when 763709 then
                   '滕州市'
                  when 763710 then
                   '东营区'
                  when 763711 then
                   '垦利县'
                  when 763712 then
                   '利津县'
                  when 763713 then
                   '广饶县'
                  when 763714 then
                   '芝罘区'
                  when 763715 then
                   '福山区'
                  when 763716 then
                   '牟平区'
                  when 763717 then
                   '莱山区'
                  when 763718 then
                   '长岛县'
                  when 763719 then
                   '龙口市'
                  when 763720 then
                   '莱阳市'
                  when 763721 then
                   '莱州市'
                  when 763722 then
                   '蓬莱市'
                  when 763723 then
                   '招远市'
                  when 763724 then
                   '栖霞市'
                  when 763725 then
                   '海阳市'
                  when 763726 then
                   '潍城区'
                  when 763727 then
                   '寒亭区'
                  when 763728 then
                   '坊子区'
                  when 763729 then
                   '奎文区'
                  when 763730 then
                   '临朐县'
                  when 763731 then
                   '昌乐县'
                  when 763732 then
                   '青州市'
                  when 763733 then
                   '诸城市'
                  when 763734 then
                   '寿光市'
                  when 763735 then
                   '安丘市'
                  when 763736 then
                   '高密市'
                  when 763737 then
                   '昌邑市'
                  when 763738 then
                   '任城区'
                  when 763739 then
                   '微山县'
                  when 763740 then
                   '鱼台县'
                  when 763741 then
                   '金乡县'
                  when 763742 then
                   '嘉祥县'
                  when 763743 then
                   '汶上县'
                  when 763744 then
                   '泗水县'
                  when 763745 then
                   '梁山县'
                  when 763746 then
                   '曲阜市'
                  when 763747 then
                   '兖州市'
                  when 763748 then
                   '邹城市'
                  when 763749 then
                   '泰山区'
                  when 763750 then
                   '岱岳区'
                  when 763751 then
                   '宁阳县'
                  when 763752 then
                   '东平县'
                  when 763753 then
                   '新泰市'
                  when 763754 then
                   '肥城市'
                  when 2229850 then
                   '南沙区'
                  when 2325750 then
                   '澳门'
                  when 2344850 then
                   '鼓楼区'
                  when 2344853 then
                   '昌北区'
                  when 2344854 then
                   '卢氏县'
                  when 2465501 then
                   '花山区'
                  when 2535550 then
                   '市中区'
                  when 2734250 then
                   '高新区'
                  when 763800 then
                   '南县'
                  when 763801 then
                   '梅县'
                  when 763802 then
                   '城区'
                  when 763803 then
                   '容县'
                  when 763804 then
                   '东区'
                  when 763805 then
                   '西区'
                  when 763806 then
                   '安县'
                  when 763807 then
                   '高县'
                  when 763808 then
                   '云县'
                  when 763809 then
                   '朗县'
                  when 763810 then
                   '陇县'
                  when 763811 then
                   '华县'
                  when 763812 then
                   '富县'
                  when 763813 then
                   '洋县'
                  when 763814 then
                   '宁县'
                  when 763815 then
                   '漳县'
                  when 763816 then
                   '文县'
                  when 763817 then
                   '康县'
                  when 763818 then
                   '中原区'
                  when 763819 then
                   '宾县'
                  when 763820 then
                   '开县'
                  when 763821 then
                   '唐县'
                  when 763822 then
                   '易县'
                  when 763823 then
                   '雄县'
                  when 763824 then
                   '青县'
                  when 763825 then
                   '矿区'
                  when 763826 then
                   '沁县'
                  when 763827 then
                   '绛县'
                  when 763828 then
                   '夏县'
                  when 763829 then
                   '吉县'
                  when 763830 then
                   '蒲县'
                  when 763831 then
                   '兴县'
                  when 763832 then
                   '岚县'
                  when 763833 then
                   '义县'
                  when 763834 then
                   '丰县'
                  when 763835 then
                   '西湖区'
                  when 763836 then
                   '泗县'
                  when 763837 then
                   '和县'
                  when 763838 then
                   '寿县'
                  when 763839 then
                   '沙县'
                  when 763840 then
                   '河口区'
                  when 1646950 then
                   '长兴岛'
                  when 2297400 then
                   '莞城区'
                  when 2465500 then
                   '金家庄区'
                  when 763237 then
                   '睢宁县'
                  when 763238 then
                   '新沂市'
                  when 763239 then
                   '邳州市'
                  when 763240 then
                   '天宁区'
                  when 763241 then
                   '钟楼区'
                  when 763242 then
                   '戚墅堰区'
                  when 763243 then
                   '新北区'
                  when 763244 then
                   '武进区'
                  when 763245 then
                   '溧阳市'
                  when 763246 then
                   '金坛市'
                  when 763247 then
                   '沧浪区'
                  when 763248 then
                   '平江区'
                  when 763249 then
                   '金阊区'
                  when 763250 then
                   '虎丘区'
                  when 763251 then
                   '吴中区'
                  when 763252 then
                   '相城区'
                  when 763253 then
                   '常熟市'
                  when 763254 then
                   '张家港市'
                  when 763255 then
                   '昆山市'
                  when 763256 then
                   '吴江市'
                  when 763257 then
                   '太仓市'
                  when 763258 then
                   '崇川区'
                  when 763259 then
                   '港闸区'
                  when 763260 then
                   '海安县'
                  when 763261 then
                   '如东县'
                  when 763262 then
                   '启东市'
                  when 763263 then
                   '如皋市'
                  when 763264 then
                   '通州市'
                  when 763265 then
                   '海门市'
                  when 763266 then
                   '连云区'
                  when 763267 then
                   '新浦区'
                  when 763268 then
                   '赣榆县'
                  when 763269 then
                   '东海县'
                  when 763270 then
                   '灌云县'
                  when 763271 then
                   '灌南县'
                  when 763272 then
                   '楚州区'
                  when 763273 then
                   '淮阴区'
                  when 763274 then
                   '清浦区'
                  when 763275 then
                   '涟水县'
                  when 763276 then
                   '洪泽县'
                  when 763277 then
                   '盱眙县'
                  when 763278 then
                   '金湖县'
                  when 763279 then
                   '亭湖区'
                  when 763280 then
                   '盐都区'
                  when 763281 then
                   '响水县'
                  when 763282 then
                   '滨海县'
                  when 763283 then
                   '阜宁县'
                  when 763284 then
                   '射阳县'
                  when 763285 then
                   '建湖县'
                  when 763286 then
                   '东台市'
                  when 763287 then
                   '大丰市'
                  when 763288 then
                   '广陵区'
                  when 763289 then
                   '邗江区'
                  when 763290 then
                   '维扬区'
                  when 763291 then
                   '宝应县'
                  when 763292 then
                   '仪征市'
                  when 763293 then
                   '高邮市'
                  when 763294 then
                   '江都市'
                  when 763295 then
                   '京口区'
                  when 763296 then
                   '润州区'
                  when 763297 then
                   '丹徒区'
                  when 763298 then
                   '丹阳市'
                  when 763299 then
                   '扬中市'
                  when 763300 then
                   '句容市'
                  when 763301 then
                   '海陵区'
                  when 763302 then
                   '高港区'
                  when 763303 then
                   '兴化市'
                  when 763304 then
                   '靖江市'
                  when 763305 then
                   '泰兴市'
                  when 763306 then
                   '姜堰市'
                  when 763307 then
                   '宿城区'
                  when 763308 then
                   '宿豫区'
                  when 763309 then
                   '沭阳县'
                  when 763310 then
                   '泗阳县'
                  when 763311 then
                   '泗洪县'
                  when 763312 then
                   '上城区'
                  when 763313 then
                   '下城区'
                  when 763314 then
                   '江干区'
                  when 763315 then
                   '拱墅区'
                  when 763316 then
                   '滨江区'
                  when 763317 then
                   '萧山区'
                  when 763318 then
                   '余杭区'
                  when 763319 then
                   '桐庐县'
                  when 763320 then
                   '淳安县'
                  when 763321 then
                   '建德市'
                  when 763322 then
                   '富阳市'
                  when 763323 then
                   '临安市'
                  when 763324 then
                   '海曙区'
                  when 763325 then
                   '江东区'
                  when 763326 then
                   '北仑区'
                  when 763327 then
                   '镇海区'
                  when 763328 then
                   '鄞州区'
                  when 763329 then
                   '象山县'
                  when 763330 then
                   '宁海县'
                  when 763331 then
                   '余姚市'
                  when 763332 then
                   '慈溪市'
                  when 763333 then
                   '奉化市'
                  when 763334 then
                   '鹿城区'
                  when 763335 then
                   '龙湾区'
                  when 763336 then
                   '瓯海区'
                  when 763337 then
                   '洞头县'
                  when 763338 then
                   '永嘉县'
                  when 763339 then
                   '平阳县'
                  when 763340 then
                   '苍南县'
                  when 763341 then
                   '文成县'
                  when 763342 then
                   '泰顺县'
                  when 763343 then
                   '瑞安市'
                  when 763344 then
                   '乐清市'
                  when 763345 then
                   '秀城区'
                  when 763346 then
                   '秀洲区'
                  when 763347 then
                   '嘉善县'
                  when 763348 then
                   '海盐县'
                  when 763349 then
                   '海宁市'
                  when 763350 then
                   '平湖市'
                  when 763351 then
                   '桐乡市'
                  when 763352 then
                   '吴兴区'
                  when 763353 then
                   '南浔区'
                  when 763354 then
                   '德清县'
                  when 763355 then
                   '长兴县'
                  when 763356 then
                   '安吉县'
                  when 763357 then
                   '越城区'
                  when 763358 then
                   '绍兴县'
                  when 763359 then
                   '新昌县'
                  when 763360 then
                   '诸暨市'
                  when 763361 then
                   '上虞市'
                  when 763362 then
                   '嵊州市'
                  when 763363 then
                   '婺城区'
                  when 763364 then
                   '金东区'
                  when 763365 then
                   '武义县'
                  when 763366 then
                   '浦江县'
                  when 763367 then
                   '磐安县'
                  when 763368 then
                   '兰溪市'
                  when 763369 then
                   '义乌市'
                  when 763370 then
                   '东阳市'
                  when 763371 then
                   '永康市'
                  when 763372 then
                   '柯城区'
                  when 763373 then
                   '衢江区'
                  when 763374 then
                   '常山县'
                  when 763375 then
                   '开化县'
                  when 763376 then
                   '龙游县'
                  when 763377 then
                   '江山市'
                  when 763378 then
                   '定海区'
                  when 763379 then
                   '岱山县'
                  when 763380 then
                   '嵊泗县'
                  when 763381 then
                   '椒江区'
                  when 763382 then
                   '黄岩区'
                  when 763383 then
                   '路桥区'
                  when 763384 then
                   '玉环县'
                  when 763385 then
                   '三门县'
                  when 763386 then
                   '天台县'
                  when 763387 then
                   '仙居县'
                  when 763388 then
                   '温岭市'
                  when 763389 then
                   '临海市'
                  when 763390 then
                   '莲都区'
                  when 762937 then
                   '集宁区'
                  when 762938 then
                   '卓资县'
                  when 762939 then
                   '化德县'
                  when 762940 then
                   '商都县'
                  when 762941 then
                   '兴和县'
                  when 762942 then
                   '凉城县'
                  when 762943 then
                   '察哈尔右翼前旗'
                  when 762944 then
                   '察哈尔右翼中旗'
                  when 762945 then
                   '察哈尔右翼后旗'
                  when 762946 then
                   '四子王旗'
                  when 762947 then
                   '丰镇市'
                  when 762948 then
                   '乌兰浩特市'
                  when 762949 then
                   '阿尔山市'
                  when 762950 then
                   '科尔沁右翼前旗'
                  when 762951 then
                   '科尔沁右翼中旗'
                  when 762952 then
                   '扎赉特旗'
                  when 762953 then
                   '突泉县'
                  when 762954 then
                   '二连浩特市'
                  when 762955 then
                   '锡林浩特市'
                  when 762956 then
                   '阿巴嘎旗'
                  when 762957 then
                   '苏尼特左旗'
                  when 762958 then
                   '苏尼特右旗'
                  when 762959 then
                   '东乌珠穆沁旗'
                  when 762960 then
                   '西乌珠穆沁旗'
                  when 762961 then
                   '太仆寺旗'
                  when 762962 then
                   '镶黄旗'
                  when 762963 then
                   '正镶白旗'
                  when 762964 then
                   '正蓝旗'
                  when 762965 then
                   '多伦县'
                  when 762966 then
                   '阿拉善左旗'
                  when 762967 then
                   '阿拉善右旗'
                  when 762968 then
                   '额济纳旗'
                  when 762969 then
                   '沈河区'
                  when 762970 then
                   '大东区'
                  when 762971 then
                   '皇姑区'
                  when 762972 then
                   '铁西区'
                  when 762973 then
                   '苏家屯区'
                  when 762974 then
                   '东陵区'
                  when 762975 then
                   '新城子区'
                  when 762976 then
                   '于洪区'
                  when 762977 then
                   '辽中县'
                  when 762978 then
                   '康平县'
                  when 762979 then
                   '法库县'
                  when 762980 then
                   '新民市'
                  when 762981 then
                   '中山区'
                  when 762982 then
                   '西岗区'
                  when 762983 then
                   '沙河口区'
                  when 762984 then
                   '甘井子区'
                  when 762985 then
                   '旅顺口区'
                  when 762986 then
                   '金州区'
                  when 762987 then
                   '长海县'
                  when 762988 then
                   '瓦房店市'
                  when 762989 then
                   '普兰店市'
                  when 762990 then
                   '庄河市'
                  when 762991 then
                   '铁东区'
                  when 762992 then
                   '立山区'
                  when 762993 then
                   '千山区'
                  when 762994 then
                   '台安县'
                  when 762995 then
                   '岫岩满族自治县'
                  when 762996 then
                   '海城市'
                  when 762997 then
                   '金家庄区'
                  when 762998 then
                   '花山区'
                  when 762999 then
                   '雨山区'
                  when 763000 then
                   '当涂县'
                  when 763001 then
                   '新抚区'
                  when 763002 then
                   '东洲区'
                  when 763003 then
                   '望花区'
                  when 763004 then
                   '顺城区'
                  when 763005 then
                   '抚顺县'
                  when 763006 then
                   '新宾满族自治县'
                  when 763007 then
                   '清原满族自治县'
                  when 763008 then
                   '平山区'
                  when 763009 then
                   '溪湖区'
                  when 763010 then
                   '明山区'
                  when 763011 then
                   '南芬区'
                  when 763012 then
                   '本溪满族自治县'
                  when 763013 then
                   '桓仁满族自治县'
                  when 763014 then
                   '元宝区'
                  when 763015 then
                   '振兴区'
                  when 763016 then
                   '振安区'
                  when 763017 then
                   '宽甸满族自治县'
                  when 763018 then
                   '东港市'
                  when 763019 then
                   '凤城市'
                  when 763020 then
                   '古塔区'
                  when 763021 then
                   '凌河区'
                  when 763022 then
                   '太和区'
                  when 763023 then
                   '黑山县'
                  when 763024 then
                   '凌海市'
                  when 763025 then
                   '北宁市'
                  when 763026 then
                   '站前区'
                  when 763027 then
                   '西市区'
                  when 763028 then
                   '鲅鱼圈区'
                  when 763029 then
                   '老边区'
                  when 763030 then
                   '盖州市'
                  when 763031 then
                   '大石桥市'
                  when 763032 then
                   '海州区'
                  when 763033 then
                   '新邱区'
                  when 763034 then
                   '太平区'
                  when 763035 then
                   '清河门区'
                  when 763036 then
                   '细河区'
                  when 763037 then
                   '阜新蒙古族自治县'
                  when 763038 then
                   '彰武县'
                  when 763039 then
                   '白塔区'
                  when 763040 then
                   '文圣区'
                  when 763041 then
                   '宏伟区'
                  when 763042 then
                   '弓长岭区'
                  when 763043 then
                   '太子河区'
                  when 763044 then
                   '辽阳县'
                  when 763045 then
                   '灯塔市'
                  when 763046 then
                   '双台子区'
                  when 763047 then
                   '兴隆台区'
                  when 763048 then
                   '大洼县'
                  when 763049 then
                   '盘山县'
                  when 763050 then
                   '银州区'
                  when 763051 then
                   '清河区'
                  when 763052 then
                   '铁岭县'
                  when 763053 then
                   '西丰县'
                  when 763054 then
                   '昌图县'
                  when 763055 then
                   '调兵山市'
                  when 763056 then
                   '开原市'
                  when 763057 then
                   '双塔区'
                  when 763058 then
                   '龙城区'
                  when 763059 then
                   '朝阳县'
                  when 763060 then
                   '建平县'
                  when 763061 then
                   '喀喇沁左翼蒙古族自治县'
                  when 763062 then
                   '北票市'
                  when 763063 then
                   '凌源市'
                  when 763064 then
                   '连山区'
                  when 763065 then
                   '龙港区'
                  when 763066 then
                   '南票区'
                  when 763067 then
                   '绥中县'
                  when 763068 then
                   '建昌县'
                  when 763069 then
                   '兴城市'
                  when 763070 then
                   '宽城区'
                  when 763071 then
                   '二道区'
                  when 763072 then
                   '绿园区'
                  when 763073 then
                   '双阳区'
                  when 763074 then
                   '农安县'
                  when 763075 then
                   '九台市'
                  when 763076 then
                   '榆树市'
                  when 763077 then
                   '德惠市'
                  when 763078 then
                   '昌邑区'
                  when 763079 then
                   '龙潭区'
                  when 763080 then
                   '船营区'
                  when 763081 then
                   '丰满区'
                  when 763082 then
                   '永吉县'
                  when 763083 then
                   '蛟河市'
                  when 763084 then
                   '桦甸市'
                  when 2776450 then
                   '市区'
                  when 2776451 then
                   '普陀区'
                  when 2825150 then
                   ' 中山市'
                  when 2825151 then
                   '高新技术开发区'
                  when 3037050 then
                   '高新区'
                  when 3102050 then
                   '政务文化新区'
                  when 3213200 then
                   '和平区'
                  when 3228300 then
                   '新城区'
                  when 3230101 then
                   '仙桃'
                  when 3230102 then
                   '潜江'
                  when 3230103 then
                   '天门'
                  when 3230113 then
                   '长安区'
                  when 3230114 then
                   '新华区'
                  when 3230115 then
                   '经济技术开发区'
                  when 3230116 then
                   '桥东区'
                  when 3230117 then
                   '桥西区'
                  when 3230118 then
                   '新市区'
                  when 3230119 then
                   '高开区'
                  when 3230120 then
                   '桥东区'
                  when 3230121 then
                   '桥西区'
                  when 3230122 then
                   '新华区'
                  when 3230123 then
                   '城区'
                  when 3230124 then
                   '城区'
                  when 3230125 then
                   '矿区'
                  when 3230126 then
                   '郊区'
                  when 3230127 then
                   '城区'
                  when 3230128 then
                   '郊区'
                  when 3230129 then
                   '高新区'
                  when 3230130 then
                   '城区'
                  when 761059 then
                   '济源市'
                  when 3230132 then
                   '青山区'
                  when 3230133 then
                   '浑南新区'
                  when 3230134 then
                   '张士开发区'
                  when 3230135 then
                   '沈北新区'
                  when 3230136 then
                   '开发区'
                  when 3230137 then
                   '高新园区'
                  when 3230138 then
                   '铁西区'
                  when 3230139 then
                   '高新区'
                  when 3230140 then
                   '北镇市'
                  when 3230141 then
                   '南关区'
                  when 3230142 then
                   '朝阳区'
                  when 3230143 then
                   '高新技术产业开发区'
                  when 3230144 then
                   '汽车产业开发区'
                  when 3230145 then
                   '经济技术开发区'
                  when 3230146 then
                   '净月旅游开发区'
                  when 3230147 then
                   '铁西区'
                  when 3230148 then
                   '铁东区'
                  when 3230149 then
                   '南山区'
                  when 3233000 then
                   '东山区'
                  when 3233001 then
                   '宝山区'

                  else
                   ''
                end;
  return v_areaname;
end;


/

