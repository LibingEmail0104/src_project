CREATE FUNCTION get_display (p_display number) return varchar2 is
  v_display varchar2(50);
begin
  --商品上下架 （1 上架, 0 下架, 2 隐藏）
  v_display := case p_display
                   when 0 then
                    '下架'
                   when 1 then
                    '上架'
                   when 2 then
                    '隐藏'
                   else
                    '未知状态'||p_display
                 end;
  return v_display;
end;


/

