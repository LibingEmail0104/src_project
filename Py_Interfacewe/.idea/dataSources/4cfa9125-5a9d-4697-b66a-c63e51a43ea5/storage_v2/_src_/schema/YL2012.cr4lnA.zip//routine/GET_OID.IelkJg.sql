CREATE function get_oid (v_dt varchar,v_wid number)
return varchar2 as
pragma autonomous_transaction;
v_id number;
v_sql CLOB;
v_mtime   varchar2(200);
-- v_wid=0 ordersid, v_wid=1 orderdetailid
 begin
    v_mtime:=v_dt;
   if v_wid =0
     then
      <<f1_loop>>
      loop

        select min(ordersid) into v_id from vt_od_ids where ordersid is not null and  mtime=v_mtime and oisuse=0;
        v_sql:='call  up_oid('''||v_id||''',0)';
        EXECUTE  immediate v_sql ;

      if  v_id is not null  then
        return v_id;
        exit f1_loop;
      else
          v_mtime:=to_char(to_date(v_mtime,'yyyymmdd')-1,'yyyymmdd');
      end if;
      end loop f1_loop;


    elsif  v_wid =1
      then
     <<f2_loop>>
/*     loop
      select min(ordersdetailid) into v_id from vt_od_ids where ordersdetailid is not null and mtime=v_mtime and odisuse=0;
      v_sql:='call  up_oid('''||v_id||''',1)';
      EXECUTE  immediate v_sql ;

     if  v_id is not null  then
        return v_id;
        exit f2_loop;
      else
          v_mtime:=to_char(to_date(v_mtime,'yyyymmdd')-1,'yyyymmdd');
      end if;
      end loop f2_loop;
    end if;*/
  loop

      select min(ordersdetailid) into v_id from vt_od_ids where ordersdetailid is not null and mtime=v_mtime and odisuse=0;
      v_sql:='call  up_oid('''||v_id||''',1)';
      EXECUTE  immediate v_sql ;
      if  v_id is not null  then
        return v_id;
        exit f2_loop;
      else
         select seq_order.nextval into  v_id from dual;
         return v_id;
         exit f2_loop;
      end if;
      end loop f2_loop;
    end if;


exception
  when no_data_found then
    return '0'  ;
end;

/

