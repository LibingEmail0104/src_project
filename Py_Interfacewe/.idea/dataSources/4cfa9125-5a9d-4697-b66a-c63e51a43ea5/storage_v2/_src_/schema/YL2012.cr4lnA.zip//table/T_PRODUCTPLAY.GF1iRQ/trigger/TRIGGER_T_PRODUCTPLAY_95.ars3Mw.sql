CREATE TRIGGER TRIGGER_T_PRODUCTPLAY_95
  AFTER INSERT
  ON T_PRODUCTPLAY
  FOR EACH ROW
  declare
  pragma autonomous_transaction;
  v_producttypeaid1 number;

begin
  select p.producttypeaid1
    into v_producttypeaid1
    from t_product p
   where p.productid = :new.productid;

  if (v_producttypeaid1 = 142452) then
    insert into t_hostdiscount
      (hostid,
       productplayid,
       discountdetailid,
       startintervaltime,
       endintervaltime,
       createtime,
       lasttime,
       lastuser,
       hosttype,
       status)
    values
      (seq_a.nextval,
       :new.productplayid,
       70114,
       to_date('15-10-2014', 'dd-mm-yyyy'),
       to_date('31-10-2014 23:59:59', 'dd-mm-yyyy hh24:mi:ss'),
       sysdate,
       sysdate,
       'AUTO95',
       0,
       1);
    commit;
    dbms_output.put_line('已插入95');
  end if;

end;




/

