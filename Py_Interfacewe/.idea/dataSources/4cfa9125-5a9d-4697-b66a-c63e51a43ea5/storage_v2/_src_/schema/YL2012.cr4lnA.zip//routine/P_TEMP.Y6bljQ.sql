CREATE PROCEDURE p_temp is
  --定义游标
  cursor c_ci2 is

    select   * from   ztemp1  ;

  r_ci2 c_ci2 % rowtype;
  --判断循环次数
  v_index number := 0;
begin
  --判断游标是否打开
  if c_ci2%isopen then
    null;
  else
    open c_ci2;
  end if;

  loop
    fetch c_ci2
      into r_ci2;
    exit when c_ci2%notfound;

  update ztemp1 t set  ctime=( select ctime from ztemp2  t2 where r_ci2.id>t2.min and r_ci2.id<t2.max) where t.id=r_ci2.id ;

    --分段提交
    v_index := v_index + 1;
   commit;
  end loop;

   commit;

  close c_ci2;
end p_temp;

/

