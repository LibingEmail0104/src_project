CREATE VIEW TV_CWPZ_ORDERS_ONE_PMDID AS
  select /*+ parallel(2) */  o.ordersid,tp.productid , pmd.id,count(*) counts
 from t_orders         o,
               t_payment_detail pmd,
               t_ordersdetail   tod,
               t_productplay        tp,
               tv_cwpz_orders_one tm
         where o.ordersid = tod.ordersid
           and pmd.order_id = o.ordersid
           and tod.productplayid = tp.productplayid
           and tm.ordersid=o.ordersid
           and o.createtime >to_date('20131231', 'yyyymmdd')   group by  o.ordersid,tp.productid , pmd.id  order by 1
/

