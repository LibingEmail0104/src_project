CREATE FUNCTION          "GET_PAYSTATUS" (paystatus number) return varchar2 is
  v_paystatus varchar2(50);
begin
  v_paystatus := case paystatus
                   when 0 then
                    '未支付'
                   when 1 then
                    '部分支付'
                   when 2 then
                    '已支付'
                   when 3 then
                    '已退款'
                   when 4 then
                    '等待付款'
                   else
                    '未知状态'
                 end;
  return v_paystatus;
end;




/

