CREATE package body YL_AUTO_ORDER is
  procedure YL_ORDER_INSERT(IN_PRODUCTID  t_product.productid%TYPE, --商品ID
                            IN_TOTALPRICE in number, --需要传入的金额,用于扣减用
                            IN_PAYTYPE    in number, --支付方式(默认支付宝)  1:支付宝  2:乐通卡  3:赊销   4:现金 5:支票
                             -- IN_DISCOUNTID       T_DISCOUNT.DISCOUNTID%TYPE, --支付方式
                             --IN_DISCOUNTDETAILID T_DISCOUNTDETAIL.DISCOUNTDETAILID%TYPE, --具体支付方式
                            IN_ORDERSOURCE T_ORDERS.ORDERSOURCE%TYPE, --订单来源 【订单来源】1:电话,2:网络,3:票务前台用户,4:票务前台票点,50:联盟,60:乐票通,70:IOS,80:ANDROID,90:WAP
                            in_customersid      t_customers.customersid%TYPE ,
                            IN_ORDER_DATE DATE
                            ) is
    --------------------------
    --乐通卡   IN_DISCOUNTID = 1665050; IN_DISCOUNTDETAILID=null;
    --支付宝   IN_DISCOUNTID = 70056; IN_DISCOUNTDETAILID=2217200;
    --赊销     IN_DISCOUNTID = 70049; IN_DISCOUNTDETAILID=null;
    --现金     IN_DISCOUNTID = 70054; IN_DISCOUNTDETAILID=null;
    --根据批次号查询插入了多少金额 select sum(t.ytotal) from t_orders t,t_ordersdetail o  where t.zproductzpids='YL_TL_TEST_10'  and t.ordersid=o.ordersid;
    --------------------------
         IN_BATCH varchar2(40);
        V_BATCH varchar2(200);



    V_ENDPRICE          number := 0; --循环增加此金额,达到指定金额后的退出条件
    IN_DISCOUNTID       T_DISCOUNT.DISCOUNTID%TYPE; --支付方式
    IN_DISCOUNTDETAILID T_DISCOUNTDETAIL.DISCOUNTDETAILID%TYPE; --具体支付方式

    ---------------------------票价参数----------------------------
    V_PRODUCTPLAYID t_productplay.productplayid%TYPE; --票价ID
    V_PRODUCTPRICE  t_productplay.price%TYPE; --票价
    V_MAXPRODUCTPRICE  t_productplay.price%TYPE;   --最高票价
    V_MINPRODUCTPRICE  t_productplay.price%TYPE;   --最高票价
    V_NUMBER        t_productplay.num%TYPE; --数量

    ---------------------------订单参数----------------------------
    V_ORDERSID          t_orders.ordersid%TYPE; --订单ID
    V_ordersdetailid    t_ordersdetail.ordersdetailid%TYPE; --订单明细ID
    V_FCONFIGID         t_product.fconfigid%TYPE; --分站ID
    V_ORDERS_TOTALPRICE t_orders.ytotal%TYPE; --订单总价
    V_CREATETIME        t_orders.createtime%TYPE; --订单创建时间
    V_PAYDATE           t_orders.createtime%TYPE; --支付时间
    V_PAYID             t_payment.dealtime%TYPE; --第三方支付ID,快钱,支付宝等
    V_ORDERSOURCE        NUMBER;
    V_ORDERSOURCE_TEMP  NUMBER;

    --------------------------支付参数-------------------------------
    v_paymentid           t_payment.paymentid%TYPE;         --支付ID
    v_PAYSUCCESSFULTIME  t_payment.PAYSUCCESSFULTIME%TYPE;  --支付时间
    v_id                 t_payment_detail.id%TYPE;            --明细ID


    --------------------------地址参数-----------------------------
    V_ADDRESSID          t_address.addressid%TYPE; --地址ID
    V_CUSTOMERSID        t_address.customersid%TYPE; --用户ID
    V_ADDRESS_NAME       t_address.name%TYPE; --收货地址
    V_ADDRESS_TYPE       t_address.type%TYPE; --地址类型
    V_ADDRESS_ZIP        t_address.zip%TYPE; --邮编
    V_ADDRESS_USERNAME   t_address.username%TYPE; --收货人
    V_ADDRESS_PHONE      t_address.phone%TYPE; --收货人手机号
    V_ADDRESS_PROVINCEID t_address.provinceid%TYPE; --省
    V_ADDRESS_CITYID     t_address.cityid%TYPE; --市
    V_ADDRESS_AREAID     t_address.areaid%TYPE; --区
    V_ADDRESS_CODEID     t_address.codeid%TYPE; --范围
    v_minid               number;
    v_maxid               number;

    --票价游标(查询指定商品票价集合,不包括隐藏和无效票价)
    cursor C_PRODUCTPLAY is
      SELECT productplayid, price
        FROM (select t.productplayid, t.price
                from t_productplay t
               where t.productid = IN_PRODUCTID --48777633
                   and t.price>16
--                 and t.starus <> 3
--                 and t.starus <> 5
--                   and t.price<2000
--                     and (t.playdate > IN_ORDER_DATE     or  t.playdate is null)
               ORDER BY dbms_random.value)
       WHERE ROWNUM < 2;





    --定义一个游标变量c_productplayrow c_productplay%rowtype ，该类型为游标c_productplay中的一行数据类型
         C_PRODUCTPLAY_ROW C_PRODUCTPLAY%rowtype;

  begin


    --支付方式如果为空,则默认为支付宝
    --if IN_PAYTYPE is null then
    --IN_PAYTYPE := 1;
    --end if;

    --70056  在线支付  2217200  支付宝
    --70049  赊销  71796727  赊销
    --1665050  乐通卡  66985006  乐通卡
    --70054  现金  71796728  现金          --赋值支付方式
    --  1613300  支票  71772150  支票
    --  48668970  微信支付  71754712  微信支付
    --  70056  在线支付  57120812  微信扫码支付




     select  'YL_0_' ||IN_PRODUCTID||to_char(sysdate,'yyyymmdd') into V_BATCH from dual; --批次号


     --最高票价
     select max(t.price) into  V_MAXPRODUCTPRICE
                from t_productplay t
               where t.productid = IN_PRODUCTID --48777633
--                     and t.playdate >= IN_ORDER_DATE
                     ;
    --最低票价
     select min(t.price) into  V_MINPRODUCTPRICE
                from t_productplay t
               where t.productid = IN_PRODUCTID and t.price>16;





    --------------------------赋值支付方式-----------------------------------

    IN_DISCOUNTID := case IN_PAYTYPE
                       when 1 then
                        70056
                       when 2 then
                        1665050
                       when 3 then
                        70049
                       when 4 then
                        70054
                       when 5 then
                         1613300
                       when 6 then
                         48668970
                       when 7 then
                         70056
                     end;
    IN_DISCOUNTDETAILID := case IN_PAYTYPE
                             when 1 then
                              2217200
                             when 2 then
                              66985006
                             when 3 then
                              71796727
                             when 4 then
                              71796728
                             when 5 then
                              71772150
                              when 6 then
                              71754712
                              when 7 then
                               57120812
                           end;
-----------------------------------------------------------------------------------



--    dbms_output.put_line(IN_PRODUCTID || '--' || IN_TOTALPRICE || '--' ||
--                         IN_DISCOUNTID || '--' || IN_DISCOUNTDETAILID || '--' ||
--                         V_BATCH || '--' || V_ENDPRICE);

    for C_PRODUCTPLAY_ROW in C_PRODUCTPLAY loop
      V_PRODUCTPLAYID := C_PRODUCTPLAY_ROW.Productplayid;
      V_PRODUCTPRICE  := C_PRODUCTPLAY_ROW.PRICE;
    end loop;

    --有票价再进行---
------------------------general-------------------------------------------------------------------------------------------------------------------
    if V_PRODUCTPLAYID is not null and (IN_PAYTYPE!=3 or   V_ORDERSOURCE!=4 ) then   --不是赊销 或 来源不是票点
--      dbms_output.put_line('-start-:' ||
--                           to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss'));

      --开始循环
      loop
        for C_PRODUCTPLAY_ROW in C_PRODUCTPLAY loop
          --dbms_output.put_line(C_PRODUCTPLAY_ROW.productplayid || '===' ||C_PRODUCTPLAY_ROW.PRICE);
          V_PRODUCTPLAYID := C_PRODUCTPLAY_ROW.Productplayid;
          V_PRODUCTPRICE  := C_PRODUCTPLAY_ROW.PRICE;
          --dbms_output.put_line(V_PRODUCTPLAYID || '===' ||V_PRODUCTPRICE);
        end loop;

        --根据商品结束日期向前随机创建日期
       -- V_CREATETIME := get_date_minus_tl(IN_PRODUCTID,
       --                                  round(dbms_random.value(2, 60)),
       --                                   round(dbms_random.value(0, 86400)));


       -- ORDERSOURCE=5 当来源为随机时：
       if IN_ORDERSOURCE=5 then
             V_ORDERSOURCE_TEMP:=round(dbms_random.value(0.8, 4.2));
                IF V_ORDERSOURCE_TEMP=1 THEN
                    V_ORDERSOURCE:=1;
                ELSIF V_ORDERSOURCE_TEMP=2 THEN
                    V_ORDERSOURCE:=2;
                ELSIF V_ORDERSOURCE_TEMP=3 THEN
                    V_ORDERSOURCE:=80;
               ELSIF V_ORDERSOURCE_TEMP=4 THEN
                    V_ORDERSOURCE:=70;
                END IF;
       ELSE
            V_ORDERSOURCE:=IN_ORDERSOURCE;

       END IF;






       select  get_date_add_tl2(IN_ORDER_DATE,IN_PRODUCTID,0, dbms_random.value(28800, 75600))  into   V_CREATETIME from dual;
       ----订单创建时间,随机在传入日期的一天正常时间内



        --dbms_output.put_line(V_PRODUCTPLAYID || '===' || V_PRODUCTPRICE ||'===' || V_CREATETIME);

        --获取分站ID
        select p.fconfigid
          into V_FCONFIGID
          from t_product p
         where p.productid = IN_PRODUCTID;
        --随机张数 num





     --V_ORDERS_TOTALPRICE
    --         dbms_output.put_line('V_ENDPRICE:'||V_ENDPRICE );
    --                     dbms_output.put_line('V_MAXPRODUCTPRICE:'||V_MAXPRODUCTPRICE );

    exit when V_ENDPRICE +V_MINPRODUCTPRICE  >= IN_TOTALPRICE;

    if    V_ENDPRICE + V_MAXPRODUCTPRICE *6 <= IN_TOTALPRICE then
               SELECT   dbms_random.value(5, 6) into V_NUMBER FROM dual;
     elsif V_ENDPRICE + V_MAXPRODUCTPRICE *5 < IN_TOTALPRICE then
                SELECT productplayid, price into   V_PRODUCTPLAYID,V_PRODUCTPRICE
                FROM (select t.productplayid, t.price
                from t_productplay t
               where t.productid = IN_PRODUCTID
               and price>16 ORDER BY  price desc)
       WHERE ROWNUM < 2;
               SELECT   dbms_random.value(4, 5) into V_NUMBER FROM dual;
     elsif V_ENDPRICE + V_MAXPRODUCTPRICE *4 < IN_TOTALPRICE then
               SELECT productplayid, price into   V_PRODUCTPLAYID,V_PRODUCTPRICE
                FROM (select t.productplayid, t.price
                from t_productplay t
               where t.productid = IN_PRODUCTID
               and price>16 ORDER BY  price desc)
       WHERE ROWNUM < 2;
               SELECT   dbms_random.value(3, 4) into V_NUMBER FROM dual;
       elsif V_ENDPRICE + V_MAXPRODUCTPRICE *3 < IN_TOTALPRICE then
               SELECT productplayid, price into   V_PRODUCTPLAYID,V_PRODUCTPRICE
                FROM (select t.productplayid, t.price
                from t_productplay t
               where t.productid = IN_PRODUCTID
               and price>16 ORDER BY  price desc)
       WHERE ROWNUM < 2;
               SELECT   dbms_random.value(2, 3) into V_NUMBER FROM dual;

    elsif V_ENDPRICE + V_MinPRODUCTPRICE *6 < IN_TOTALPRICE then
               SELECT productplayid, price into   V_PRODUCTPLAYID,V_PRODUCTPRICE
                FROM (select t.productplayid, t.price
                from t_productplay t
               where t.productid = IN_PRODUCTID    and price>16
               ORDER BY  price  )
       WHERE ROWNUM < 2;
               SELECT   dbms_random.value(5, 6) into V_NUMBER FROM dual;
    elsif V_ENDPRICE + V_MinPRODUCTPRICE *5 < IN_TOTALPRICE then
               SELECT productplayid, price into   V_PRODUCTPLAYID,V_PRODUCTPRICE
                FROM (select t.productplayid, t.price
                from t_productplay t
               where t.productid = IN_PRODUCTID  and price>16
               ORDER BY  price  )
       WHERE ROWNUM < 2;
               SELECT   dbms_random.value(4, 5) into V_NUMBER FROM dual;
  elsif V_ENDPRICE + V_MinPRODUCTPRICE *4 < IN_TOTALPRICE then
               SELECT productplayid, price into   V_PRODUCTPLAYID,V_PRODUCTPRICE
                FROM (select t.productplayid, t.price
                from t_productplay t
               where t.productid = IN_PRODUCTID  and price>16
               ORDER BY  price  )
       WHERE ROWNUM < 2;
               SELECT   dbms_random.value(3, 4) into V_NUMBER FROM dual;
  elsif V_ENDPRICE + V_MinPRODUCTPRICE *3 < IN_TOTALPRICE then
               SELECT productplayid, price into   V_PRODUCTPLAYID,V_PRODUCTPRICE
                FROM (select t.productplayid, t.price
                from t_productplay t
               where t.productid = IN_PRODUCTID  and price>16
               ORDER BY  price  )
       WHERE ROWNUM < 2;
               SELECT   dbms_random.value(2, 3) into V_NUMBER FROM dual;
  elsif V_ENDPRICE + V_MinPRODUCTPRICE *2 < IN_TOTALPRICE then
               SELECT productplayid, price into   V_PRODUCTPLAYID,V_PRODUCTPRICE
                FROM (select t.productplayid, t.price
                from t_productplay t
               where t.productid = IN_PRODUCTID  and price>16
               ORDER BY  price  )
       WHERE ROWNUM < 2;
               SELECT   dbms_random.value(1, 2) into V_NUMBER FROM dual;
  elsif  V_ENDPRICE + V_MinPRODUCTPRICE *1 < IN_TOTALPRICE then
               SELECT productplayid, price into   V_PRODUCTPLAYID,V_PRODUCTPRICE
                FROM (select t.productplayid, t.price
                from t_productplay t
               where t.productid = IN_PRODUCTID  and price>16
               ORDER BY  price  )
       WHERE ROWNUM < 2;
               SELECT  1 into V_NUMBER FROM dual;
  else
        exit;
     end if;



        --获取收获地址信息

        select CUSTOMERSID,phone,uname
          into V_CUSTOMERSID,
            V_ADDRESS_PHONE,
            V_ADDRESS_USERNAME
          from t_cw_customers
         where id = round(dbms_random.value(3, 856792), 0);



--------------地址随机---------------------------
if v_fconfigid=1 then v_minid:=1;v_maxid:=181318;
elsif v_fconfigid=84500 then v_minid:=213853;v_maxid:=290973;
elsif v_fconfigid=131053 then v_minid:=312208;v_maxid:=338386;
elsif v_fconfigid=2350506 then v_minid:=447898;v_maxid:=450188;
elsif v_fconfigid=2350510 then v_minid:=456712;v_maxid:=457017;
elsif v_fconfigid=2350511 then v_minid:=457018;v_maxid:=458603;
elsif v_fconfigid=2535501 then v_minid:=472621;v_maxid:=479975;
elsif v_fconfigid=45345310 then v_minid:=529451;v_maxid:=531007;
elsif v_fconfigid=47194943 then v_minid:=535188;v_maxid:=535631;
elsif v_fconfigid=67253390 then v_minid:=557147;v_maxid:=557673;
elsif v_fconfigid=131340383 then v_minid:=570213;v_maxid:=570310;
elsif v_fconfigid=186363414 then v_minid:=575984;v_maxid:=576370;
elsif v_fconfigid=197402034 then v_minid:=576699;v_maxid:=576981;
elsif v_fconfigid=2350507 then v_minid:=450189;v_maxid:=451350;
elsif v_fconfigid=2350508 then v_minid:=451351;v_maxid:=453394;
elsif v_fconfigid=5214250 then v_minid:=502121;v_maxid:=502360;
elsif v_fconfigid=52144957 then v_minid:=549366;v_maxid:=550286;
elsif v_fconfigid=108070430 then v_minid:=568823;v_maxid:=568953;
elsif v_fconfigid=1661350 then v_minid:=406062;v_maxid:=418691;
elsif v_fconfigid=4396400 then v_minid:=494507;v_maxid:=502120;
elsif v_fconfigid=66140874 then v_minid:=555330;v_maxid:=555823;
elsif v_fconfigid=85967606 then v_minid:=565721;v_maxid:=566035;
elsif v_fconfigid=160884144 then v_minid:=573875;v_maxid:=574013;
elsif v_fconfigid=2350505 then v_minid:=446338;v_maxid:=447897;
elsif v_fconfigid=2870000 then v_minid:=479976;v_maxid:=491716;
elsif v_fconfigid=51360987 then v_minid:=539371;v_maxid:=540506;
elsif v_fconfigid=65831822 then v_minid:=555147;v_maxid:=555329;
elsif v_fconfigid=84314898 then v_minid:=565174;v_maxid:=565485;
elsif v_fconfigid=84590210 then v_minid:=565486;v_maxid:=565704;
elsif v_fconfigid=88115564 then v_minid:=566283;v_maxid:=566298;
elsif v_fconfigid=101789186 then v_minid:=568316;v_maxid:=568558;
elsif v_fconfigid=128159551 then v_minid:=569727;v_maxid:=569820;
elsif v_fconfigid=136795092 then v_minid:=572684;v_maxid:=572858;
elsif v_fconfigid=165279237 then v_minid:=574113;v_maxid:=574523;
elsif v_fconfigid=131051 then v_minid:=294272;v_maxid:=295403;
elsif v_fconfigid=3950200 then v_minid:=491717;v_maxid:=494506;
elsif v_fconfigid=50618886 then v_minid:=538385;v_maxid:=538609;
elsif v_fconfigid=51973785 then v_minid:=544386;v_maxid:=549365;
elsif v_fconfigid=80495831 then v_minid:=563160;v_maxid:=563627;
elsif v_fconfigid=80886573 then v_minid:=563853;v_maxid:=563943;
elsif v_fconfigid=82000488 then v_minid:=564517;v_maxid:=564661;
elsif v_fconfigid=131065784 then v_minid:=569821;v_maxid:=570029;
elsif v_fconfigid=135584214 then v_minid:=571755;v_maxid:=572012;
elsif v_fconfigid=182049884 then v_minid:=575730;v_maxid:=575850;
elsif v_fconfigid=218348235 then v_minid:=577979;v_maxid:=578680;
elsif v_fconfigid=11533200 then v_minid:=517247;v_maxid:=517929;
elsif v_fconfigid=54549350 then v_minid:=550594;v_maxid:=551539;
elsif v_fconfigid=55265882 then v_minid:=551540;v_maxid:=552677;
elsif v_fconfigid=69457848 then v_minid:=557936;v_maxid:=558295;
elsif v_fconfigid=87420685 then v_minid:=566236;v_maxid:=566282;
elsif v_fconfigid=139910254 then v_minid:=572859;v_maxid:=573234;
elsif v_fconfigid=131052 then v_minid:=295404;v_maxid:=312207;
elsif v_fconfigid=131055 then v_minid:=365396;v_maxid:=384164;
elsif v_fconfigid=2350501 then v_minid:=425139;v_maxid:=445148;
elsif v_fconfigid=2350513 then v_minid:=469033;v_maxid:=469498;
elsif v_fconfigid=2350514 then v_minid:=469499;v_maxid:=470001;
elsif v_fconfigid=44429175 then v_minid:=517930;v_maxid:=518317;
elsif v_fconfigid=45591871 then v_minid:=531830;v_maxid:=532295;
elsif v_fconfigid=72174567 then v_minid:=560243;v_maxid:=560729;
elsif v_fconfigid=101786298 then v_minid:=567790;v_maxid:=567821;
elsif v_fconfigid=131096348 then v_minid:=570030;v_maxid:=570134;
elsif v_fconfigid=151512962 then v_minid:=573235;v_maxid:=573245;
elsif v_fconfigid=166004284 then v_minid:=574524;v_maxid:=574915;
elsif v_fconfigid=203073789 then v_minid:=577163;v_maxid:=577388;
elsif v_fconfigid=131056 then v_minid:=384165;v_maxid:=406061;
elsif v_fconfigid=2350503 then v_minid:=445757;v_maxid:=445962;
elsif v_fconfigid=6742100 then v_minid:=503684;v_maxid:=504955;
elsif v_fconfigid=45277388 then v_minid:=527834;v_maxid:=528994;
elsif v_fconfigid=45395428 then v_minid:=531008;v_maxid:=531829;
elsif v_fconfigid=51844107 then v_minid:=540507;v_maxid:=544385;
elsif v_fconfigid=78979880 then v_minid:=562264;v_maxid:=562549;
elsif v_fconfigid=96772601 then v_minid:=566767;v_maxid:=567095;
elsif v_fconfigid=101784805 then v_minid:=567240;v_maxid:=567789;
elsif v_fconfigid=124879361 then v_minid:=569468;v_maxid:=569726;
elsif v_fconfigid=131340023 then v_minid:=570156;v_maxid:=570212;
elsif v_fconfigid=170097284 then v_minid:=574966;v_maxid:=575370;
elsif v_fconfigid=175446704 then v_minid:=575586;v_maxid:=575729;
elsif v_fconfigid=220138727 then v_minid:=578681;v_maxid:=579054;
elsif v_fconfigid=6377000 then v_minid:=502361;v_maxid:=503683;
elsif v_fconfigid=10923150 then v_minid:=512054;v_maxid:=517246;
elsif v_fconfigid=69288840 then v_minid:=557674;v_maxid:=557935;
elsif v_fconfigid=85925404 then v_minid:=565705;v_maxid:=565720;
elsif v_fconfigid=117116998 then v_minid:=569196;v_maxid:=569467;
elsif v_fconfigid=156879453 then v_minid:=573246;v_maxid:=573820;
elsif v_fconfigid=82500 then v_minid:=181319;v_maxid:=213852;
elsif v_fconfigid=2350500 then v_minid:=418692;v_maxid:=425138;
elsif v_fconfigid=45733256 then v_minid:=532296;v_maxid:=532555;
elsif v_fconfigid=66417245 then v_minid:=555824;v_maxid:=555905;
elsif v_fconfigid=66562619 then v_minid:=555906;v_maxid:=557112;
elsif v_fconfigid=80812899 then v_minid:=563628;v_maxid:=563852;
elsif v_fconfigid=82000945 then v_minid:=564662;v_maxid:=564749;
elsif v_fconfigid=131264878 then v_minid:=570135;v_maxid:=570155;
elsif v_fconfigid=211801953 then v_minid:=577389;v_maxid:=577698;
elsif v_fconfigid=45216767 then v_minid:=526413;v_maxid:=526661;
elsif v_fconfigid=45324515 then v_minid:=528995;v_maxid:=529450;
elsif v_fconfigid=70853344 then v_minid:=558296;v_maxid:=558786;
elsif v_fconfigid=72174665 then v_minid:=560730;v_maxid:=561009;
elsif v_fconfigid=101788098 then v_minid:=567976;v_maxid:=568315;
elsif v_fconfigid=189491618 then v_minid:=576371;v_maxid:=576467;
elsif v_fconfigid=7582150 then v_minid:=504956;v_maxid:=507078;
elsif v_fconfigid=9722400 then v_minid:=507079;v_maxid:=512053;
elsif v_fconfigid=47026354 then v_minid:=533035;v_maxid:=535187;
elsif v_fconfigid=62124540 then v_minid:=552803;v_maxid:=554111;
elsif v_fconfigid=77585959 then v_minid:=561816;v_maxid:=562263;
elsif v_fconfigid=79509558 then v_minid:=562550;v_maxid:=563159;
elsif v_fconfigid=106144477 then v_minid:=568559;v_maxid:=568822;
elsif v_fconfigid=111231052 then v_minid:=568954;v_maxid:=569195;
elsif v_fconfigid=196549660 then v_minid:=576468;v_maxid:=576698;
elsif v_fconfigid=131054 then v_minid:=338387;v_maxid:=365395;
elsif v_fconfigid=2350502 then v_minid:=445149;v_maxid:=445756;
elsif v_fconfigid=44872151 then v_minid:=521198;v_maxid:=525421;
elsif v_fconfigid=45191511 then v_minid:=525770;v_maxid:=526412;
elsif v_fconfigid=66616127 then v_minid:=557113;v_maxid:=557146;
elsif v_fconfigid=71120954 then v_minid:=558787;v_maxid:=559668;
elsif v_fconfigid=80887348 then v_minid:=563944;v_maxid:=564355;
elsif v_fconfigid=101787260 then v_minid:=567822;v_maxid:=567975;
elsif v_fconfigid=135584785 then v_minid:=572013;v_maxid:=572683;
elsif v_fconfigid=158639953 then v_minid:=573821;v_maxid:=573874;
elsif v_fconfigid=163367135 then v_minid:=574014;v_maxid:=574112;
elsif v_fconfigid=172744369 then v_minid:=575371;v_maxid:=575585;
elsif v_fconfigid=2350504 then v_minid:=445963;v_maxid:=446337;
elsif v_fconfigid=44458777 then v_minid:=518318;v_maxid:=519082;
elsif v_fconfigid=44977102 then v_minid:=525422;v_maxid:=525769;
elsif v_fconfigid=46519435 then v_minid:=532556;v_maxid:=533034;
elsif v_fconfigid=47738201 then v_minid:=535632;v_maxid:=538226;
elsif v_fconfigid=50143107 then v_minid:=538227;v_maxid:=538384;
elsif v_fconfigid=98068844 then v_minid:=567096;v_maxid:=567239;
elsif v_fconfigid=182067941 then v_minid:=575851;v_maxid:=575983;
elsif v_fconfigid=201754274 then v_minid:=576982;v_maxid:=577162;
elsif v_fconfigid=2350509 then v_minid:=453395;v_maxid:=456711;
elsif v_fconfigid=44872100 then v_minid:=519083;v_maxid:=521197;
elsif v_fconfigid=57276086 then v_minid:=552678;v_maxid:=552802;
elsif v_fconfigid=76201474 then v_minid:=561010;v_maxid:=561354;
elsif v_fconfigid=76864889 then v_minid:=561355;v_maxid:=561815;
elsif v_fconfigid=81998523 then v_minid:=564356;v_maxid:=564464;
elsif v_fconfigid=84238763 then v_minid:=564750;v_maxid:=565173;
elsif v_fconfigid=135178520 then v_minid:=571575;v_maxid:=571754;
elsif v_fconfigid=166008681 then v_minid:=574916;v_maxid:=574965;
elsif v_fconfigid=216441451 then v_minid:=577699;v_maxid:=577978;
elsif v_fconfigid=131050 then v_minid:=290974;v_maxid:=294271;
elsif v_fconfigid=2350512 then v_minid:=458604;v_maxid:=469032;
elsif v_fconfigid=2535500 then v_minid:=470002;v_maxid:=472620;
elsif v_fconfigid=45253678 then v_minid:=526662;v_maxid:=526683;
elsif v_fconfigid=45277304 then v_minid:=526684;v_maxid:=527833;
elsif v_fconfigid=50622507 then v_minid:=538610;v_maxid:=539370;
elsif v_fconfigid=52413515 then v_minid:=550287;v_maxid:=550593;
elsif v_fconfigid=64436701 then v_minid:=554112;v_maxid:=555146;
elsif v_fconfigid=72174487 then v_minid:=559669;v_maxid:=560242;
elsif v_fconfigid=81999497 then v_minid:=564465;v_maxid:=564516;
elsif v_fconfigid=87309420 then v_minid:=566036;v_maxid:=566235;
elsif v_fconfigid=89222419 then v_minid:=566299;v_maxid:=566766;
elsif v_fconfigid=133933847 then v_minid:=570311;v_maxid:=571574;
end if;







if   in_customersid=0 then
   select round(dbms_random.value(1, 2)),
       null,
       t.provinceid,
       t.cityid,
       t.areaid,
       t.codeid,
       name
  into V_ADDRESS_TYPE,
       V_ADDRESS_ZIP,
       V_ADDRESS_PROVINCEID,
       V_ADDRESS_CITYID,
       V_ADDRESS_AREAID,
       V_ADDRESS_CODEID,
       V_ADDRESS_NAME
  from t_cw_address t where id =round(dbms_random.value(v_minid,v_maxid));


else
          select in_customersid  into V_CUSTOMERSID from dual;
          select 1   into  V_ADDRESS_TYPE from dual;
          select 000000    into    V_ADDRESS_ZIP from dual;
          select '1' into      V_ADDRESS_PHONE from dual;
          select '1' into      V_ADDRESS_PROVINCEID from dual;
          select '1' into      V_ADDRESS_CITYID from dual;
          select '1' into      V_ADDRESS_AREAID  from dual;
          select '1' into      V_ADDRESS_CODEID  from dual;

end if;









        --获取收货地址及收货人姓名
  --      select addressname, username
   --       into V_ADDRESS_NAME, V_ADDRESS_USERNAME
   --       from (select a.name as addressname, a.username
  --                from t_address a
   --              where a.customersid=V_CUSTOMERSID
   --              )
   --      where rownum < 2;



        --计算订单总金额
        V_ORDERS_TOTALPRICE := (V_PRODUCTPRICE * V_NUMBER);

        --地址表主键ID
        select seq_address.nextval into V_ADDRESSID from dual;
        --插入地址
        insert into t_address
          (ADDRESSID,
           CUSTOMERSID,
           NAME,
           TYPE,
           ZIP,
           USERNAME,
           PHONE,
           TEL,
           ORDERS,
           REMARK,
           STATUS,
           CREATETIME,
           LASTTIME,
           LASTUSER,
           AREAID,
           CITYID,
           CODEID,
           PROVINCEID,
           DZPHONE,
           EMAIL,
           DELIVERY)
        values
          (V_ADDRESSID,
           V_CUSTOMERSID,
           V_ADDRESS_NAME,
           V_ADDRESS_TYPE,
           V_ADDRESS_ZIP,
           V_ADDRESS_USERNAME,
           V_ADDRESS_PHONE,
           null,
           null,
           null,
           0,
           V_CREATETIME,
           V_CREATETIME,
            'order_auto',
           V_ADDRESS_AREAID,
           V_ADDRESS_CITYID,
           V_ADDRESS_CODEID,
           V_ADDRESS_PROVINCEID,
           null,
           null,
           null);

        --生成订单ID



      --  select   get_oid(to_char(IN_ORDER_DATE,'yyyymmdd'),0)  into V_ORDERSID from dual;
       if to_char(IN_ORDER_DATE,'yyyymmdd')='20080101'
        then
               select   get_oid(to_char(v_createtime,'yyyymmdd'),0)  into V_ORDERSID from dual;
        else
              select   get_oid(to_char(IN_ORDER_DATE,'yyyymmdd'),0)  into V_ORDERSID from dual;
       end if;


        --创建订单
        insert into t_orders
          (ORDERSID,
           CUSTOMERSID,
           ADDRESSID,
           CLIENTINFO,
           COMPANYINFO,
           RANGEPRICE,
           LNVOICE,
           PSXX,
           APPEND,
           URGENTPRICE,
           SHSMDATE,
           YTOTAL,
           ZTOTAL,
           STARUS,
           ERRSTARUS,
           ZPRODUCTZPIDS,
           FPRODUCTFJPIDS,
           TYPE,
           PROTYPE,
           PROIDS,
           EXPRESSCOSTID,
           EXPRESSNO,
           PRINT,
           PRINTTIME,

           PRINTUSER,
           DELIVERYUSER,
           DELIVERYDATE,
           IP,
           CREATETIME,
           LASTTIME,
           LASTUSER,
           RANGEPINFO,
           ORDERSOURCE,
           GIFTID,
           TICKET,
           REFUNDS,
           WAREHOUSEDATE,
           TEXT,
           EXPRESSNAME,
           INTEGRAL,
           LPIDS,
           LPNUM,
           ZPNUM,
           FJPNUM,
           BACKMONEYDATE,
           backmoneystatus,      --
           WRITECHECKDATE,
           WRITECHECK,
           ISEND,
           FCONFIGID,
           ISMODIF,
           CHANGEMONEY,
           OLDORDERSID,
           ISCHANGEMONEY,
           WRITECHECKCODE,
           ISTEAMWORK,
           TXTONE,
           ISPWQTBACKMONEY,
           UNIONID,
           PROCESSINGSTARUS,
           CLEARREMARK,
           LPCARDID,
           ONLINE_SCREENINGINFO,
           ONLINE_ORDERSID,
           ONLINE_SENDTAG,
           UNIONORDERSID,
           CHANGEMONEYINFO,
           FINANCEINFO,
           FPPRICE,
           CREATEUSER,
           WRITECHECKINFO,
           ISDISCOUNTRESET,
           ISADDWRITECHECK,
           PRINTCOUNT,
           DZPHONE,
           ISPWQTDEALWITH,
           ISSGP,
           COMMISSION,
           INSUREDPUSHSTATUS,
           WRITECHECKPOSTDATE,
           CLAIMUSER,
           CLAIMTIME,
           INSUREDSTATUS,
           QZNUM,
           HDFK_PAYMENTTYPE,
           INTEGRALNEW,
           MULTIPLE,
           VERIFYTIME,
           ISENDUSER,
           ISENDTIME,
           CHANGEMONEYDATE,
           CHANGEMONEYENDDATE,
           ISWAITINGFORPAY,
           DZTYPE,
           VERIFYUSER,
           MATCHINGTIME,
           MATCHINGUSER,
           ISKGDEALWITH,
           WAREHOUSEDATEUPDATENUM,
           CANCLEREASON,
           RECEIPTTYPE,
           CANCLETIME,
           SPREADSOURCE,
           SETTLEMENTSTATUS,
           SETTLEMENTDATE,
           SETTLEMENTUSER,
           ORDERSSETTLEMENTSTATUS,
           SWEEPTIME,
           ISLIMIT,
           EQUIPMENTSYSTEM,
           ISMODIFTIME,
           ISMODIFUSER,
           LANGUAGES,
           ISREFUNDROAD,
           PAYTYPEINFO,
           CWERRORLASTUSER,
           BATCH)
        values
          (V_ORDERSID,
           V_CUSTOMERSID,
           case IN_PAYTYPE   when 4 then 0  when 3 then 0    else V_ADDRESSID end,
           null,
           null,
           0,
           null,
           case IN_PAYTYPE   when 4 then 2 when 3 then 2    else 1 end,
           0,
           0,
           1,
           V_ORDERS_TOTALPRICE,
           V_ORDERS_TOTALPRICE,
           10,
           0,
          '', -- V_BATCH
           null,
           0,
           2,
           IN_PRODUCTID,
           null,
           null,
           1,
           get_date_add_tl(V_CREATETIME,0,dbms_random.value(32400, 65600)), --打印四联单时间,随机5分钟
             'order_auto',
            'order_auto',
          get_date_add_tl(V_CREATETIME,0,dbms_random.value(3600, 10800)), --发货时间
           null,
           V_CREATETIME,
          get_date_add_tl(V_CREATETIME,0,dbms_random.value(32400, 65600)), --最后修改时间
           'order_auto',
           null,
          -- case IN_PAYTYPE   when 4 then 3  when 3 then 4    else V_ORDERSOURCE end,
          V_ORDERSOURCE,
           null,
           0,
           null,
           get_date_add_tl(V_CREATETIME,0,dbms_random.value(3600, 10800)), --发货时间
           null,
           null,
           0,
           null,
           null,
           null,
           null,
               get_date_add_tl(V_CREATETIME,0,dbms_random.value(3600, 10800)), --发货时间
           1,
           null,
           0,
           0,
           V_FCONFIGID,
           0,
           null,
           null,
           null,
           null,
           0,
           null,
           null,
           null,
           null,
           null,
           null,
           null,
           null,
           null,
           null,
           null,
           null,
           null,
           'order_auto',
           null,
           null,
           0,
           1,
           null,
           0,
           0,
           null,
           0,
           null,
            'order_auto',
           get_date_add_tl(V_CREATETIME, 0,  dbms_random.value(2400, 65600)), --认领时间
           0,
           null,
           null,
           0,
           1.0000,
           null,
           null,
           null,
           null,
           null,
           null,
           -1,
           'order_auto',
               get_date_add_tl(V_CREATETIME,0,dbms_random.value(3600, 10800)),   --配票时间
           'order_auto',
           0,
           0,
           null,
           null,
           null,
           null,
           0,
           null,
           null,
           null,
           null,
           0,
           null,
           get_date_add_tl(V_CREATETIME, 1, round(dbms_random.value(3600, 10800))), --终止修改时间
            'order_auto',
           null,
           null,
           null,
           null,
           V_BATCH);


        --创建订单明细
   --     select   get_oid(to_char(IN_ORDER_DATE,'yyyymmdd'),1)  into V_ordersdetailid from dual;
         if to_char(IN_ORDER_DATE,'yyyymmdd')='20080101'
          then
               select   get_oid(to_char(v_createtime,'yyyymmdd'),1)  into V_ordersdetailid from dual;
        else
              select   get_oid(to_char(IN_ORDER_DATE,'yyyymmdd'),1)  into V_ordersdetailid from dual;
       end if;
        insert into t_ordersdetail
          (ORDERSDETAILID,
           ORDERSID,
           PRODUCTPLAYID,
           PRICE,
           NUM,
           TOTAL,
           GIFTID,
           TICKET,
           HOSTDISCOUNT,
           INTEGRAL,
           SEAT,
           SYSTEM,
           CREATETIME,
           LASTTIME,
           LASTUSER,
           DISCOUNTDETAILID,
           PAPERNUMBER,
           DISCOUNT,
           DISCOUNTDETAILIDORGANIZER,
           DISCOUNTDETAILIDTEAMWORK,
           YTOTAL,
           CUSTOMERDISCOUNT,
           INSUREDSTATUS,
           INSUREDTOTAL,
           SETTLEMENTSTATUS,
           INTEGRALMULTIPLE,
           YLTOUSERDISCOUNT,
           JSDISCOUNT)
        values
          (V_ordersdetailid,
           V_ORDERSID,
           V_PRODUCTPLAYID,
           V_PRODUCTPRICE,
           V_NUMBER,
           V_ORDERS_TOTALPRICE,
           null,
           null,
           100,
           V_ORDERS_TOTALPRICE,
           null,
           70150,
           V_CREATETIME,
           get_date_add_tl(V_CREATETIME,
                           0,
                           round(dbms_random.value(400, 65600))),
           'order_auto',
           70100,
           null,
           null,
           3688000,
           null,
           V_ORDERS_TOTALPRICE,
           100,
           0,
           0,
           0,
           1,
           null,
           null);

        --第三方支付时间
        select get_date_add_tl(V_CREATETIME,
                               0,
                               round(dbms_random.value(10, 900)))
          into V_PAYDATE
          from dual;

        --第三方支付ID
        --支付宝支付ID
        if IN_PAYTYPE = 1 then
          select to_char(V_PAYDATE, 'yyyymmddhh24miss') ||
                 substr(cast(dbms_random.value as varchar2(38)), 3, 17)
            into V_PAYID
            from dual;
        end if;
        --乐通卡支付ID
        if IN_PAYTYPE = 2 then
          select substr(cast(dbms_random.value as varchar2(38)), 3, 8)
            into V_PAYID
            from dual;
        end if;

        --创建支付表  注:乐通卡字段那里未添加,待修改
    select seq_a.nextval into v_paymentid from dual;
        insert into t_payment
          (PAYMENTID,
           RMIDS,
           YSIDS,
           LJPRICE,
           YCKPRICE,
           LPKPRICE,
           SJZFPRICE,
           ZPRICE,
           PAYSTATUS,
           CREATETIME,
           LASTTIME,
           LASTUSER,
           ORDERSID,
           REMARK,
           DISCOUNTDETAILID,
           DISCOUNT,
           REFUNDS,
           REFUNDTIME,
           DEALTIME,
           OLDDISCOUNT,
           OLDSJZFPRICE,
           YSPRICE,
           OLDDISCOUNTDETAILID,
           REFUNPRICE,
           LTKPRICE,
           PAYCARDID,
           PAYCARDTYPE,
           PAYTELLOKTIME,
           DISCOUNTPAY,
           INSUREDAMOUNT,
           LPKCODEID,
           CHECKNO,
           CHECKCOMPANYNAME,
           PAYSUCCESSFULTIME,
           nzprice,
           isselect)
        values
          (v_paymentid,
           IN_PRODUCTID,
           null,
           0.000,
           0.000,
           0.000,
           V_ORDERS_TOTALPRICE,
           V_ORDERS_TOTALPRICE,
           2,
           V_CREATETIME,
           get_date_add_tl(V_CREATETIME,
                           0,
                           round(dbms_random.value(30, 90))),
           'payuser_auto',
           V_ORDERSID,
           null,
           IN_DISCOUNTDETAILID,
           IN_DISCOUNTID,
           0,
           null,
           V_PAYID,
           null,
           0.000,
           V_ORDERS_TOTALPRICE,
           null,
           0,
           case IN_PAYTYPE when 2 then V_ORDERS_TOTALPRICE else 0.000 end, --乐通卡
           case IN_PAYTYPE when 2 then
           '228' || substr(cast(dbms_random.value as varchar2(38)), 3, 13) else null end, --乐通卡
           case IN_PAYTYPE when 2 then 2 else null end, --乐通卡
           case IN_PAYTYPE when 1 then V_PAYDATE else null end,
           100,
           0,
           null,
           null,
           null,
          V_PAYDATE ,
           V_ORDERS_TOTALPRICE,
           '1');

    select seq_a.nextval into v_id from dual;

      insert into t_payment_detail
      (ID,
      PAYMENT_ID,
      ORDER_ID,
      ORIGINAL_FEE,
      ACTUAL_FEE,
      DISCOUNT,
      DISCOUNTDETAILID,
      PAYMENT_STATUS,
      TRADE_CREATE_TIME,
      TRADE_FINISH_TIME,
      THIRD_TRADE_NO,
      GMT_CREATE,
      DISCOUNTVALUE,
      LAST_TIME,
      LAST_USERS,
       ERROR_URL,
      REQUEST_CHANNEL,
      REQUEST_SOURCE,
      REQUEST_PARTNER,
      CARDNO,
      ORIGINAL_DISCOUNT_FEE,
      PAY_DISCOUNT_FEE)
    values
      (v_id,
      v_paymentid,
      V_ORDERSID,
      V_ORDERS_TOTALPRICE,
      V_ORDERS_TOTALPRICE,
      IN_DISCOUNTID,
      IN_DISCOUNTDETAILID,
      1,
      get_date_add_tl(V_CREATETIME,0,round(dbms_random.value(200, 2600))),
      V_PAYDATE,
      V_PAYID,
      V_CREATETIME,
      100,
      get_date_add_tl(V_CREATETIME,0,round(dbms_random.value(200, 2600))),
      'AUTO',
      'http://api.228.cn/alipay/pay_notify',
       case V_ORDERSOURCE   when 2 then 'web'  when 70 then 'IOS'   when 80 then 'ANDROID'   when 90 then 'WAP' else null end,
       case V_ORDERSOURCE   when 2 then 'web'  when 70 then 'IOS'  when 80 then 'ANDROID'   when 90 then 'WAP' else null end,
       case IN_PAYTYPE when 1 then 'alipay' when 2 then 'letong'  when 3 then 'shexiao' when 4 then 'cash' else null end ,
        case IN_PAYTYPE when 2 then '228' || substr(cast(dbms_random.value as varchar2(38)), 3, 13) else null end, --乐通卡
        V_ORDERS_TOTALPRICE,
       0);


                        dbms_output.put_line('-------------------putong-----'|| IN_DISCOUNTID );

        dbms_output.put_line('IN_DISCOUNTDETAILID:'|| IN_DISCOUNTDETAILID );

        --提交
        commit;
        --回滚测试数据
        --rollback;
        V_ENDPRICE := V_ENDPRICE + V_ORDERS_TOTALPRICE;
        --dbms_output.put_line('ordersID:' || V_ORDERSID);

        -----退出条件
        exit when V_ENDPRICE +V_MINPRODUCTPRICE  >= IN_TOTALPRICE;
                dbms_output.put_line('endloop');
       end loop;
      dbms_output.put_line(to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss'));



----------------------------------------------------赊销---------------------------------------------------------------------------------------
else
--      dbms_output.put_line('-start-:' ||
--                           to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss'));

 if IN_ORDERSOURCE=5 then
             V_ORDERSOURCE_TEMP:=round(dbms_random.value(0.8, 4.2));
                IF V_ORDERSOURCE_TEMP=1 THEN
                    V_ORDERSOURCE:=1;
                ELSIF V_ORDERSOURCE_TEMP=2 THEN
                    V_ORDERSOURCE:=2;
                ELSIF V_ORDERSOURCE_TEMP=3 THEN
                    V_ORDERSOURCE:=80;
               ELSIF V_ORDERSOURCE_TEMP=4 THEN
                    V_ORDERSOURCE:=70;
                END IF;
       ELSE
            V_ORDERSOURCE:=IN_ORDERSOURCE;

       END IF;



      --开始循环
      loop
        for C_PRODUCTPLAY_ROW in C_PRODUCTPLAY loop
          --dbms_output.put_line(C_PRODUCTPLAY_ROW.productplayid || '===' ||C_PRODUCTPLAY_ROW.PRICE);
          V_PRODUCTPLAYID := C_PRODUCTPLAY_ROW.Productplayid;
          V_PRODUCTPRICE  := C_PRODUCTPLAY_ROW.PRICE;
          --dbms_output.put_line(V_PRODUCTPLAYID || '===' ||V_PRODUCTPRICE);
        end loop;

        --根据商品结束日期向前随机创建日期
       -- V_CREATETIME := get_date_minus_tl(IN_PRODUCTID,
       --                                  round(dbms_random.value(2, 60)),
       --                                   round(dbms_random.value(0, 86400)));


             select  get_date_add_tl2(IN_ORDER_DATE,IN_PRODUCTID,0, dbms_random.value(0, 75600))  into   V_CREATETIME from dual;
       -- select trunc(IN_ORDER_DATE)+ dbms_random.value(28800, 75600)/ (24 * 60*60)  into   V_CREATETIME from dual;


        --dbms_output.put_line(V_PRODUCTPLAYID || '===' || V_PRODUCTPRICE ||'===' || V_CREATETIME);

        --获取分站ID
        select p.fconfigid
          into V_FCONFIGID
          from t_product p
         where p.productid = IN_PRODUCTID;
        --随机张数
        --V_ORDERS_TOTALPRICE
   exit when V_ENDPRICE +V_MINPRODUCTPRICE  >= IN_TOTALPRICE;
    if    V_ENDPRICE + V_MAXPRODUCTPRICE *500 < IN_TOTALPRICE then
               SELECT   dbms_random.value(200, 500) into V_NUMBER FROM dual;
    elsif    V_ENDPRICE + V_MAXPRODUCTPRICE *200 < IN_TOTALPRICE then
               SELECT   dbms_random.value(100, 200) into V_NUMBER FROM dual;
    elsif    V_ENDPRICE + V_MAXPRODUCTPRICE *100 < IN_TOTALPRICE then
               SELECT   dbms_random.value(80, 100) into V_NUMBER FROM dual;
    elsif    V_ENDPRICE + V_MAXPRODUCTPRICE *80 < IN_TOTALPRICE then
               SELECT   dbms_random.value(60, 80) into V_NUMBER FROM dual;
   elsif    V_ENDPRICE + V_MAXPRODUCTPRICE *60 < IN_TOTALPRICE then
               SELECT   dbms_random.value(50, 60) into V_NUMBER FROM dual;
   elsif  V_ENDPRICE + V_MAXPRODUCTPRICE *50 < IN_TOTALPRICE then
               SELECT   dbms_random.value(40, 50) into V_NUMBER FROM dual;
   elsif  V_ENDPRICE + V_MAXPRODUCTPRICE *40 < IN_TOTALPRICE then
               SELECT   dbms_random.value(30, 40) into V_NUMBER FROM dual;
   elsif  V_ENDPRICE + V_MAXPRODUCTPRICE *30 < IN_TOTALPRICE then
               SELECT   dbms_random.value(20, 30) into V_NUMBER FROM dual;
   elsif  V_ENDPRICE + V_MAXPRODUCTPRICE *20 < IN_TOTALPRICE then
               SELECT   dbms_random.value(10, 20) into V_NUMBER FROM dual;
   elsif  V_ENDPRICE + V_MAXPRODUCTPRICE *10 < IN_TOTALPRICE then
               SELECT   dbms_random.value(5, 10) into V_NUMBER FROM dual;
   elsif V_ENDPRICE + V_MAXPRODUCTPRICE *6 < IN_TOTALPRICE then
               SELECT   dbms_random.value(5, 6) into V_NUMBER FROM dual;

     elsif V_ENDPRICE + V_MAXPRODUCTPRICE *5 < IN_TOTALPRICE then
                SELECT productplayid, price into   V_PRODUCTPLAYID,V_PRODUCTPRICE
                FROM (select t.productplayid, t.price
                from t_productplay t
               where t.productid = IN_PRODUCTID
               and price>16 ORDER BY  price desc)
       WHERE ROWNUM < 2;
               SELECT   dbms_random.value(4, 5) into V_NUMBER FROM dual;
     elsif V_ENDPRICE + V_MAXPRODUCTPRICE *4 < IN_TOTALPRICE then
               SELECT productplayid, price into   V_PRODUCTPLAYID,V_PRODUCTPRICE
                FROM (select t.productplayid, t.price
                from t_productplay t
               where t.productid = IN_PRODUCTID
               and price>16 ORDER BY  price desc)
       WHERE ROWNUM < 2;
               SELECT   dbms_random.value(3, 4) into V_NUMBER FROM dual;
       elsif V_ENDPRICE + V_MAXPRODUCTPRICE *3 < IN_TOTALPRICE then
               SELECT productplayid, price into   V_PRODUCTPLAYID,V_PRODUCTPRICE
                FROM (select t.productplayid, t.price
                from t_productplay t
               where t.productid = IN_PRODUCTID
               and price>16 ORDER BY  price desc)
       WHERE ROWNUM < 2;
               SELECT   dbms_random.value(2, 3) into V_NUMBER FROM dual;

   elsif V_ENDPRICE + V_MINPRODUCTPRICE *6 < IN_TOTALPRICE then
               SELECT productplayid, price into   V_PRODUCTPLAYID,V_PRODUCTPRICE
                FROM (select t.productplayid, t.price
                from t_productplay t
               where t.productid = IN_PRODUCTID
               and price>16 ORDER BY  price asc)
       WHERE ROWNUM < 2;
               SELECT   dbms_random.value(5, 6) into V_NUMBER FROM dual;


       elsif V_ENDPRICE + V_MINPRODUCTPRICE *5 < IN_TOTALPRICE then
               SELECT productplayid, price into   V_PRODUCTPLAYID,V_PRODUCTPRICE
                FROM (select t.productplayid, t.price
                from t_productplay t
               where t.productid = IN_PRODUCTID
               and price>16 ORDER BY  price asc)
       WHERE ROWNUM < 2;
               SELECT   dbms_random.value(4, 5) into V_NUMBER FROM dual;

       elsif V_ENDPRICE + V_MINPRODUCTPRICE *4 < IN_TOTALPRICE then
               SELECT productplayid, price into   V_PRODUCTPLAYID,V_PRODUCTPRICE
                FROM (select t.productplayid, t.price
                from t_productplay t
               where t.productid = IN_PRODUCTID
               and price>16 ORDER BY  price asc)
       WHERE ROWNUM < 2;
               SELECT   dbms_random.value(3, 4) into V_NUMBER FROM dual;

       elsif V_ENDPRICE + V_MINPRODUCTPRICE *3 < IN_TOTALPRICE then
               SELECT productplayid, price into   V_PRODUCTPLAYID,V_PRODUCTPRICE
                FROM (select t.productplayid, t.price
                from t_productplay t
               where t.productid = IN_PRODUCTID
               and price>16 ORDER BY  price asc)
       WHERE ROWNUM < 2;
               SELECT   dbms_random.value(2, 3) into V_NUMBER FROM dual;
      elsif  V_ENDPRICE + V_MINPRODUCTPRICE *2 < IN_TOTALPRICE then
                SELECT productplayid, price into   V_PRODUCTPLAYID,V_PRODUCTPRICE
                FROM (select t.productplayid, t.price
                from t_productplay t
               where t.productid = IN_PRODUCTID  and price>16
               ORDER BY  price asc)
       WHERE ROWNUM < 2;
               SELECT  dbms_random.value(1, 2)  into V_NUMBER FROM dual;

      elsif  V_ENDPRICE + V_MINPRODUCTPRICE *1 < IN_TOTALPRICE then
                SELECT productplayid, price into   V_PRODUCTPLAYID,V_PRODUCTPRICE
                FROM (select t.productplayid, t.price
                from t_productplay t
               where t.productid = IN_PRODUCTID  and price>16
               ORDER BY  price asc)
       WHERE ROWNUM < 2;
               SELECT  1  into V_NUMBER FROM dual;
      else
        exit;
     end if;



        --获取收获地址信息


if   in_customersid=0 or in_customersid=1 then
          select   CUSTOMERSID into V_CUSTOMERSID from vt_cw_customers_pd where nextval=round (dbms_random.value(1,164),0) ;
          select 1   into  V_ADDRESS_TYPE from dual;
          select 000000    into    V_ADDRESS_ZIP from dual;
          select '1' into      V_ADDRESS_PHONE from dual;
          select '1' into      V_ADDRESS_PROVINCEID from dual;
          select '1' into      V_ADDRESS_CITYID from dual;
          select '1' into      V_ADDRESS_AREAID  from dual;
          select '1' into      V_ADDRESS_CODEID  from dual;


else
          select in_customersid  into V_CUSTOMERSID from dual;
          select 1   into  V_ADDRESS_TYPE from dual;
          select 000000    into    V_ADDRESS_ZIP from dual;
          select '1' into      V_ADDRESS_PHONE from dual;
          select '1' into      V_ADDRESS_PROVINCEID from dual;
          select '1' into      V_ADDRESS_CITYID from dual;
          select '1' into      V_ADDRESS_AREAID  from dual;
          select '1' into      V_ADDRESS_CODEID  from dual;

end if;






        --获取收货地址及收货人姓名
 --       select addressname, username
 --         into V_ADDRESS_NAME, V_ADDRESS_USERNAME
 --         from (select a.name as addressname, a.username
---                  from t_address a
 --                where a.customersid between 425257 and 891498
 --                ORDER BY dbms_random.value())
 --        where rownum < 2;
           select ' ', ' '
          into V_ADDRESS_NAME, V_ADDRESS_USERNAME FROM DUAL;


        --计算订单总金额
        V_ORDERS_TOTALPRICE := (V_PRODUCTPRICE * V_NUMBER);

        --地址表主键ID
        select seq_address.nextval into V_ADDRESSID from dual;
        --插入地址
        insert into t_address
          (ADDRESSID,
           CUSTOMERSID,
           NAME,
           TYPE,
           ZIP,
           USERNAME,
           PHONE,
           TEL,
           ORDERS,
           REMARK,
           STATUS,
           CREATETIME,
           LASTTIME,
           LASTUSER,
           AREAID,
           CITYID,
           CODEID,
           PROVINCEID,
           DZPHONE,
           EMAIL,
           DELIVERY)
        values
          (V_ADDRESSID,
           V_CUSTOMERSID,
           V_ADDRESS_NAME,
           V_ADDRESS_TYPE,
           V_ADDRESS_ZIP,
           V_ADDRESS_USERNAME,
           V_ADDRESS_PHONE,
           null,
           null,
           null,
           0,
           V_CREATETIME,
           V_CREATETIME,
            'order_auto',
           V_ADDRESS_AREAID,
           V_ADDRESS_CITYID,
           V_ADDRESS_CODEID,
           V_ADDRESS_PROVINCEID,
           null,
           null,
           null);

        --生成订单ID
        if to_char(IN_ORDER_DATE,'yyyymmdd')='20080101'
          then
               select   get_oid(to_char(v_createtime,'yyyymmdd'),0)  into V_ORDERSID from dual;
        else
              select   get_oid(to_char(IN_ORDER_DATE,'yyyymmdd'),0)  into V_ORDERSID from dual;
       end if;
        --创建订单
        insert into t_orders
          (ORDERSID,
           CUSTOMERSID,
           ADDRESSID,
           CLIENTINFO,
           COMPANYINFO,
           RANGEPRICE,
           LNVOICE,
           PSXX,
           APPEND,
           URGENTPRICE,
           SHSMDATE,
           YTOTAL,
           ZTOTAL,
           STARUS,
           ERRSTARUS,
           ZPRODUCTZPIDS,
           FPRODUCTFJPIDS,
           TYPE,
           PROTYPE,
           PROIDS,
           EXPRESSCOSTID,
           EXPRESSNO,
           PRINT,
           PRINTTIME,

           PRINTUSER,
           DELIVERYUSER,
           DELIVERYDATE,
           IP,
           CREATETIME,
           LASTTIME,
           LASTUSER,
           RANGEPINFO,
           ORDERSOURCE,
           GIFTID,
           TICKET,
           REFUNDS,
           WAREHOUSEDATE,
           TEXT,
           EXPRESSNAME,
           INTEGRAL,
           LPIDS,
           LPNUM,
           ZPNUM,
           FJPNUM,
           BACKMONEYDATE,
           backmoneystatus,
           WRITECHECKDATE,
           WRITECHECK,
           ISEND,
           FCONFIGID,
           ISMODIF,
           CHANGEMONEY,
           OLDORDERSID,
           ISCHANGEMONEY,
           WRITECHECKCODE,
           ISTEAMWORK,
           TXTONE,
           ISPWQTBACKMONEY,
           UNIONID,
           PROCESSINGSTARUS,
           CLEARREMARK,
           LPCARDID,
           ONLINE_SCREENINGINFO,
           ONLINE_ORDERSID,
           ONLINE_SENDTAG,
           UNIONORDERSID,
           CHANGEMONEYINFO,
           FINANCEINFO,
           FPPRICE,
           CREATEUSER,
           WRITECHECKINFO,
           ISDISCOUNTRESET,
           ISADDWRITECHECK,
           PRINTCOUNT,
           DZPHONE,
           ISPWQTDEALWITH,
           ISSGP,
           COMMISSION,
           INSUREDPUSHSTATUS,
           WRITECHECKPOSTDATE,
           CLAIMUSER,
           CLAIMTIME,
           INSUREDSTATUS,
           QZNUM,
           HDFK_PAYMENTTYPE,
           INTEGRALNEW,
           MULTIPLE,
           VERIFYTIME,
           ISENDUSER,
           ISENDTIME,
           CHANGEMONEYDATE,
           CHANGEMONEYENDDATE,
           ISWAITINGFORPAY,
           DZTYPE,
           VERIFYUSER,
           MATCHINGTIME,
           MATCHINGUSER,
           ISKGDEALWITH,
           WAREHOUSEDATEUPDATENUM,
           CANCLEREASON,
           RECEIPTTYPE,
           CANCLETIME,
           SPREADSOURCE,
           SETTLEMENTSTATUS,
           SETTLEMENTDATE,
           SETTLEMENTUSER,
           ORDERSSETTLEMENTSTATUS,
           SWEEPTIME,
           ISLIMIT,
           EQUIPMENTSYSTEM,
           ISMODIFTIME,
           ISMODIFUSER,
           LANGUAGES,
           ISREFUNDROAD,
           PAYTYPEINFO,
           CWERRORLASTUSER,
           BATCH)
        values
          (V_ORDERSID,
           V_CUSTOMERSID,
            case IN_PAYTYPE   when 4 then 0  when 3 then 0    else V_ADDRESSID end,
           null,
           null,
           0,
           null,
           case IN_PAYTYPE   when 4 then 2 when 3 then 2    else 1 end ,
           0,
           0,
           1,
           V_ORDERS_TOTALPRICE,
           V_ORDERS_TOTALPRICE,
           10,
           0,
          '', -- V_BATCH
           null,
           0,
           2,
           IN_PRODUCTID,
           null,
           null,
           1,
          get_date_add_tl(V_CREATETIME,0,dbms_random.value(32400, 65600)), --打印四联单时间,随机5分钟
            'order_auto',
            'order_auto',
          get_date_add_tl(V_CREATETIME,0,round(dbms_random.value(3600, 10800))),   --发货时间
           null,
           V_CREATETIME,
               get_date_add_tl(V_CREATETIME,0,round(dbms_random.value(3600, 10800))),   --最后修改时间
           'order_auto',
           null,
         --  case IN_PAYTYPE   when 4 then 3  when 3 then 4    else V_ORDERSOURCE end,
         V_ORDERSOURCE,
           null,
           0,
           null,
          get_date_add_tl(V_CREATETIME,0,round(dbms_random.value(3600, 10800))),   --发货时间
           null,
           null,
           0,
           null,
           null,
           null,
           null,
           get_date_add_tl(V_CREATETIME,
                           0,
                          dbms_random.value(2000, 65600)), --回款时间
           1,
           null,
           0,
           0,
           V_FCONFIGID,
           0,
           null,
           null,
           null,
           null,
           0,
           null,
           null,
           null,
           null,
           null,
           null,
           null,
           null,
           null,
           null,
           null,
           null,
           null,
           'order_auto',
           null,
           null,
           0,
           1,
           null,
           0,
           0,
           null,
           0,
           null,
            'order_auto',
           get_date_add_tl(V_CREATETIME, 0,  dbms_random.value(2400, 65600)), --认领时间
           0,
           null,
           null,
           0,
           1.0000,
           null,
           null,
           null,
           null,
           null,
           null,
           -1,
           'order_auto',
               get_date_add_tl(V_CREATETIME,0,dbms_random.value(3600, 10800)),   --配票时间
           'order_auto',
           0,
           0,
           null,
           null,
           null,
           null,
           0,
           null,
           null,
           null,
           null,
           0,
           null,
           get_date_add_tl(V_CREATETIME, 1, round(dbms_random.value(3600, 10800))), --终止修改时间
            'order_auto',
           null,
           null,
           null,
           null,
           V_BATCH);

        --创建订单明细
    --     select   get_oid(to_char(IN_ORDER_DATE,'yyyymmdd'),1)  into V_ordersdetailid from dual;

        if to_char(IN_ORDER_DATE,'yyyymmdd')='20080101'
        then
               select   get_oid(to_char(v_createtime,'yyyymmdd'),1)  into V_ordersdetailid from dual;
        else
              select   get_oid(to_char(IN_ORDER_DATE,'yyyymmdd'),1)  into V_ordersdetailid from dual;
       end if;

        insert into t_ordersdetail
          (ORDERSDETAILID,
           ORDERSID,
           PRODUCTPLAYID,
           PRICE,
           NUM,
           TOTAL,
           GIFTID,
           TICKET,
           HOSTDISCOUNT,
           INTEGRAL,
           SEAT,
           SYSTEM,
           CREATETIME,
           LASTTIME,
           LASTUSER,
           DISCOUNTDETAILID,
           PAPERNUMBER,
           DISCOUNT,
           DISCOUNTDETAILIDORGANIZER,
           DISCOUNTDETAILIDTEAMWORK,
           YTOTAL,
           CUSTOMERDISCOUNT,
           INSUREDSTATUS,
           INSUREDTOTAL,
           SETTLEMENTSTATUS,
           INTEGRALMULTIPLE,
           YLTOUSERDISCOUNT,
           JSDISCOUNT)
        values
          (V_ordersdetailid,
           V_ORDERSID,
           V_PRODUCTPLAYID,
           V_PRODUCTPRICE,
           V_NUMBER,
           V_ORDERS_TOTALPRICE,
           null,
           null,
           100,
           V_ORDERS_TOTALPRICE,
           null,
           70150,
           V_CREATETIME,
           get_date_add_tl(V_CREATETIME,
                           0,
                           round(dbms_random.value(400, 65600))),
           'order_auto',
           70100,
           null,
           null,
           3688000,
           null,
           V_ORDERS_TOTALPRICE,
           100,
           0,
           0,
           0,
           1,
           null,
           null);

        --第三方支付时间
        select get_date_add_tl(V_CREATETIME,
                               0,
                               round(dbms_random.value(10, 900)))
          into V_PAYDATE
          from dual;

        --第三方支付ID
        --支付宝支付ID
        if IN_PAYTYPE = 1 then
          select to_char(V_PAYDATE, 'yyyymmddhh24miss') ||
                 substr(cast(dbms_random.value as varchar2(38)), 3, 14)
            into V_PAYID
            from dual;
        end if;
        --乐通卡支付ID
        if IN_PAYTYPE = 2 then
          select substr(cast(dbms_random.value as varchar2(38)), 3, 8)
            into V_PAYID
            from dual;
        end if;

        --创建支付表  注:乐通卡字段那里未添加,待修改
    select seq_a.nextval into v_paymentid from dual;
        insert into t_payment
          (PAYMENTID,
           RMIDS,
           YSIDS,
           LJPRICE,
           YCKPRICE,
           LPKPRICE,
           SJZFPRICE,
           ZPRICE,
           PAYSTATUS,
           CREATETIME,
           LASTTIME,
           LASTUSER,
           ORDERSID,
           REMARK,
           DISCOUNTDETAILID,
           DISCOUNT,
           REFUNDS,
           REFUNDTIME,
           DEALTIME,
           OLDDISCOUNT,
           OLDSJZFPRICE,
           YSPRICE,
           OLDDISCOUNTDETAILID,
           REFUNPRICE,
           LTKPRICE,
           PAYCARDID,
           PAYCARDTYPE,
           PAYTELLOKTIME,
           DISCOUNTPAY,
           INSUREDAMOUNT,
           LPKCODEID,
           CHECKNO,
           CHECKCOMPANYNAME,
           PAYSUCCESSFULTIME,
           nzprice,
           isselect)
        values
          (v_paymentid,
           IN_PRODUCTID,
           null,
           0.000,
           0.000,
           0.000,
           V_ORDERS_TOTALPRICE,
           V_ORDERS_TOTALPRICE,
           2,
           V_CREATETIME,
           get_date_add_tl(V_CREATETIME,
                           0,
                           round(dbms_random.value(30, 90))),
           'payuser_auto',
           V_ORDERSID,
           null,
           IN_DISCOUNTDETAILID,
           IN_DISCOUNTID,
           0,
           null,
           V_PAYID,
           null,
           0.000,
           V_ORDERS_TOTALPRICE,
           null,
           0,
           case IN_PAYTYPE when 2 then V_ORDERS_TOTALPRICE else 0.000 end, --乐通卡
           case IN_PAYTYPE when 2 then
           '228' || substr(cast(dbms_random.value as varchar2(38)), 3, 13) else null end, --乐通卡
           case IN_PAYTYPE when 2 then 2 else null end, --乐通卡
           case IN_PAYTYPE when 1 then V_PAYDATE else null end,
           100,
           0,
           null,
           null,
           null,
            V_PAYDATE ,
           V_ORDERS_TOTALPRICE,
           '1');

    select seq_a.nextval into v_id from dual;

      insert into t_payment_detail
      (ID,
      PAYMENT_ID,
      ORDER_ID,
      ORIGINAL_FEE,
      ACTUAL_FEE,
      DISCOUNT,
      DISCOUNTDETAILID,
      PAYMENT_STATUS,
      TRADE_CREATE_TIME,
      TRADE_FINISH_TIME,
      THIRD_TRADE_NO,
      GMT_CREATE,
      DISCOUNTVALUE,
      LAST_TIME,
      LAST_USERS,
       ERROR_URL,
      REQUEST_CHANNEL,
      REQUEST_SOURCE,
      REQUEST_PARTNER,
      CARDNO,
      ORIGINAL_DISCOUNT_FEE,
      PAY_DISCOUNT_FEE)
    values
      (v_id,
      v_paymentid,
      V_ORDERSID,
      V_ORDERS_TOTALPRICE,
      V_ORDERS_TOTALPRICE,
      IN_DISCOUNTID,
      IN_DISCOUNTDETAILID,
      1,
      get_date_add_tl(V_CREATETIME,0,round(dbms_random.value(200, 2600))),
      V_PAYDATE,
      V_PAYID,
      V_CREATETIME,
      100,
      get_date_add_tl(V_CREATETIME,0,round(dbms_random.value(200, 2600))),
      'AUTO',
      'http://api.228.cn/alipay/pay_notify',
       case V_ORDERSOURCE   when 2 then 'web'  when 70 then 'IOS'   when 80 then 'ANDROID'   when 90 then 'WAP' else null end,
       case V_ORDERSOURCE   when 2 then 'web'  when 70 then 'IOS'  when 80 then 'ANDROID'   when 90 then 'WAP' else null end,
       case IN_PAYTYPE when 1 then 'alipay' when 2 then 'letong'  when 3 then 'shexiao' when 4 then 'cash' else null end ,
        case IN_PAYTYPE when 2 then '228' || substr(cast(dbms_random.value as varchar2(38)), 3, 13) else null end, --乐通卡
        V_ORDERS_TOTALPRICE,
       0);



        --提交
        commit;
        --回滚测试数据
        --rollback;
        V_ENDPRICE := V_ENDPRICE + V_ORDERS_TOTALPRICE;
        --dbms_output.put_line('ordersID:' || V_ORDERSID);

        --退出条件,当插入金额大于或等于指定金额时退出
        dbms_output.put_line('IN_PAYTYPE:'||IN_PAYTYPE );
        dbms_output.put_line('IN_DISCOUNTID:'|| IN_DISCOUNTID );
                dbms_output.put_line('-------------------SHEXIAO-----'|| IN_DISCOUNTID );

        dbms_output.put_line('IN_DISCOUNTDETAILID:'|| IN_DISCOUNTDETAILID );


          exit when V_ENDPRICE +V_MINPRODUCTPRICE>= IN_TOTALPRICE;
      end loop;
      dbms_output.put_line(to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss'));
----------------------------------------------------赊销---------------------------------------------------------------------------------------

    end if;
  end YL_ORDER_INSERT;
end YL_AUTO_ORDER;

/

