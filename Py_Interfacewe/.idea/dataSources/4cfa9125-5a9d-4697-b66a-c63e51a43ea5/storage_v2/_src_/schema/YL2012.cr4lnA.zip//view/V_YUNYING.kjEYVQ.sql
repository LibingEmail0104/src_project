create view V_YUNYING as
select  ta.typea 类型,ta.cityname 城市,ta.pname 演出, decode(ta.order_source,'网络',case when  推广 in ('微信') OR 联盟名称 IN ( '微信')                 then '微信'
                                                   when   upper(联盟名称) like '%DSP%' or upper(推广) like  '%DSP%' then 'DSP'
                                                   when   upper(联盟名称) like '%CPS%' or upper(推广) like  '%CPS%' then 'CPS'
                                                   when   联盟名称        like  '%粉丝通%'                           then   '粉丝通'
                                                   when    推广='百度音乐'                                           then   '联盟'
                                                    when    推广='拜仁同仁会'                                         then   '团购'
                                                   when  联盟名称='彩贝'                                             then    'CPS'
                                                   when  推广 in ('360','Google','百度','百度移动','国家大剧院','搜狗') then '网站_SEM'
                                                   else  '网站_平台' end ,
                                         'WAP',case when   upper(联盟名称) like '%DSP%' or upper(推广) like  '%DSP%' then 'DSP'
                                                    when   upper(联盟名称) like '%CPS%' or upper(推广) like  '%CPS%' then 'CPS'
                                                    when  联盟名称='彩贝'                                             then    'CPS'
                                                    when  推广 in ('360','Google','百度','百度移动','国家大剧院','搜狗') then 'WAP_SEM'
                                                    when   联盟名称        like  '%粉丝通%'                            then   '粉丝通'
                                                    when    推广='拜仁同仁会'                                          then   '团购'
                                                    when  推广 in ('微信') OR 联盟名称 IN ( '微信')                    then '微信'
                                                     else  'WAP_平台' end ，
                                         '联盟',case when  upper(联盟名称) like '%CPS%' or upper(推广) like  '%CPS%'        then 'CPS'
                                                     when  联盟名称='彩贝'                                                  then    'CPS'
                                                     when   upper(联盟名称) like '%DSP%' or upper(推广) like  '%DSP%'       then 'DSP'
                                                     when  推广 in ('360','Google','百度','百度移动','国家大剧院','搜狗')   then 'SEM'
                                                     when   联盟名称        like  '%粉丝通%'                                then   '粉丝通'
                                                     when  推广 in ('360','Google','百度','百度移动','国家大剧院','搜狗')    then '网站_SEM'
                                                     when   推广 in ('安演','百度登录','人人登录','腾讯(套)','腾讯登录','微信登录','武汉演出网','新浪微博登录') then  '网站_平台'
                                                     when  推广 in ('微信') OR 联盟名称 IN ( '微信')                         then '微信'
                                                     else  '联盟' end,
                                  '票点前台用户', '票务前台',
                                  '票务前台票点','票点',
                                  'IOS','APP-iOS',
                                  'ANDROID','APP-安卓',
                                  '电话','电话'
                                  ) 来源,
                sum(ta.TOTAL) 金额,sum(ta.NUM) 数量,to_char(sysdate-1,'yyyymmdd') mdate
         from  v_zorder_product ta where to_char(mtime,'yyyymmdd')=to_char(sysdate-1,'yyyymmdd') and (ta.starus in ('已审核','配票中','发货中','已发货','已完成','审核至前台') or ta.paystatus='已支付' or ta.role='货到付款')
 group by
         ta.typea,ta.cityname,ta.pname,decode(ta.order_source,'网络',case when  推广 in ('微信') OR 联盟名称 IN ( '微信')                 then '微信'
                                                   when   upper(联盟名称) like '%DSP%' or upper(推广) like  '%DSP%' then 'DSP'
                                                   when   upper(联盟名称) like '%CPS%' or upper(推广) like  '%CPS%' then 'CPS'
                                                   when   联盟名称        like  '%粉丝通%'                           then   '粉丝通'
                                                   when    推广='百度音乐'                                           then   '联盟'
                                                    when    推广='拜仁同仁会'                                         then   '团购'
                                                   when  联盟名称='彩贝'                                             then    'CPS'
                                                   when  推广 in ('360','Google','百度','百度移动','国家大剧院','搜狗') then '网站_SEM'
                                                   else  '网站_平台' end ,
                                         'WAP',case when   upper(联盟名称) like '%DSP%' or upper(推广) like  '%DSP%' then 'DSP'
                                                    when   upper(联盟名称) like '%CPS%' or upper(推广) like  '%CPS%' then 'CPS'
                                                    when  联盟名称='彩贝'                                             then    'CPS'
                                                    when  推广 in ('360','Google','百度','百度移动','国家大剧院','搜狗') then 'WAP_SEM'
                                                    when   联盟名称        like  '%粉丝通%'                            then   '粉丝通'
                                                    when    推广='拜仁同仁会'                                          then   '团购'
                                                    when  推广 in ('微信') OR 联盟名称 IN ( '微信')                    then '微信'
                                                     else  'WAP_平台' end ，
                                         '联盟',case when  upper(联盟名称) like '%CPS%' or upper(推广) like  '%CPS%'        then 'CPS'
                                                     when  联盟名称='彩贝'                                                  then    'CPS'
                                                     when   upper(联盟名称) like '%DSP%' or upper(推广) like  '%DSP%'       then 'DSP'
                                                     when  推广 in ('360','Google','百度','百度移动','国家大剧院','搜狗')   then 'SEM'
                                                     when   联盟名称        like  '%粉丝通%'                                then   '粉丝通'
                                                     when  推广 in ('360','Google','百度','百度移动','国家大剧院','搜狗')    then '网站_SEM'
                                                     when   推广 in ('安演','百度登录','人人登录','腾讯(套)','腾讯登录','微信登录','武汉演出网','新浪微博登录') then  '网站_平台'
                                                     when  推广 in ('微信') OR 联盟名称 IN ( '微信')                         then '微信'
                                                     else  '联盟' end,
                                  '票点前台用户', '票务前台',
                                  '票务前台票点','票点',
                                  'IOS','APP-iOS',
                                  'ANDROID','APP-安卓',
                                  '电话','电话'
                                  ),to_char(sysdate-1,'yyyymmdd')   order by 1,2

 
/

