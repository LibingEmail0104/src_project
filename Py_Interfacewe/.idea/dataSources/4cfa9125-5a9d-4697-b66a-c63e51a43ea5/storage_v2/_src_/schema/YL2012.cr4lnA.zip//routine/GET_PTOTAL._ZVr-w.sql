CREATE FUNCTION get_ptotal(p_ordersid  number,
                                      p_mdiscount varchar2,
                                      p_by        number) return number is
  v_bytotal number(20,2);
begin
  select (select t.actual_fee
            from v_by_fei t
           where t.order_id = p_ordersid
             and t.mdiscount = p_mdiscount and t.actual_fee is not null
              and t.mdiscount not in ('66985008','101159715')) /
         (select sum(t.actual_fee)
            from v_by_fei t
           where t.order_id = p_ordersid and t.actual_fee is not null and t.actual_fee!=0 and t.mdiscount not in ('66985008','101159715')) * p_by
    into v_bytotal
    from dual;
  return v_bytotal;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    return '0.00';
end;

/

