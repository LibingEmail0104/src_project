CREATE VIEW V_ZPRODUCT_PAY AS
  select sum(t.total) TOTAL, t.productid, t.paystatus, t.starus, tb.mhost
  from v_zorder_product t,
       (select t.ordersid, max(t.logtime) logtime
          from log_t_payment t
         group by t.ordersid) ta,
       log_t_payment tb
 where t.ordersid = ta.ordersid
   and ta.ordersid = tb.ordersid
   and ta.logtime = tb.logtime
   and to_char(t.mtime,'yyyymmdd')=to_char(sysdate,'yyyymmdd')
 group by t.productid, t.paystatus, mhost, starus


/

