CREATE VIEW V_PAY AS
  select p.ordersid,d.role,dd.rank from t_payment p, T_DISCOUNT d,t_discountdetail dd where p.discount=d.discountid and p.discountdetailid=dd.discountdetailid(+)


/

