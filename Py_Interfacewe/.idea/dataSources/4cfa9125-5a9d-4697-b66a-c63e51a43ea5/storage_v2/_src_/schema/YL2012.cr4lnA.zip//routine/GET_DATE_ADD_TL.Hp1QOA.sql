CREATE function get_date_add_tl(in_date        date, --时间
                                           in_char_hour   number, --要加的天
                                           in_char_minute number --要加的秒
                                           ) return date is
  v_date date;
begin
  select in_date + in_char_hour + (in_char_minute / (24 * 60*60))
    into v_date
    from dual;
  return v_date;
end get_date_add_tl;

/

