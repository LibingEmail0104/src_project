CREATE FUNCTION GET_Productid (odid number)
  return number is
  v_Productid varchar2(50);
begin
  select tp.productid
    into v_Productid
    from T_PRODUCT tp,T_PRODUCTPLAY tpa,T_ORDERSDETAIL tod
   where   tod.productplayid=tpa.productplayid
   and tpa.productid=tp.productid
   and tod.ordersdetailid=odid;
  return v_Productid;
exception
  when no_data_found then
    return '0' || v_Productid;
  when others then
    return '0' || v_Productid;
end;



/

