CREATE TYPE          "SPLIT_TYPE"                                          IS TABLE OF VARCHAR2 (4000)
CREATE OR REPLACE FUNCTION split (
    p_str       IN VARCHAR2,
    p_delimiter IN VARCHAR2 default(',') --????????
)
    RETURN split_type
IS
    j INT := 0
  /

