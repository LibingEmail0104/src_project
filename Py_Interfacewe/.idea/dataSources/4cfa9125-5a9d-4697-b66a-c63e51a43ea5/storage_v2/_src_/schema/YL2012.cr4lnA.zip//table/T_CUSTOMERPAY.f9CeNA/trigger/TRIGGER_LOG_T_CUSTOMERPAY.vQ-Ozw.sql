CREATE TRIGGER TRIGGER_LOG_T_CUSTOMERPAY
  AFTER UPDATE
  ON T_CUSTOMERPAY
  FOR EACH ROW
  begin
  insert into log_t_customerpay
    (customerpayid,
     orderid,
     transferid,
     ylbankname,
     username,
     openbuck,
     zpirce,
     sequencesid,
     info,
     customerphone,
     customertransferid,
     transferdate,
     createtime,
     lasttime,
     lastuser,
     payok,
     payadmin,
     methodremittance,
     remittance,
     payremittance,
     trading,
     status,
     lastcommituser,
     lastcommittime,
     lastverifyuser,
     lastverifytime,
     logtime)
  values
    (:old.CUSTOMERPAYID,
     :old.ORDERID,
     :old.TRANSFERID,
     :old.YLBANKNAME,
     :old.USERNAME,
     :old.OPENBUCK,
     :old.ZPIRCE,
     :old.SEQUENCESID,
     :old.INFO,
     :old.CUSTOMERPHONE,
     :old.CUSTOMERTRANSFERID,
     :old.TRANSFERDATE,
     :old.CREATETIME,
     :old.LASTTIME,
     :old.LASTUSER,
     :old.PAYOK,
     :old.PAYADMIN,
     :old.METHODREMITTANCE,
     :old.REMITTANCE,
     :old.PAYREMITTANCE,
     :old.TRADING,
     :old.STATUS,
     :old.LASTCOMMITUSER,
     :old.LASTCOMMITTIME,
     :old.LASTVERIFYUSER,
     :old.LASTVERIFYTIME,
     sysdate);
end;


/

