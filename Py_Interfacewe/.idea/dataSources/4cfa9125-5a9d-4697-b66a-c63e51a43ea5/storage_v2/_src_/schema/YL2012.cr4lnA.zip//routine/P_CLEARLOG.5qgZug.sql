CREATE PROCEDURE "P_CLEARLOG" (num number) as
begin
  delete LOG_ORDERCASCADEALL t where t.logtime < sysdate - 365;
  delete LOG_T_ADDRESS t where t.logtime < sysdate - 365;
  delete LOG_T_ADDRESSCUSTOMERS t where t.logtime < sysdate - 365;
  delete LOG_T_CUSTOMERPAY t where t.logtime < sysdate - 365;
  delete LOG_T_CUSTOMERS t where t.logtime < sysdate - 365;
  delete LOG_T_CUSTOMERSYCKLOG t where t.logtime < sysdate - 365;
  delete LOG_T_DISCOUNT t where t.logtime < sysdate - 365;
  delete LOG_T_DISCOUNTDETAIL t where t.logtime < sysdate - 365;
  delete LOG_T_FCONFIG t where t.logtime < sysdate - 365;
  delete LOG_T_HOSTDISCOUNT t where t.logtime < sysdate - 365;
  delete LOG_T_ORDERANOMALY t where t.logtime < sysdate - 365;
  delete LOG_T_ORDERS t where t.logtime < sysdate - 365;
  delete LOG_T_ORDERSDETAIL t where t.logtime < sysdate - 365;
  delete LOG_T_PAYMENT t where t.logtime < sysdate - 365;
  delete LOG_T_PROCEDUREPRICE t where t.logtime < sysdate - 365;
  delete LOG_T_PRODUCT t where t.logtime < sysdate - 365;
  delete LOG_T_PRODUCTPLAY t where t.logtime < sysdate - 365;
  delete LOG_T_VENUES t where t.logtime < sysdate - 365;
  delete t_unioncode t where t.createtime < sysdate - 10;
  dbms_output.put_line(num);
  commit;
end;


/

