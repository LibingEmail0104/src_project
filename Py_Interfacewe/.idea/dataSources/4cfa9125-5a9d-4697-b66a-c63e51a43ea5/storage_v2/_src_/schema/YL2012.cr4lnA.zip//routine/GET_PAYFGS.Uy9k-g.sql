CREATE function get_payfgs(v_ordersdetailid number)
 return varchar is
 v_fgs varchar2(80);
 begin
select case when  get_fcname(p.fconfigid)='乌鲁木齐市' and  (decode(dis.discountid,70054,o.createtime,70057,o.createtime,2341200,o.createtime,70049,o.deliverydate,70053,o.ismodiftime,pm.paysuccessfultime)  between to_date('20140101','yyyymmdd') and to_date('20141231','yyyymmdd')  ) then  '北京分公司'
						when  get_fcname(p.fconfigid)='哈尔滨市' and  (decode(dis.discountid,70054,o.createtime,70057,o.createtime,2341200,o.createtime,70049,o.deliverydate,70053,o.ismodiftime,pm.paysuccessfultime)  between  to_date('20110101','yyyymmdd') and to_date('20141231','yyyymmdd')  ) then  '北京分公司'
						when  get_fcname(p.fconfigid)='宁波市' and  (decode(dis.discountid,70054,o.createtime,70057,o.createtime,2341200,o.createtime,70049,o.deliverydate,70053,o.ismodiftime,pm.paysuccessfultime)  between  to_date('20110101','yyyymmdd') and to_date('20141231','yyyymmdd')  ) then  '北京分公司'
						when  get_fcname(p.fconfigid)='营口市' and  (decode(dis.discountid,70054,o.createtime,70057,o.createtime,2341200,o.createtime,70049,o.deliverydate,70053,o.ismodiftime,pm.paysuccessfultime)  between  to_date('20110101','yyyymmdd') and to_date('20141231','yyyymmdd')  ) then  '北京分公司'
--广州
						when  get_fcname(p.fconfigid)='福州市' and  (decode(dis.discountid,70054,o.createtime,70057,o.createtime,2341200,o.createtime,70049,o.deliverydate,70053,o.ismodiftime,pm.paysuccessfultime)  between  to_date('20110101','yyyymmdd') and to_date('20130831','yyyymmdd')  ) then  '广州分公司'
--合肥
						when  get_fcname(p.fconfigid)='宁波市' and  (decode(dis.discountid,70054,o.createtime,70057,o.createtime,2341200,o.createtime,70049,o.deliverydate,70053,o.ismodiftime,pm.paysuccessfultime) >= to_date('20150101','yyyymmdd')  ) then  '合肥分公司'
						when  get_fcname(p.fconfigid)='镇江市' and  (decode(dis.discountid,70054,o.createtime,70057,o.createtime,2341200,o.createtime,70049,o.deliverydate,70053,o.ismodiftime,pm.paysuccessfultime)  between  to_date('20150401','yyyymmdd') and to_date('20150431','yyyymmdd')  ) then  '合肥分公司'
--南京
						when  get_fcname(p.fconfigid)='镇江市' and  (decode(dis.discountid,70054,o.createtime,70057,o.createtime,2341200,o.createtime,70049,o.deliverydate,70053,o.ismodiftime,pm.paysuccessfultime) not  between  to_date('20150401','yyyymmdd') and to_date('20150431','yyyymmdd')  ) then  '南京分公司'
--天津
						when  get_fcname(p.fconfigid)='太原市' and  (decode(dis.discountid,70054,o.createtime,70057,o.createtime,2341200,o.createtime,70049,o.deliverydate,70053,o.ismodiftime,pm.paysuccessfultime) >=  to_date('20130901','yyyymmdd')   ) then  '天津分公司'
            when  get_fcname(p.fconfigid)='新乡市' and  (decode(dis.discountid,70054,o.createtime,70057,o.createtime,2341200,o.createtime,70049,o.deliverydate,70053,o.ismodiftime,pm.paysuccessfultime) >=  to_date('20130901','yyyymmdd')   ) then  '天津分公司'
            when  get_fcname(p.fconfigid)='郑州市' and  (decode(dis.discountid,70054,o.createtime,70057,o.createtime,2341200,o.createtime,70049,o.deliverydate,70053,o.ismodiftime,pm.paysuccessfultime) >= to_date('20130901','yyyymmdd')   ) then  '天津分公司'
						when  get_fcname(p.fconfigid)='洛阳市' and  (decode(dis.discountid,70054,o.createtime,70057,o.createtime,2341200,o.createtime,70049,o.deliverydate,70053,o.ismodiftime,pm.paysuccessfultime) >=  to_date('20130901','yyyymmdd')   ) then  '天津分公司'
--重庆
            when  get_fcname(p.fconfigid)='乌鲁木齐市' and  (decode(dis.discountid,70054,o.createtime,70057,o.createtime,2341200,o.createtime,70049,o.deliverydate,70053,o.ismodiftime,pm.paysuccessfultime)  between to_date('20130101','yyyymmdd') and to_date('20131231','yyyymmdd')  ) then  '重庆分公司'

--大连
						when  get_fcname(p.fconfigid)='哈尔滨市' and  (decode(dis.discountid,70054,o.createtime,70057,o.createtime,2341200,o.createtime,70049,o.deliverydate,70053,o.ismodiftime,pm.paysuccessfultime) >=  to_date('20150101','yyyymmdd')   ) then  '天津分公司'
						when  get_fcname(p.fconfigid)='营口市' and  (decode(dis.discountid,70054,o.createtime,70057,o.createtime,2341200,o.createtime,70049,o.deliverydate,70053,o.ismodiftime,pm.paysuccessfultime) >=  to_date('20150101','yyyymmdd')   ) then  '天津分公司'
--福州
					when  get_fcname(p.fconfigid)='福州市' and  (decode(dis.discountid,70054,o.createtime,70057,o.createtime,2341200,o.createtime,70049,o.deliverydate,70053,o.ismodiftime,pm.paysuccessfultime) >=  to_date('20130901','yyyymmdd')   ) then  '福州分公司'
--郑州
						when  get_fcname(p.fconfigid)='太原市' and  (decode(dis.discountid,70054,o.createtime,70057,o.createtime,2341200,o.createtime,70049,o.deliverydate,70053,o.ismodiftime,pm.paysuccessfultime) <=  to_date('20130901','yyyymmdd')   ) then  '郑州分公司'
            when  get_fcname(p.fconfigid)='新乡市' and  (decode(dis.discountid,70054,o.createtime,70057,o.createtime,2341200,o.createtime,70049,o.deliverydate,70053,o.ismodiftime,pm.paysuccessfultime) <=  to_date('20130901','yyyymmdd')   ) then  '郑州分公司'
            when  get_fcname(p.fconfigid)='郑州市' and  (decode(dis.discountid,70054,o.createtime,70057,o.createtime,2341200,o.createtime,70049,o.deliverydate,70053,o.ismodiftime,pm.paysuccessfultime) <= to_date('20130901','yyyymmdd')   ) then  '郑州分公司'
						when  get_fcname(p.fconfigid)='洛阳市' and  (decode(dis.discountid,70054,o.createtime,70057,o.createtime,2341200,o.createtime,70049,o.deliverydate,70053,o.ismodiftime,pm.paysuccessfultime) <=  to_date('20130901','yyyymmdd')   ) then  '郑州分公司'
---others
when  get_fcname(p.fconfigid)='北京市' then  '北京分公司'
when  get_fcname(p.fconfigid)='澳门特别行政区' then  '北京分公司'
when  get_fcname(p.fconfigid)='大同市' then  '北京分公司'
when  get_fcname(p.fconfigid)='银川' then  '北京分公司'

when  get_fcname(p.fconfigid)='上海市' then  '上海分公司'


when  get_fcname(p.fconfigid)='广州市' then  '广州分公司'
when  get_fcname(p.fconfigid)='佛山市' then  '广州分公司'
when  get_fcname(p.fconfigid)='东莞市' then  '广州分公司'
when  get_fcname(p.fconfigid)='珠海市' then  '广州分公司'
when  get_fcname(p.fconfigid)='汕头市' then  '广州分公司'
when  get_fcname(p.fconfigid)='三亚市' then  '广州分公司'
when  get_fcname(p.fconfigid)='梅州市' then  '广州分公司'
when  get_fcname(p.fconfigid)='柳州市' then  '广州分公司'
when  get_fcname(p.fconfigid)='江门市' then  '广州分公司'
when  get_fcname(p.fconfigid)='中山市' then  '广州分公司'
when  get_fcname(p.fconfigid)='惠州市' then  '广州分公司'
when  get_fcname(p.fconfigid)='海口市' then  '广州分公司'
when  get_fcname(p.fconfigid)='南宁市' then  '广州分公司'

when  get_fcname(p.fconfigid)='合肥市' then  '合肥分公司'
when  get_fcname(p.fconfigid)='芜湖市' then  '合肥分公司'
when  get_fcname(p.fconfigid)='杭州市' then  '合肥分公司'
when  get_fcname(p.fconfigid)='温州市' then  '合肥分公司'
when  get_fcname(p.fconfigid)='金华市' then  '合肥分公司'
when  get_fcname(p.fconfigid)='舟山市' then  '合肥分公司'
when  get_fcname(p.fconfigid)='马鞍山市' then  '合肥分公司'
when  get_fcname(p.fconfigid)='湖州市' then  '合肥分公司'
when  get_fcname(p.fconfigid)='嘉兴市' then  '合肥分公司'


when  get_fcname(p.fconfigid)='南京市' then  '南京分公司'
when  get_fcname(p.fconfigid)='苏州市' then  '南京分公司'
when  get_fcname(p.fconfigid)='常州市' then  '南京分公司'
when  get_fcname(p.fconfigid)='无锡市' then  '南京分公司'
when  get_fcname(p.fconfigid)='南通市' then  '南京分公司'
when  get_fcname(p.fconfigid)='淮安市' then  '南京分公司'
when  get_fcname(p.fconfigid)='扬州市' then  '南京分公司'
when  get_fcname(p.fconfigid)='徐州市' then  '南京分公司'
when  get_fcname(p.fconfigid)='昆山市' then  '南京分公司'
when  get_fcname(p.fconfigid)='泰州市' then  '南京分公司'
when  get_fcname(p.fconfigid)='九江市' then  '南京分公司'
when  get_fcname(p.fconfigid)='绍兴市' then  '南京分公司'

when  get_fcname(p.fconfigid)='天津市' then  '天津分公司'
when  get_fcname(p.fconfigid)='济南市' then  '天津分公司'
when  get_fcname(p.fconfigid)='青岛市' then  '天津分公司'
when  get_fcname(p.fconfigid)='石家庄市' then  '天津分公司'
when  get_fcname(p.fconfigid)='呼和浩特市' then  '天津分公司'
when  get_fcname(p.fconfigid)='威海市' then  '天津分公司'
when  get_fcname(p.fconfigid)='潍坊市' then  '天津分公司'
when  get_fcname(p.fconfigid)='包头市' then  '天津分公司'
when  get_fcname(p.fconfigid)='南阳市' then  '天津分公司'


when  get_fcname(p.fconfigid)='深圳市' then  '深圳分公司'
when  get_fcname(p.fconfigid)='湛江市' then  '深圳分公司'

when  get_fcname(p.fconfigid)='武汉市' then  '武汉分公司'
when  get_fcname(p.fconfigid)='长沙市' then  '武汉分公司'
when  get_fcname(p.fconfigid)='仙桃市' then  '武汉分公司'
when  get_fcname(p.fconfigid)='南昌市' then  '武汉分公司'

when  get_fcname(p.fconfigid)='成都市' then  '成都分公司'
when  get_fcname(p.fconfigid)='昆明市' then  '成都分公司'
when  get_fcname(p.fconfigid)='贵阳市' then  '成都分公司'
when  get_fcname(p.fconfigid)='绵阳市' then  '成都分公司'

when  get_fcname(p.fconfigid)='重庆市' then  '重庆分公司'
when  get_fcname(p.fconfigid)='昌吉回族自治州' then  '重庆分公司'

when  get_fcname(p.fconfigid)='大连市' then  '大连分公司'
when  get_fcname(p.fconfigid)='沈阳市' then  '大连分公司'
when  get_fcname(p.fconfigid)='长春市' then  '大连分公司'

when  get_fcname(p.fconfigid)='厦门市' then  '福州分公司'
when  get_fcname(p.fconfigid)='泉州市' then  '福州分公司'

when  get_fcname(p.fconfigid)='西安市' then  '西安分公司'


else  'XXXXX'        end into v_fgs

 from t_ordersdetail od,
            t_orders       o,
            t_payment      pm,
            t_product      p,
            T_PRODUCTPLAY  pp,
            t_discount     dis
 where o.ordersid = pm.ordersid
   and od.ordersid = o.ordersid
    and p.productid = pp.productid
     and od.productplayid = pp.productplayid
      and pm.discount=dis.DISCOUNTID(+)  and dis.HOST=2
      and od.ordersdetailid=v_ordersdetailid ;
 return  v_fgs;
 exception
  when no_data_found then
    return ''  ;
  when others then
    return '出错了' || v_ordersdetailid;
end;

/

