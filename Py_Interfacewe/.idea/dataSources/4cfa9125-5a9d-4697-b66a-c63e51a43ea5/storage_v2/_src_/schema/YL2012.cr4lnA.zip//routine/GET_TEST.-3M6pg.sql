CREATE FUNCTION GET_test (odid in  number,v_Productid out varchar2 ,v_pname OUT VARCHAR2)
return varchar2 is
begin
  select tp.productid  ,tp.name into v_Productid,v_pname
    from T_PRODUCT tp,T_PRODUCTPLAY tpa,T_ORDERSDETAIL tod
   where   tod.productplayid=tpa.productplayid
   and tpa.productid=tp.productid
   and tod.ordersdetailid=odid;
exception
  when no_data_found then
    return '未知' || v_Productid;
  when others then
    return '出错了' || v_Productid;
end;



/

