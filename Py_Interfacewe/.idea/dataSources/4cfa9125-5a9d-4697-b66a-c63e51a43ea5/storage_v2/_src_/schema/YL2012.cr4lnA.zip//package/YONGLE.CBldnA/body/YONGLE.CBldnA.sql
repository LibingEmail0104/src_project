CREATE package body yongle
is
 function pd(oid number) return varchar2
 is
 d varchar2(3000);
 begin
  select clob_concat(tpd.discountdetailid||'^'||tpd.payment_status||'^'||nvl(tpd.cwid, tpd.id)||'^'||tpd.discount||'^'||tpd.actual_fee||tpd.discountvalue||'^'||tpd.cardno||'^'||tpd.id  || '^' || tpd.retry_time||'^'||tpd.third_trade_no||'^'||rownum) into d from t_payment_detail tpd where tpd.order_id=oid;
  return d;
 end pd;

 --获取订单支付方式：oid 订单Id, payStatus 支付状态, showType 显示格式(1:包含交易号，其他正常显示) ZhaoHb2016.11.11
 function pmd(oid number, payStatus number, showType number) return varchar2 is
    cols_fmt varchar2(500);
    wm_paymethod varchar2(3000);
    tsql varchar2(3000);
  begin
    if showType = 1 then
      --显示追加 + 交易号
      cols_fmt := 'case when discount=2341200 then ''联盟支付-{''||discountdetailid||''}(''||nvl(cwid, id)||'')'' when discountdetailid in (71754712,57120812,144201733) then ''{''||discountdetailid||''}(''||id||''_''||nvl(retry_time, 1)||'')'' else ''{''||discountdetailid||''}(''||nvl(cwid, id)||'')'' end';
    else
      --正常显示：联盟支付前追加文本
      cols_fmt := 'distinct(case when discount=2341200 then ''联盟支付-{''||discountdetailid||''}'' else ''{''||discountdetailid||''}'' end)';
    end if;
    --dbms_output.put_line(cols_fmt);
    --1.支付状态：0：未支付状态 或 4：等待付款
    --条件：支付明细表：（支付状态==未支付 或 支付方式==赊销、预存故宫、系统赊销、主办售票）  取最近一条记录
    if payStatus = 0 or payStatus = 4 then
      tsql := 'select '||cols_fmt||' as paymethod from t_payment_detail where id = (select max(pad.id) from t_payment_detail pad where pad.order_id =:oid and (pad.payment_status = 0 or pad.discount in (70049, 62923793, 62923783, 63046930)))';
    --2.支付状态：1：部分支付
    --条件：支付明细表：（支付状态==已支付 union（支付状态!=已支付 取最近一条记录））
    elsif payStatus = 1 then
      tsql := 'select clob_concat('||cols_fmt||') as paymethod from ((select * from t_payment_detail pad where pad.order_id ='||oid||' and pad.payment_status = 1 ) union all (select * from t_payment_detail where id = (select max(pad.id) from t_payment_detail pad where pad.order_id = :oid and pad.payment_status != 1))) t order by t.id desc';
    --3.支付状态：2：已支付
    --条件：支付明细表：（支付状态==已支付）
    elsif payStatus = 2 then
      tsql := 'select clob_concat('||cols_fmt||') as paymethod from t_payment_detail pad where pad.order_id =:oid and pad.payment_status = 1 order by pad.id desc';
    --4.其他订单状态：
    --条件：支付明细表：（支付状态==已支付、已退款）
    else
      tsql := 'select clob_concat('||cols_fmt||') as paymethod from t_payment_detail pad where pad.order_id =:oid and pad.payment_status in (1, 2) order by pad.id desc';
    end if;
    --dbms_output.put_line(tsql);
    --动态SQL，用 tsql 字符串返回结果，用using关键词传递参数
    EXECUTE IMMEDIATE tsql INTO wm_paymethod using oid;
    return wm_paymethod;
  end pmd;

  function upd(oid number,discount number) return varchar2
 is
a varchar2(500) ;
 begin
   select wm_concat(tpd.id) into a from t_payment_detail tpd where tpd.order_id=oid and tpd.discount=discount;
   dbms_output.put_line( a );
    if a is null then
   return 0;
  else
   return 1;
  end if;
 end upd;

 function hostdiscount(odid number) return number
 is
 n number;
 begin
 select torp.discount_rate * 100  into n from t_ordersdetail_promos torp where torp.ordersdetailid = odid  and torp.promotypecd in ('10', '910');
 -- select wm_concat(tpd.discountdetailid||'^'||tpd.payment_status||'^'||nvl(tpd.cwid, tpd.id)||'^'||tpd.discount||'^'||tpd.actual_fee||tpd.discountvalue||'^'||tpd.cardno||'^'||rownum) into d from t_payment_detail tpd where tpd.order_id=oid;
  return n;
 end hostdiscount;

  function userdiscount(odid number) return number
 is
 n number;
 begin
  select torp.discount_rate * 100  into n from t_ordersdetail_promos torp where torp.ordersdetailid = odid  and torp.promotypecd in ('900', '920', '930', '940', '999');
  return n;
 end userdiscount;

 function uniondiscount(odid number) return number
 is
 n number;
 begin
  select torp.discount_rate * 100  into n from t_ordersdetail_promos torp where torp.ordersdetailid = odid  and torp.promotypecd in ('900');
  return n;
 end uniondiscount;

 function actualfee(did number,oid number) return number
 is
 n number;
 begin
 select sum(tpd.actual_fee) into n from t_payment_detail tpd where tpd.discountdetailid=did and tpd.order_id=oid and tpd.payment_status=1;
 return n;
 end actualfee;
end yongle;
/

