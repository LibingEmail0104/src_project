CREATE VIEW V_COMPANY AS
  select '天津市' fz,t1.fconfigid,t.cityid,t.cityname from t_city t,t_fconfig t1
where  t.cityname in
 (
'天津市','郑州市','洛阳市','许昌市','新乡市','威海市','济南市','石家庄市','青岛市','呼和浩特市','太原市','大同市','潍坊市','南阳市','包头市','秦皇岛市','唐山市','沧州市','邯郸市','烟台市','焦作','德州','临沂','泰安','赤峰','鄂尔多斯','保定','张家口市','阿拉善盟','淄博市','济宁市'
)
and t.cityid=t1.cityid

union all

select '南京市' fz,t1.fconfigid,t.cityid,t.cityname from t_city t,t_fconfig t1
where  t.cityname in

(
'南京市','常州市','无锡市','苏州市','扬州市','淮安市','徐州市','泰州市','镇江市','南通市','宿迁市','盐城市'

)
and t.cityid=t1.cityid

union all

select '合肥市' fz,t1.fconfigid,t.cityid,t.cityname from t_city t,t_fconfig t1
where  t.cityname in

(
'合肥市','芜湖市','马鞍山市','安庆市','六安市','黄山'
)
and t.cityid=t1.cityid
union all

select '广州市' fz,t1.fconfigid,t.cityid,t.cityname from t_city t,t_fconfig t1
where  t.cityname in

(
'广州市','佛山市','海口市','湛江市','珠海市','汕头市','南宁市','梅州市','东莞市','柳州市','江门市','中山市','三亚市','惠州市','阳江市','茂名市','清远市','肇庆市'

)
and t.cityid=t1.cityid
union all

select '上海市' fz,t1.fconfigid,t.cityid,t.cityname from t_city t,t_fconfig t1
where  t.cityname in
('上海市'
)
and t.cityid=t1.cityid
union all

select '北京市' fz,t1.fconfigid,t.cityid,t.cityname from t_city t,t_fconfig t1
where  t.cityname in

(
'北京市','韩国','台湾省','日本','新加坡','马来西亚','泰国'

)

and t.cityid=t1.cityid
union all
select '深圳市' fz,t1.fconfigid,t.cityid,t.cityname from t_city t,t_fconfig t1
where  t.cityname in

(
'深圳市','香港特别行政区','澳门特别行政区'
)
and t.cityid=t1.cityid
union all


select '武汉市' fz,t1.fconfigid,t.cityid,t.cityname from t_city t,t_fconfig t1
where  t.cityname in

(
'武汉市','贵阳市','长沙市','仙桃市','遵义市','孝感市','铜仁地区','黄冈市','岳阳市','荆州市','黔南布依族苗族自治州','恩施土家族苗族自治州','宜昌市','株洲市','黔西南布依族苗族自治州','娄底市','六盘水市','襄阳市','潜江市','黔东南苗族侗族自治州','安顺市'
)
and t.cityid=t1.cityid
union all

select '成都市' fz,t1.fconfigid,t.cityid,t.cityname from t_city t,t_fconfig t1
where  t.cityname in

(
'成都市','绵阳市','昆明市','南充市','曲靖市','楚雄彝族自治州','玉溪市','德阳市','攀枝花市','自贡市','广元市','丽江市','大理白族自治州','凉山彝族自治州','红河哈尼族彝族自治州','遂宁市','乐山市','泸州市','达州市','宜宾市'
)
and t.cityid=t1.cityid
union all

select '重庆市' fz,t1.fconfigid,t.cityid,t.cityname from t_city t,t_fconfig t1
where  t.cityname in

(
'乌鲁木齐市','兰州市','银川市','重庆市','白银市','克拉玛依市','昌吉回族自治州','西宁市'
)
and t.cityid=t1.cityid
union all

select '大连市' fz,t1.fconfigid,t.cityid,t.cityname from t_city t,t_fconfig t1
where  t.cityname in

(
'哈尔滨市','大连市','营口市','沈阳市','铁岭市','朝阳市','鞍山市','葫芦岛市','长春市','延边朝鲜族自治州','本溪市','大庆市','盘锦市'
)
and t.cityid=t1.cityid

union all
select '福州市' fz,t1.fconfigid,t.cityid,t.cityname from t_city t,t_fconfig t1
where  t.cityname in

(
'福州市','厦门市','泉州市','三明市','莆田市','南昌市','九江市','赣州市','萍乡市','抚州市','鹰潭市'
)
and t.cityid=t1.cityid

union all
select '西安市' fz,t1.fconfigid,t.cityid,t.cityname from t_city t,t_fconfig t1
where  t.cityname in

(
'西安市','渭南市','咸阳','宝鸡','铜川市'
)
and t.cityid=t1.cityid
/

