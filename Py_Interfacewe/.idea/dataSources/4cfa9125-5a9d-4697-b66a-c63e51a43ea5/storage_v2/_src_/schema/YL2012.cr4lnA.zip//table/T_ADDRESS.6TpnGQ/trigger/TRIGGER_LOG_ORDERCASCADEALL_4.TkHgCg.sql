CREATE TRIGGER TRIGGER_LOG_ORDERCASCADEALL_4
  AFTER UPDATE
  ON T_ADDRESS
  FOR EACH ROW
  declare
  PRAGMA AUTONOMOUS_TRANSACTION;
  oid number;
  --定义游标
  cursor c_obj is
    select o.ordersid, d.ordersdetailid, tp.paymentid, addr.addressid
      from t_orders o, t_ordersdetail d, t_payment tp, t_address addr
     where o.ordersid = d.ordersid
       and o.ordersid = tp.ordersid
       and o.addressid = addr.addressid(+)
       and addr.addressid = :old.addressid;
  c_row c_obj%rowtype;
begin

  -- dbms_output.put_line('1');
  for c_row in c_obj loop

    if c_row.ordersid is not null and c_row.ordersdetailid is not null and
       c_row.paymentid is not null then

      oid := c_row.ordersid;

      /*dbms_output.put_line('全部非空' || c_row.ordersid || ',' ||
      c_row.ordersdetailid || ',' || c_row.paymentid || ',' ||
      c_row.addressid);*/

      dbms_output.put_line('oid:=' || oid);
    else

      dbms_output.put_line('有空值' || c_row.ordersid || ',' ||
                           c_row.ordersdetailid || ',' || c_row.paymentid || ',' ||
                           c_row.addressid);

    end if;

  end loop;

  p_orderlog_cascadeall(oid);

end;


/

