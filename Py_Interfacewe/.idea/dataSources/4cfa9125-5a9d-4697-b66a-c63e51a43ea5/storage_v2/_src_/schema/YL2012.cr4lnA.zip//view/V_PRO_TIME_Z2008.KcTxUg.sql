CREATE VIEW V_PRO_TIME_Z2008 AS
  select pr.productid,pr.ordersource,pr.discount, sum(a.ytotal)  ytotal from vt_od_proc pr,
( select tp.productid,
       decode( o.ordersource,3,3,4,4,5) ordersource,
         decode(pd.discountdetailid,
                  2217200,
                  1,
                  66985006,
                  2,
                  71796727,
                  3,
                  71796728,
                  4,
                  71772150,
                  5,
                  71754712,
                  6,
                  57120812,
                  7
                  ) discount,
        sum(od.ytotal) ytotal
   from t_orders         o,
        t_ordersdetail   od,
        t_productplay    tp,
        t_payment_detail pd
  where o.ordersid = od.ordersid
    and od.productplayid = tp.productplayid
    and o.ordersid = pd.order_id(+)
    and batch like 'YL_0_%'  and o.createtime> to_date('20161101','yyyymmdd')
  group by   tp.productid,
        o.ordersource,
         decode(pd.discountdetailid,
                  2217200,
                  1,
                  66985006,
                  2,
                  71796727,
                  3,
                  71796728,
                  4,
                  71772150,
                  5,
                  71754712,
                  6,
                  57120812,
                  7
                  )
    ) a where pr.productid=a.productid(+) and pr.ordersource=a.ordersource(+) and pr.discount=a.discount(+) and pr.mtime='20080101'  group by  pr.productid,pr.ordersource,pr.discount
/

