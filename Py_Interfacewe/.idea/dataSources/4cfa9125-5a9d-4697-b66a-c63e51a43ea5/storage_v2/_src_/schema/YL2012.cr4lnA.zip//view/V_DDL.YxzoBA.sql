CREATE VIEW V_DDL AS
  select "DB_NAME","LOGIN_USER","DDL_TIME","IP_ADDRESS","AUDSID","SCHEMA_USER","SCHEMA_OBJECT","LOGIN_TOOL","OS_HOST","OS_USER","DDL_SQL" from sys.t_ddl_audit order by ddl_time desc


/

