CREATE FUNCTION GET_mincodeid (p_areaid number) return varchar2 is
  v_codeid varchar2(50);
begin
  select min(codeid)   into v_codeid from t_code t  where t.areaid=p_areaid;
  return v_codeid;
end;

/

