CREATE procedure YL_AUTO_loop
    is
   v_ytotal number;
   CURSOR c1 is select * from vt_productid;
   c_c1 c1%rowtype;
begin
  open c1;
  loop
      fetch c1 into c_c1;
      select sum(ytotal)  into v_ytotal from t_orders t where t.batch = 'YL_'||c_c1.productid||'_'||c_c1.dt;
      exit  when c1%notfound;
--    dbms_output.put_line( 'YL_'||c_c1.productid||'%');
      while v_ytotal>c_c1.total
            loop
                 YL_AUTO_degre(c_c1.productid,c_c1.dt);
                 select sum(ytotal)  into v_ytotal from t_orders t where  t.batch = 'YL_'||c_c1.productid||'_'||c_c1.dt;
           end loop;
     end loop;
 close c1;
 end;

/

