CREATE function get_tuiguang (i_tuiguang varchar2)
return varchar2 is
v_tuiguang varchar2(40);
begin
  select name
    into v_tuiguang
    from t_code t,
         (select info, max(t.codeid) codeid
            from t_code t
           where type = 6
           group by info) ta
   where ta.codeid = t.codeid
   and t.info=i_tuiguang;

 return v_tuiguang;
exception
  when no_data_found then
    return ''  ;
  when others then
    return '出错了' || v_tuiguang;
end;



/

