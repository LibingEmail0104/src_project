CREATE PROCEDURE P_order_defualt is
  --定义游标
  cursor c_ci2 is

    select rowid row_id from   t_customers where  IFALIPAY is null  ;

  r_ci2 c_ci2 % rowtype;
  --判断循环次数
  v_index number := 0;
begin
  --判断游标是否打开
  if c_ci2%isopen then
    null;
  else
    open c_ci2;
  end if;

  loop
    fetch c_ci2
      into r_ci2;
    exit when c_ci2%notfound;



  update t_customers t set  t.IFALIPAY=0 where t.IFALIPAY is null and  t.rowid=r_ci2.row_id;

    --分段提交
    v_index := v_index + 1;
    if (v_index = 5000) then
      commit;
      v_index := 0;
    end if;
  end loop;

   commit;

  close c_ci2;
end P_order_defualt;

/

