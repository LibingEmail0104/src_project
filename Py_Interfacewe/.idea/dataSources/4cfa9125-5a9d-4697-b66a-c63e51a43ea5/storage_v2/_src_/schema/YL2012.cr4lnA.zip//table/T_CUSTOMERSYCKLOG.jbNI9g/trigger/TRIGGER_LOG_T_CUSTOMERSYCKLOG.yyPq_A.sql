CREATE TRIGGER TRIGGER_LOG_T_CUSTOMERSYCKLOG
  AFTER UPDATE
  ON T_CUSTOMERSYCKLOG
  FOR EACH ROW
  begin
  insert into log_t_customersycklog
    (logid,
     customersid,
     renewaltime,
     renewaluser,
     balance,
     renewal,
     count,
     flag,
     orderid,
     declares,
     logtime)
  values
    (:old.LOGID,
     :old.CUSTOMERSID,
     :old.RENEWALTIME,
     :old.RENEWALUSER,
     :old.BALANCE,
     :old.RENEWAL,
     :old.COUNT,
     :old.FLAG,
     :old.ORDERID,
     :old.DECLARES,
     sysdate);
end;


/

