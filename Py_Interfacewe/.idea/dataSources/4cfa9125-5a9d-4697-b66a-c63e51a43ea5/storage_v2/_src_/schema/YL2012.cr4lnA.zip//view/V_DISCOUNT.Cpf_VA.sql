CREATE VIEW V_DISCOUNT AS
  select t1.discountid,t1.role,t2.discountdetailid,t2.rank from t_discount t1,t_discountdetail t2 where t1.discountid=t2.discountid(+) and t1.host=2

/

