CREATE TYPE          "TY_TBL_STR_SPLIT"                                          IS TABLE OF ty_row_str_split
/

