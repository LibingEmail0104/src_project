CREATE PROCEDURE "P_SET_REGPHONE" is
  --定义游标
  cursor c_ci is
    SELECT distinct (c.CUSTOMERSID) --, c.phone as cphone, ad.phone as adphone,o.DZPHONE as ophone
      FROM T_CUSTOMERS c
      LEFT JOIN T_ORDERS o
        ON c.CUSTOMERSID = o.CUSTOMERSID
      LEFT JOIN T_ADDRESS ad
        ON o.ADDRESSID = ad.ADDRESSID
       and (ad.phone = c.phone or ad.TEL = c.phone or c.phone = o.DZPHONE)
      LEFT JOIN T_PAYMENT pa
        ON pa.OrdersID = o.ORDERSID
       AND pa.PAYSTATUS IN (1, 2)
     WHERE c.PHONE IS NOT NULL
       and (ad.phone is not null or ad.TEL is not null or
           o.DZPHONE is not null)
       and o.STARUS not in (7, 10)
       and (c.REGPHONE is null or c.ISRENEWAL is null or c.REGPHONE = 0 or
           c.ISRENEWAL = 0)
       and c.type=0

    UNION

    SELECT distinct (c.CUSTOMERSID) --,c.phone as cphone,ad.phone as adphoneo.phone as ophone
      FROM T_CUSTOMERS c
      LEFT JOIN JF_Order o
        ON c.CUSTOMERSID = o.CUSTOMERSID
      LEFT JOIN JF_ADDRESS ad
        ON o.ADDRESSID = ad.ADDRESSID
       and (ad.phone = c.phone or ad.TEL = c.phone or c.phone = o.phone)

     WHERE c.PHONE IS NOT NULL
       and (ad.phone is not null or ad.TEL is not null or
           o.phone is not null)
       and o.STATUS != 6
       and (c.REGPHONE is null or c.ISRENEWAL is null or c.REGPHONE = 0 or
           c.ISRENEWAL = 0)
       and c.type=0;
  --定义rowtype
  r_ci c_ci % rowtype;
  --判断循环次数
  v_index number := 0;
begin
  --判断游标是否打开
  if c_ci%isopen then
    null;
  else
    open c_ci;
  end if;

  loop
    fetch c_ci
      into r_ci;
    exit when c_ci%notfound;
    -- 更新手机验证状态为已验证
    update t_customers tcus
       set tcus.regphone = 1
     where tcus.customersid = r_ci.customersid;

    --分段提交
    v_index := v_index + 1;
    if (v_index = 2000) then
      commit;
      v_index := 0;
    end if;
  end loop;

   commit;

  close c_ci;
end P_SET_REGPHONE;

/

