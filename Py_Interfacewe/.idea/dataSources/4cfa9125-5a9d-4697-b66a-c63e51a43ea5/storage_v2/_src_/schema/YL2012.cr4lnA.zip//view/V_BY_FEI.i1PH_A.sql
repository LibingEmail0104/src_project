CREATE VIEW V_BY_FEI AS
  select
  t.order_id,t.discountdetailid mdiscount,sum(t.actual_fee)  actual_fee
     from t_payment_detail   t where t.payment_status!=0   group by t.order_id,t.discountdetailid
/

