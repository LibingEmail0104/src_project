CREATE PROCEDURE          "P_ORDERLOG" (username         varchar2,
                                       phone            varchar2,
                                       address          varchar2,
                                       psxx             number,
                                       rangeprice       number,
                                       zprice           number,
                                       role             varchar2,
                                       rank             varchar2,
                                       discountpay      number,
                                       discount         varchar2,
                                       paystatus        number,
                                       starus           number,
                                       processingstarus number,
                                       companyinfo      varchar2,
                                       rangepinfo       varchar2,
                                       ordersid         number,
                                       lastuser         varchar2,
                                       lasttime         date) as
begin

  insert into LOG_ORDERCASCADEALL
  values
    (seq_log.nextval,
     username,
     phone,
     address,
     psxx,
     rangeprice,
     zprice,
     role,
     rank,
     discountpay,
     discount,
     paystatus,
     starus,
     processingstarus,
     companyinfo,
     rangepinfo,
     ordersid,
     lastuser,
     lasttime,
     sysdate);

end;




/

