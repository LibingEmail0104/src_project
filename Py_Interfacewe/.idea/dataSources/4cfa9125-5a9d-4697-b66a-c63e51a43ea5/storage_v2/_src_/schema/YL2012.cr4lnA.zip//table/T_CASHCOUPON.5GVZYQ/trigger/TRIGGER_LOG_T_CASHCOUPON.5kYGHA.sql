CREATE TRIGGER TRIGGER_LOG_T_CASHCOUPON
  AFTER UPDATE OR DELETE
  ON T_CASHCOUPON
  FOR EACH ROW
  begin
insert into LOG_T_CASHCOUPON
 (
  cashcouponid         ,
  cashcouponname       ,
  isreuse              ,
  tickettype           ,
  begindate            ,
  enddate              ,
  dayslimit            ,
  parvalue             ,
  num                  ,
  lowest               ,
  usescope             ,
  usefconfig           ,
  useproducttype       ,
  specialproducttype   ,
  specialproductids    ,
  allocationstatus     ,
  allocationdepartment ,
  exportnum            ,
  invalidstatus        ,
  warningtime          ,
  invalidreasons       ,
  createdate           ,
  lastdate             ,
  lastuser             ,
  allocationuser       ,
  allocationdate       ,
  createuser           ,
  marketinvalidreasons ,
  warninguser          ,
  dishalltype          ,
  logtime               ,
  ipaddr
)
values
(
  :old.cashcouponid         ,
  :old.cashcouponname       ,
  :old.isreuse              ,
  :old.tickettype           ,
  :old.begindate            ,
  :old.enddate              ,
  :old.dayslimit            ,
  :old.parvalue             ,
  :old.num                  ,
  :old.lowest               ,
  :old.usescope             ,
  :old.usefconfig           ,
  :old.useproducttype       ,
  :old.specialproducttype   ,
  :old.specialproductids    ,
  :old.allocationstatus     ,
  :old.allocationdepartment ,
  :old.exportnum            ,
  :old.invalidstatus        ,
  :old.warningtime          ,
  :old.invalidreasons       ,
  :old.createdate           ,
  :old.lastdate             ,
  :old.lastuser             ,
  :old.allocationuser       ,
  :old.allocationdate       ,
  :old.createuser           ,
  :old.marketinvalidreasons ,
  :old.warninguser          ,
  :old.dishalltype          ,
  sysdate                  ,
  sys_context('userenv','ip_address')
);
end;


/

