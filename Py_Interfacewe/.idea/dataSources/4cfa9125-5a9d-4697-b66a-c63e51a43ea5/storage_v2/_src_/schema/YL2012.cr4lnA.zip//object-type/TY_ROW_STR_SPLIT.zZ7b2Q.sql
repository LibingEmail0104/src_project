CREATE TYPE          "TY_ROW_STR_SPLIT"                                          as object (strValue VARCHAR2 (4000))
/

