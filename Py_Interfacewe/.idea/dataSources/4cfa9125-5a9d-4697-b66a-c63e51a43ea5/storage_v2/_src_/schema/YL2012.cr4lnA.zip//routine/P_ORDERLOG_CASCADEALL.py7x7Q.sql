CREATE PROCEDURE "P_ORDERLOG_CASCADEALL" (oid number) as
  discount         varchar2(255);
  username         varchar2(255);
  phone            varchar2(255);
  address          varchar2(1000);
  psxx             number;
  rangeprice       number;
  zprice           number;
  role             varchar2(255);
  rank             varchar2(255);
  discountpay      number;
  paystatus        number;
  starus           number;
  processingstarus number;
  companyinfo      varchar2(4000);
  rangepinfo       varchar2(1000);
  ordersid         number;
  lastuser         varchar2(255);
  lasttime         date;
begin
/*  select wm_concat(d.discount)
    into discount
    from (select distinct t.ordersid,
                          t.discount || t.customerdiscount discount
            from t_ordersdetail t
           where t.ordersid = oid) d
   group by d.ordersid;

*/
  --获取折扣
 select wm_concat(d.discount)
    into discount
    from (select distinct tord.ordersid,torp.discount_rate * 100  discount
            from t_ordersdetail tord,t_ordersdetail_promos torp
            where tord.ordersdetailid = torp.ordersdetailid and torp.promotypecd in（900,920,930,940,999)
           and tord.ordersid = oid) d;
                 
  select wm_concat(td.role), wm_concat(tdd.rank)
    into role, rank
    from t_payment_detail t, t_discount td, t_discountdetail tdd
   where t.discount = td.discountid(+)
     and t.discountdetailid = tdd.discountdetailid(+)
     and t.order_id = oid;
   
  select distinct taddr.username,
                  taddr.phone,
                  taddr.name,
                  tor.psxx,
                  tor.rangeprice,
                  tp.zprice,
                  tp.discountpay,
                  tp.paystatus,
                  tor.starus,
                  tor.processingstarus,
                  tor.companyinfo,
                  tor.rangepinfo,
                  tor.ordersid,
                  tor.lastuser,
                  tor.lasttime
    into username,
         phone,
         address,
         psxx,
         rangeprice,
         zprice,
         discountpay,
         paystatus,
         starus,
         processingstarus,
         companyinfo,
         rangepinfo,
         ordersid,
         lastuser,
         lasttime
    from t_orders         tor,
         t_address        taddr,
         t_payment        tp,
         t_discount       td,
         t_discountdetail tddl,
         t_ordersdetail   torddl
   where tor.addressid = taddr.addressid(+)
     and tor.ordersid = tp.ordersid
     and tp.DISCOUNT = td.discountid(+)
     and tp.discountdetailid = tddl.discountdetailid(+)
     and tor.ordersid = torddl.ordersid
     and tor.ordersid = oid;
  p_orderlog(username,
             phone,
             address,
             psxx,
             rangeprice,
             zprice,
             role,
             rank,
             discountpay,
             nvl(discount,100),
             paystatus,
             starus,
             processingstarus,
             companyinfo,
             rangepinfo,
             ordersid,
             lastuser,
             lasttime);

  commit;
    --异常,新WAP站在保存 上门自取 订单时,触发器报错,故这里先加一个异常,待修改此BUG.T.L 140803
    EXCEPTION
        WHEN OTHERS THEN
             ROLLBACK;
end;




/

