CREATE VIEW V_ZORDER_PRODUCT_CW2 AS
  select
       '01.' || f.fconfigid || '.' || ta.producttypeaid || '.' ||tb.producttypebid || '.' || p.productid codes,
       city.cityname  ,
       get_ordersource(o.ordersource)  ordersource,
       c.customersid  ,
       o.ordersid  ,
       od.ORDERSDETAILID  ,
       get_starus(o.starus) starus,
       o.BACKMONEYDATE  ,
       o.createtime  ,
       o.MATCHINGTIME  peipiaot,
       o.DELIVERYDATE  sendt,
       ty.ENDTIME      yichangt,
       dis.role || disd.rank  payway,
       get_paystatus(pm.paystatus) paystatus,

   /*    decode(dis.discountid,
              2341200,
              to_char(o.createtime, 'yyyy-MM-dd HH24:mi:ss'),
              70053,
              to_char(o.deliverydate, 'yyyy-MM-dd HH24:mi:ss'),
              70054,
              to_char(o.createtime, 'yyyy-MM-dd HH24:mi:ss'),
              70049,
              to_char(o.deliverydate, 'yyyy-MM-dd HH24:mi:ss'),
              70057,
              to_char(o.createtime, 'yyyy-MM-dd HH24:mi:ss'),
              to_char(pm.paysuccessfultime, 'yyyy-MM-dd HH24:mi:ss')) paysuccessfultime*/
          decode(dis.discountid,
                      70054,
                      o.createtime,
                      70057,
                      o.createtime,
                      2341200,
                      o.createtime,
                      70049,
                     o.deliverydate,
                     70053,
                     o.ismodiftime,
                     pm.paysuccessfultime)    paysuccessfultime,



       addr.username 收货人,
       decode(o.ADDRESSID, 0, '自取', '配送上上门')  sendway,
       ta.name 商品分类,
       decode(p.status,
              0,
              '售票中',
              1,
              '预售',
              2,
              '无效',
              3,
              '待定',
              4,
              '售完',
              5,
              '延期',
              6,
              '取消',
              7,
              '已结束') 商品状态,
       p.productid  ,
       p.name  pname,
       v.vname locations,
       decode(pp. playdate, null, pp.time, pp.playdate) ptime,
       p.begindate  ,
       p.enddate  ,
      p.enddate- p.begindate   zhouqi ,
       pp.PRICE  ,
       od.hostdiscount,
       pp.playinfo  ,
       od.NUM  ,
       od.YTOTAL  ,
       c.UNIONSETTLEMENTDISCOUNT  ,
   --    od.YTOTAL*(1-c.UNIONSETTLEMENTDISCOUNT/100) 联盟折扣损失,
       (case
         when (row_number() over(partition by o.ordersid order by od.YTOTAL*(1-c.UNIONSETTLEMENTDISCOUNT/100))) = 1 then
          od.YTOTAL*(1-c.UNIONSETTLEMENTDISCOUNT/100)
         else
          null
       end)   联盟折扣损失,
       decode(c.type,
              0,
              decode(od.customerdiscount, null, 100, od.customerdiscount),
              1,
              decode(od.discount, null, 100, od.discount),
              100) 折扣,
    --   od.YTOTAL - od.TOTAL 折扣损失,
       pm.discountpay 支付折扣,
   --    decode(pm.ysprice, null, 0, pm.ysprice) * (1 - pm.discountpay / 100) 支付损失,
    (case
         when (row_number() over(partition by o.ordersid order by decode(pm.ysprice, null, 0, pm.ysprice) * (1 - pm.discountpay / 100))) = 1 then
          decode(pm.ysprice, null, 0, pm.ysprice) * (1 - pm.discountpay / 100)
         else
          null
       end) 支付损失,
       od.TOTAL 票面应收,
      -- pm.insuredamount 保费,
       --o.RANGEPRICE 运费,

       (case
         when (row_number()
               over(partition by o.ordersid order by pm.insuredamount)) = 1 then
          pm.lpkprice
         else
          null
       end) 保费,



       (case
         when (row_number() over(partition by o.ordersid order by  o.RANGEPRICE)) = 1 then
           o.RANGEPRICE
         else
          null
       end) 运费,
      -- decode(pm.ljprice, null, 0, pm.ljprice) 礼卷,
       (case
         when (row_number() over(partition by o.ordersid order by pm.ljprice)) = 1 then
          pm.ljprice
         else
          null
       end) 礼卷,
      -- decode(pm.lpkprice, null, 0, pm.lpkprice) 礼品卡,
       (case
         when (row_number()
               over(partition by o.ordersid order by pm.lpkprice)) = 1 then
          pm.lpkprice
         else
          null
       end) 礼品卡,

     --  decode(pm.yckprice, null, 0, pm.yckprice) 预存款,
       (case
         when (row_number()
               over(partition by o.ordersid order by pm.yckprice)) = 1 then
          pm.yckprice
         else
          null
       end) 预存款,
     --  decode(pm.ysprice, null, 0, pm.ysprice) 应收,
       (case
         when (row_number() over(partition by o.ordersid order by pm.ysprice)) = 1 then
          pm.ysprice
         else
          null
       end) 票面款,

        tcode.name zhuban,
       te.name kuaidi,
       te.EXPRESSID 快递号,
       o.ISENDTIME 取票时间,
       o.UNIONORDERSID 联盟单号
  from t_orders         o,
       t_ordersdetail   od,
       t_customers      c,
       t_address        addr,
       t_productplay    pp,
       t_producttypea   ta,
       t_product        p,
       t_venues         v,
       t_payment        pm,
       t_fconfig        f,
       t_city           city,
       t_discount       dis,
       t_discountdetail disd,
       t_producttypeb   tb,
       t_office         tof,
       t_code           tcode,
       T_EXPRESS        te,
        T_ORDERANOMALY   ty
 where o.ordersid = od.ordersid
   and o.customersid = c.customersid
   and o.addressid = addr.addressid(+)
   and p.productid = pp.productid
   and od.productplayid = pp.productplayid
   and p.producttypeaid1 = ta.producttypeaid
   and p.venuesid = v.venuesid
   and o.ordersid = pm.ordersid
   and o.fconfigid = f.fconfigid
   and f.cityid = city.cityid
   and pm.discount = dis.DISCOUNTID(+)
   and dis.HOST = 2
   and pm.discountdetailid = disd.discountdetailid(+)
   and p.producttypebid1 = tb.producttypebid
   and p.OFFICE = tof.officeid(+)
   and p.codeid = tcode.codeid(+)
   and o.EXPRESSNAME = te.expressid(+)
    and o.ordersid=ty.ordersid(+)


/

