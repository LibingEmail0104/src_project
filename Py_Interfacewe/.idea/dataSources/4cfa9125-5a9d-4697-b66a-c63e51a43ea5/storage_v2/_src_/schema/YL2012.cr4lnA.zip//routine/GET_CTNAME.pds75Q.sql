CREATE FUNCTION "GET_CTNAME" (p_ctiyid number)
  return varchar2 is
  v_ctiyid varchar2(40);
begin

  select CITYNAME
    into v_ctiyid
    from T_CITY
   where CITYID = p_ctiyid;

  return v_ctiyid;
exception
  when no_data_found then

    return '未知' || v_ctiyid;
  when others then
    return '出错了' || v_ctiyid;
end;


/

