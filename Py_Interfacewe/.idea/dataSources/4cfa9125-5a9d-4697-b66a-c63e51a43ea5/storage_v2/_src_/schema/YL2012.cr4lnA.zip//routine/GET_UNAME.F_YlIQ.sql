CREATE function get_uname (v_customersid number)
return varchar2 is
v_truename  varchar2(40);
begin
   select t.truename into v_truename from t_customers t   where type in (2,3) and t.customersid=v_customersid;
return v_truename;
exception
  when no_data_found then
    return ''  ;
  when others then
    return '出错了' || v_truename;
end;

/

