CREATE function  get_role (v_discountid number)
return varchar2 is
v_role varchar2(40);
begin
   select role into v_role from t_discount   where discountid=v_discountid;
return v_role;
exception
  when no_data_found then
    return ''  ;
  when others then
    return '出错了' || v_role;
end;



/

