CREATE function get_date_add_tl2 (in_date        date, --时间
                                           in_productid  number,  --传入商品，供随机商品使用
                                           in_char_hour   number, --要加的天
                                           in_char_minute number --要加的分钟数,一天1440分钟
                                           ) return date is
  v_date date;
begin
    if to_char(in_date,'yyyymmdd')='20080101' then
     select enddate -
       round(dbms_random.value(0,
                               enddate -
                               to_date(to_char(enddate, 'yyyymm'), 'yyyymm')))
      + in_char_hour + (in_char_minute / (24 * 60*60))   into v_date
    from t_product
     where productid=in_productid;
     return v_date;
    else
   select  trunc(in_date) + in_char_hour + (in_char_minute / (24 * 60*60))
    into v_date
    from dual;
  return v_date;
end if;
end get_date_add_tl2;

/

