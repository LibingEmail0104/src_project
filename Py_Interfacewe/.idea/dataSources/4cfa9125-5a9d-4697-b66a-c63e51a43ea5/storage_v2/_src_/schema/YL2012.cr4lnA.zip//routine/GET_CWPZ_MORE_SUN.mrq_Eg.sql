CREATE FUNCTION get_cwpz_more_sun (p_ordersid  number,
                                       p_productid number,
                                       p_pmdid     number) return number is
  v_ptotal number(20,2);
begin
  select (select tt.pdtotal
            from tv_cwpz_orders_more_sun tt
           where tt.ordersid = p_ordersid
             and tt.productid = p_productid) /
          (select decode(sum(t.pdtotal), 0, 1, sum(t.pdtotal))
            from tv_cwpz_orders_more_par t
           where t.ordersid = p_ordersid) * get_actual_fee(p_pmdid) into v_ptotal from dual;
  return v_ptotal;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    return 'err';
end;

/

