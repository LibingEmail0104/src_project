CREATE TRIGGER TRIGGER_LOG_T_HOSTDISCOUNT
  AFTER UPDATE
  ON T_HOSTDISCOUNT
  FOR EACH ROW
  begin
  insert into log_t_hostdiscount
    (hostid,
     productplayid,
     discountdetailid,
     startintervaltime,
     endintervaltime,
     createtime,
     lasttime,
     lastuser,
     hosttype,
     status,
     logtime)
  values
    (:old.HOSTID,
     :old.PRODUCTPLAYID,
     :old.DISCOUNTDETAILID,
     :old.STARTINTERVALTIME,
     :old.ENDINTERVALTIME,
     :old.CREATETIME,
     :old.LASTTIME,
     :old.LASTUSER,
     :old.HOSTTYPE,
     :old.STATUS,
     sysdate);
end;


/

