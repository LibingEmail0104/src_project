CREATE function get_province(p_provinceid in number)
  return varchar2 is
  v_province_name varchar2(50);
begin
  v_province_name := case p_provinceid
                       when 110000 then
                        '北京市'
                       when 120000 then
                        '天津市'
                       when 130000 then
                        '河北省'
                       when 140000 then
                        '山西省'
                       when 150000 then
                        '内蒙古自治区'
                       when 210000 then
                        '辽宁省'
                       when 220000 then
                        '吉林省'
                       when 230000 then
                        '黑龙江省'
                       when 310000 then
                        '上海市'
                       when 320000 then
                        '江苏省'
                       when 330000 then
                        '浙江省'
                       when 340000 then
                        '安徽省'
                       when 350000 then
                        '福建省'
                       when 360000 then
                        '江西省'
                       when 370000 then
                        '山东省'
                       when 410000 then
                        '河南省'
                       when 420000 then
                        '湖北省'
                       when 430000 then
                        '湖南省'
                       when 440000 then
                        '广东省'
                       when 450000 then
                        '广西壮族自治区'
                       when 460000 then
                        '海南省'
                       when 500000 then
                        '重庆市'
                       when 510000 then
                        '四川省'
                       when 520000 then
                        '贵州省'
                       when 530000 then
                        '云南省'
                       when 540000 then
                        '西藏自治区'
                       when 610000 then
                        '陕西省'
                       when 620000 then
                        '甘肃省'
                       when 630000 then
                        '青海省'
                       when 640000 then
                        '宁夏回族自治区'
                       when 650000 then
                        '新疆维吾尔自治区'
                       when 710000 then
                        '台湾省'
                       when 810000 then
                        '香港特别行政区'
                       when 820000 then
                        '澳门特别行政区'
                       else
                        '未知状态'
                     end;

  return v_province_name;
end;


/

