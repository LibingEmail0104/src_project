CREATE VIEW V_COMPANY_2014 AS
  select '天津市' fz,t1.fconfigid,t.cityid,t.cityname from t_city t,t_fconfig t1
where  t.cityname in
('天津市',
'郑州市',
'济南市',
'石家庄市',
'青岛市',
'洛阳市',
'新乡市',
'呼和浩特市',
'威海市',
'太原市',
'潍坊市',
'南阳市',
'包头市'
)
and t.cityid=t1.cityid

union all

select '南京市' fz,t1.fconfigid,t.cityid,t.cityname from t_city t,t_fconfig t1
where  t.cityname in
('南京市',
'苏州市',
'常州市',
'无锡市',
'南通市',
'镇江市',
'淮安市',
'扬州市',
'徐州市',
'泰州市',
'昆山市',
'九江市',
'绍兴市'
)
and t.cityid=t1.cityid

union all


select '合肥市' fz,t1.fconfigid,t.cityid,t.cityname from t_city t,t_fconfig t1
where  t.cityname in
('合肥市',
'芜湖市',
'杭州市',
'温州市',
'金华市',
'马鞍山市',
'宁波市',
'舟山市',
'湖州市',
'嘉兴市'
)
and t.cityid=t1.cityid
union all

select '广州市' fz,t1.fconfigid,t.cityid,t.cityname from t_city t,t_fconfig t1
where  t.cityname in
('广州市',
'佛山市',
'东莞市',
'珠海市',
'汕头市',
'三亚市',
'梅州市',
'柳州市',
'江门市',
'中山市',
'南宁市',
'惠州市',
'海口市'
)
and t.cityid=t1.cityid
union all

select '上海市' fz,t1.fconfigid,t.cityid,t.cityname from t_city t,t_fconfig t1
where  t.cityname in
('上海市'
)
and t.cityid=t1.cityid
union all

select '北京市' fz,t1.fconfigid,t.cityid,t.cityname from t_city t,t_fconfig t1
where  t.cityname in
('北京市',
'澳门特别行政区',
'大同市',
'乌鲁木齐市'
)
and t.cityid=t1.cityid
union all
select '深圳市' fz,t1.fconfigid,t.cityid,t.cityname from t_city t,t_fconfig t1
where  t.cityname in
('深圳市',
'湛江市'
)
and t.cityid=t1.cityid
union all


select '武汉市' fz,t1.fconfigid,t.cityid,t.cityname from t_city t,t_fconfig t1
where  t.cityname in
('武汉市',
'长沙市',
'南昌市',
'仙桃市'
)
and t.cityid=t1.cityid
union all

select '成都市' fz,t1.fconfigid,t.cityid,t.cityname from t_city t,t_fconfig t1
where  t.cityname in
('成都市',
'昆明市',
'贵阳市',
'绵阳市',
'银川市'
)
and t.cityid=t1.cityid
union all

select '重庆市' fz,t1.fconfigid,t.cityid,t.cityname from t_city t,t_fconfig t1
where  t.cityname in
('重庆市',
'昌吉回族自治州'
)
and t.cityid=t1.cityid
union all

select '大连市' fz,t1.fconfigid,t.cityid,t.cityname from t_city t,t_fconfig t1
where  t.cityname in
('大连市',
'哈尔滨市',
'营口市',
'沈阳市',
'长春市')
and t.cityid=t1.cityid

union all
select '福州市' fz,t1.fconfigid,t.cityid,t.cityname from t_city t,t_fconfig t1
where  t.cityname in
('福州市',
'厦门市',
'泉州市'
)
and t.cityid=t1.cityid

union all
select '西安市' fz,t1.fconfigid,t.cityid,t.cityname from t_city t,t_fconfig t1
where  t.cityname in
('西安市'
)
and t.cityid=t1.cityid


/

