create view V_PRODUCT_ZBASIC as
select c.customersid as customer_id,
       c.TRUENAME as CNAME,
       c.phone  as CPHONE,
       c.email  as CMAIL,
       decode(C.TYPE,0,'用户',1,'票点',2,'联盟',3,'新联盟'，'其他') ctype,
       c.CREATETIME ctime,
       o.ordersid  as order_nu,
       o.UNIONID as union_id,
       o.UNIONORDERSID  as union_nu,
       o.createtime as mtime,
       get_starus(o.starus) starus,
       decode(o.TYPE,0,'普通','1','选座','20','抢座','未知') as seat_type,
       get_ordersource(o.ordersource) order_source,
       decode(o.PROTYPE,1,'预售',2,'热卖','未知') as product_type,   --待完善
       od.ORDERSDETAILID,
       addr.username name,
       addr.phone,
       addr.email,
       get_province(addr.provinceid) province,
       get_cityname(addr.cityid) city,
       get_areaname(addr.areaid) area,
       get_paystatus(pm.paystatus) paystatus,
       pm.sjzfprice,
       pm.ysprice,
       dis.role,
       disd.rank  ,
       p.productid,
       p.name pname,
       v.vname,
       ta.name typea,
       city.cityname
  from t_orders       o,
       t_ordersdetail od,
       t_customers    c,
       t_address      addr,
       t_productplay  pp,
       t_producttypea ta,
       t_product      p,
       t_venues       v,
       t_payment      pm,
       t_fconfig      f,
       t_city         city,
       t_discount     dis,
       t_discountdetail  disd
 where o.ordersid = od.ordersid
   and o.customersid = c.customersid
   and o.addressid = addr.addressid(+)
   and p.productid = pp.productid
   and od.productplayid = pp.productplayid
   and p.producttypeaid1 = ta.producttypeaid
   and p.venuesid = v.venuesid
   and o.ordersid = pm.ordersid
   and o.fconfigid = f.fconfigid
   and f.cityid = city.cityid
   and pm.discount=dis.DISCOUNTID(+)  and dis.HOST=2
   and pm.discountdetailid=disd.discountdetailid(+)

 
/

