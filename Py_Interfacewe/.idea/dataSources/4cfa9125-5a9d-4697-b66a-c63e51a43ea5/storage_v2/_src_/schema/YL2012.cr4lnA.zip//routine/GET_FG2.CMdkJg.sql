CREATE FUNCTION get_fg2(f_char varchar2,in_paras varchar2,in_paras2 varchar2)
--author:  zhangqiang
--createtime: 20170419
  return varchar2 is
  o_para varchar2(400);
  v_dtl  varchar(200);
begin
select 1 into o_para  from
( SELECT REGEXP_SUBSTR(in_paras,'[^\in_paras2]+',1,l) AS NAME
  FROM dual t
      ,(SELECT LEVEL l FROM DUAL CONNECT BY LEVEL<=100)
WHERE     l <=LENGTH(in_paras) - LENGTH(REPLACE(in_paras,in_paras2))+1  ) where name= f_char ;

  return o_para;
exception
  when no_data_found then
    return 0;
  when others then
    return 'oo';
end;

/

