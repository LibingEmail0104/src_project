CREATE VIEW V_CWPZ_ORDERS AS
  select o.ordersid,   --开窗函数，取订单里项目的 price*num 并区分出需要单独处理的商品
       (case
         when (row_number() over(partition by o.ordersid order by o.ordersid)) = 1 then
          o.ordersid
         else
          null
       end) ordersid2,
       tp.productid,
       o.starus,
       pm.paystatus,
     sum(od.total) pdtotal
  from t_ordersdetail od, t_orders o, t_productplay tp, t_payment pm
 where od.ordersid = o.ordersid
   and od.productplayid = tp.productplayid
   and pm.ordersid = o.ordersid
   and o.createtime > to_date('20131231', 'yyyymmdd')
 group by  o.ordersid, tp.productid,     o.starus,      pm.paystatus
/

